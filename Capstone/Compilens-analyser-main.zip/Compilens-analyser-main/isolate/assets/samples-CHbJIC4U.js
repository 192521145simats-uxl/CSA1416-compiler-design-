import{c as e}from"./index-s_wBUMsx.js";const t=[["path",{d:"M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1",key:"ezmyqa"}],["path",{d:"M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1",key:"e1hn23"}]],s=e("braces",t);const r=[["line",{x1:"6",x2:"6",y1:"3",y2:"15",key:"17qcm7"}],["circle",{cx:"18",cy:"6",r:"3",key:"1h7g24"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["path",{d:"M18 9a9 9 0 0 1-9 9",key:"n2h4wq"}]],o=e("git-branch",r);const n=[["path",{d:"M8 5h13",key:"1pao27"}],["path",{d:"M13 12h8",key:"h98zly"}],["path",{d:"M13 19h8",key:"c3s6r1"}],["path",{d:"M3 10a2 2 0 0 0 2 2h3",key:"1npucw"}],["path",{d:"M3 5v12a2 2 0 0 0 2 2h3",key:"x1gjn2"}]],d=e("list-tree",n);const i=[["path",{d:"M3 7V5a2 2 0 0 1 2-2h2",key:"aa7l1z"}],["path",{d:"M17 3h2a2 2 0 0 1 2 2v2",key:"4qcy5o"}],["path",{d:"M21 17v2a2 2 0 0 1-2 2h-2",key:"6vwrx8"}],["path",{d:"M7 21H5a2 2 0 0 1-2-2v-2",key:"ioqczr"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["path",{d:"m16 16-1.9-1.9",key:"1dq9hf"}]],h=e("scan-search",i);const a=[["path",{d:"M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18",key:"gugj83"}]],m=e("table-2",a),u=[{id:"clean",name:"Clean Program",filename:"clean.c",description:"A tidy program — no major findings expected.",code:`#include <stdio.h>

// Adds two integers safely and prints the result.
int add(int a, int b) {
    return a + b;
}

int main() {
    int x = 5;
    int y = 7;
    int sum = add(x, y);
    printf("Sum: %d\\n", sum);
    return 0;
}
`},{id:"syntax-error",name:"Syntax Error",filename:"syntax_error.c",description:"Missing semicolon on line 4 — expect a syntax finding.",code:`#include <stdio.h>

int main() {
    int x = 10
    printf("%d", x);
    return 0;
}
`},{id:"semantic-error",name:"Semantic Error",filename:"semantic_error.c",description:"Assigning a string to an int — expect a type mismatch.",code:`int main() {
    int x;
    x = "hello";
    return 0;
}
`},{id:"security-error",name:"Security Error",filename:"security_error.c",description:"Hardcoded password — expect CWE-798 (HIGH).",code:`#include <stdio.h>

int main() {
    char *password = "admin123";
    printf("%s", password);
    return 0;
}
`},{id:"runtime-error",name:"Runtime Risk",filename:"runtime_risk.c",description:"Division by a zero constant — expect a potential runtime error.",code:`#include <stdio.h>

int main() {
    int a = 10;
    int b = 0;
    printf("%d", a / b);
    return 0;
}
`},{id:"structs-switch",name:"Structs & Switch",filename:"structs_switch.c",description:"Typedef struct, member access and a switch on scores — exercises the extended C subset.",code:`#include <stdio.h>

// A grade record: name buffer plus an integer score.
typedef struct {
    char name[32];
    int score;
} Student;

// Convert a numeric score into a letter grade.
char grade_letter(int score) {
    switch (score / 10) {
        case 9:
        case 10:
            return 'A';
        case 8:
            return 'B';
        case 7:
            return 'C';
        case 6:
            return 'D';
        default:
            return 'F';
    }
}

int main() {
    Student students[3];
    int i;
    for (i = 0; i < 3; i++) {
        students[i].score = 70 + i * 10;
    }
    for (i = 0; i < 3; i++) {
        printf("Score %d -> %c\\n", students[i].score, grade_letter(students[i].score));
    }
    return 0;
}
`}];export{s as B,o as G,d as L,h as S,m as T,u as a};
