import { describe, expect, test } from "bun:test";
import { lexSource } from "../src/convex/analyzer/lexer";
import { parseTokens } from "../src/convex/analyzer/parser";

const parse = (src: string) => {
  const { data } = lexSource(src);
  return parseTokens(data);
};

describe("parser", () => {
  test("parses a valid program into an AST", () => {
    const { ast, findings } = parse(
      "#include <stdio.h>\nint main() { int x = 10; printf(\"%d\", x); return 0; }",
    );
    expect(findings.length).toBe(0);
    expect(ast).not.toBeNull();
    expect(ast!.kind).toBe("Program");
    const body = ast!.body as { kind: string }[];
    expect(body.some((n) => n.kind === "FunctionDeclaration")).toBe(true);
  });

  test("builds rich nodes (function, declaration, call)", () => {
    const { ast } = parse("int add(int a, int b) { return a + b; }");
    const fn = (ast!.body as unknown[])[0] as {
      kind: string;
      name: string;
      params: { kind: string }[];
      body: { kind: string; body: { kind: string }[] };
    };
    expect(fn.kind).toBe("FunctionDeclaration");
    expect(fn.name).toBe("add");
    expect(fn.params.length).toBe(2);
    expect(fn.body.kind).toBe("BlockStatement");
    expect(fn.body.body[0].kind).toBe("ReturnStatement");
  });

  test("reports a missing semicolon on the correct line", () => {
    const src = "int main() {\n  int x = 10\n  printf(\"%d\", x);\n  return 0;\n}";
    const { findings } = parse(src);
    const missing = findings.find((f) => f.rule === "missing-semicolon");
    expect(missing).toBeDefined();
    expect(missing!.line).toBe(2);
    expect(missing!.category).toBe("SYNTAX");
  });

  test("recovers and continues after a missing semicolon", () => {
    const src = "int main() {\n  int x = 10\n  printf(\"%d\", x);\n  return 0;\n}";
    const { ast } = parse(src);
    const fn = (ast?.body as unknown[] | undefined)?.find(
      (n) => (n as { kind: string }).kind === "FunctionDeclaration",
    ) as { body: { kind: string; body: { kind: string }[] } } | undefined;
    // The parser recovered: later statements are still in the tree.
    expect(fn).toBeDefined();
    const stmts = fn.body.body.map((s) => s.kind);
    expect(stmts).toContain("ExpressionStatement");
    expect(stmts).toContain("ReturnStatement");
  });

  test("reports missing closing brace", () => {
    const { findings } = parse("int main() {\n  int x = 10;\n");
    expect(findings.some((f) => f.rule === "missing-brace")).toBe(true);
  });

  test("reports unexpected token / invalid declaration", () => {
    const { findings } = parse("int main() { int 123abc = 5; return 0; }");
    expect(findings.length).toBeGreaterThan(0);
    expect(findings.every((f) => f.category === "SYNTAX")).toBe(true);
  });

  test("reports invalid array declarations", () => {
    const { findings } = parse("int main() { int a[] = {1}; return 0; }");
    expect(findings.some((f) => f.rule === "missing-array-size")).toBe(true);
  });
});
