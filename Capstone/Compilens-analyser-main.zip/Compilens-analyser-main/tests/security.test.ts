import { describe, expect, test } from "bun:test";
import { lexSource } from "../src/convex/analyzer/lexer";
import { parseTokens } from "../src/convex/analyzer/parser";
import { analyzeSecurity } from "../src/convex/analyzer/security";

const analyze = (src: string) => {
  const lexed = lexSource(src);
  const { ast } = parseTokens(lexed.data);
  return analyzeSecurity(ast, lexed.data);
};

describe("security analyzer", () => {
  test("flags hardcoded credentials (CWE-798)", () => {
    const { findings } = analyze(
      '#include <stdio.h>\nint main() { char *password = "admin123"; printf("%s", password); return 0; }',
    );
    const f = findings.find((x) => x.rule === "hardcoded-secret");
    expect(f).toBeDefined();
    expect(f!.cwe).toBe("CWE-798");
    expect(f!.severity).toBe("HIGH");
    expect(f!.line).toBe(2);
    expect(f!.recommendation.length).toBeGreaterThan(10);
  });

  test("flags hardcoded secret in a parameter", () => {
    const { findings } = analyze(
      'int main() { const char *api_key = "sk-123456"; return 0; }',
    );
    expect(findings.some((f) => f.rule === "hardcoded-secret")).toBe(true);
  });

  test("flags gets()", () => {
    const { findings } = analyze(
      'int main() { char b[10]; gets(b); return 0; }',
    );
    const f = findings.find((x) => x.rule === "gets");
    expect(f).toBeDefined();
    expect(f!.severity).toBe("HIGH");
  });

  test("flags strcpy()", () => {
    const { findings } = analyze(
      'int main() { char a[10], b[10]; strcpy(a, b); return 0; }',
    );
    expect(findings.some((f) => f.rule === "strcpy")).toBe(true);
  });

  test("flags strcat()", () => {
    const { findings } = analyze(
      'int main() { char a[10], b[10]; strcat(a, b); return 0; }',
    );
    expect(findings.some((f) => f.rule === "strcat")).toBe(true);
  });

  test("flags sprintf()", () => {
    const { findings } = analyze(
      'int main() { char a[10]; sprintf(a, "%s", "x"); return 0; }',
    );
    expect(findings.some((f) => f.rule === "sprintf")).toBe(true);
  });

  test("flags system()", () => {
    const { findings } = analyze(
      'int main() { system("rm -rf /"); return 0; }',
    );
    const f = findings.find((x) => x.rule === "system");
    expect(f).toBeDefined();
    expect(["HIGH", "CRITICAL"]).toContain(f!.severity);
  });

  test("flags popen()", () => {
    const { findings } = analyze(
      'int main() { FILE *p; p = popen("ls", "r"); return 0; }',
    );
    expect(findings.some((f) => f.rule === "popen")).toBe(true);
  });

  test("flags scanf %s without width", () => {
    const { findings } = analyze(
      'int main() { char b[10]; scanf("%s", b); return 0; }',
    );
    const f = findings.find((x) => x.rule === "unsafe-scanf");
    expect(f).toBeDefined();
  });

  test("does not flag scanf with a width limit", () => {
    const { findings } = analyze(
      'int main() { char b[10]; scanf("%9s", b); return 0; }',
    );
    expect(findings.some((f) => f.rule === "unsafe-scanf")).toBe(false);
  });

  test("flags multiple issues in one program", () => {
    const { findings } = analyze(
      '#include <stdio.h>\nint main() { char buf[10]; gets(buf); char *secret = "abc123"; printf("%s", secret); return 0; }',
    );
    const rules = new Set(findings.map((f) => f.rule));
    expect(rules.has("gets")).toBe(true);
    expect(rules.has("hardcoded-secret")).toBe(true);
  });
});
