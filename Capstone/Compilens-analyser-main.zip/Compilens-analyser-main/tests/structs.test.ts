import { describe, expect, test } from "bun:test";
import { lexSource } from "../src/convex/analyzer/lexer";
import { parseTokens } from "../src/convex/analyzer/parser";
import { analyzeSemantics } from "../src/convex/analyzer/semantic";
import { analyzeRuntime } from "../src/convex/analyzer/runtime";
import { analyzeSecurity } from "../src/convex/analyzer/security";
import { runAnalysisPipeline } from "../src/convex/analyzer/orchestrator";

const parse = (src: string) => {
  const lexed = lexSource(src);
  return parseTokens(lexed.data);
};

const semantics = (src: string) => {
  const lexed = lexSource(src);
  const { ast } = parseTokens(lexed.data);
  return analyzeSemantics(ast);
};

const runtime = (src: string) => {
  const lexed = lexSource(src);
  const { ast } = parseTokens(lexed.data);
  const symbolTable = analyzeSemantics(ast).data;
  return analyzeRuntime(ast, symbolTable);
};

const security = (src: string) => {
  const lexed = lexSource(src);
  const { ast } = parseTokens(lexed.data);
  return analyzeSecurity(ast, lexed.data);
};

describe("parser: structs, typedefs and switch", () => {
  test("parses struct definitions, typedefs and switch statements cleanly", () => {
    const { ast, findings } = parse(`
typedef struct {
    int x;
    int y;
} Point;
struct Node {
    int value;
    struct Node *next;
};
int classify(int v) {
    switch (v) {
        case 0:
            return 1;
        default:
            return 0;
    }
}
`);
    expect(findings.length).toBe(0);
    const kinds = ((ast!.body as { kind: string }[]) ?? []).map((n) => n.kind);
    expect(kinds).toContain("StructDeclaration");
    expect(kinds).toContain("TypedefDeclaration");
    const fn = (ast!.body as { kind: string; body: { kind: string; body: { kind: string }[] } }[]).find(
      (n) => n.kind === "FunctionDeclaration",
    )!;
    const switchStmt = fn.body.body.find((s) => s.kind === "SwitchStatement") as {
      cases: { kind: string; test: { valueType: string } | null; body: { kind: string }[] }[];
    };
    expect(switchStmt).toBeDefined();
    // case 0 + default, in source order
    expect(switchStmt.cases.length).toBe(2);
    expect(switchStmt.cases[0].test!.valueType).toBe("int");
    expect(switchStmt.cases[1].test).toBeNull();
  });

  test("parses member access with '.' and '->' and brace initializers", () => {
    const { findings } = parse(
      "struct P { int x; }; int main() { struct P p = {1}; struct P *q = &p; int a[3] = {1, 2, 3}; p.x = 5; return q->x + (*p).x + a[0]; }",
    );
    expect(findings.length).toBe(0);
  });

  test("supports typedef names as types and structs in parameters", () => {
    const { ast, findings } = parse(
      "typedef int myint; typedef struct { int x; } S; myint add(S s, myint b) { return s.x + b; }",
    );
    expect(findings.length).toBe(0);
    const fn = (ast!.body as { kind: string; params: { type: string }[] }[]).find(
      (n) => n.kind === "FunctionDeclaration",
    )!;
    expect(fn.params[0].type).toBe("struct anon_1");
    expect(fn.params[1].type).toBe("int");
  });

  test("accepts const qualifiers", () => {
    const { findings } = parse("int main() { const char *msg = \"hi\"; const int n = 3; return n; }");
    expect(findings.length).toBe(0);
  });

  test("reports a case label outside a switch", () => {
    const { findings } = parse("int main() { case 1: return 0; }");
    expect(findings.some((f) => f.rule === "invalid-statement")).toBe(true);
  });
});

describe("semantic analyzer: structs, switch, break/continue", () => {
  test("resolves member access and records type symbols", () => {
    const { data, findings } = semantics(
      "typedef struct { int x; int y; } Point; int main() { Point p; p.x = 1; p.y = 2; return p.x + p.y; }",
    );
    expect(findings.length).toBe(0);
    expect(data.some((s) => s.kind === "Type" && s.name === "Point")).toBe(true);
  });

  test("flags unknown struct members", () => {
    const { findings } = semantics("struct P { int x; }; int main() { struct P p; p.y = 1; return 0; }");
    const f = findings.find((x) => x.rule === "invalid-member");
    expect(f).toBeDefined();
    expect(f!.message).toContain("no member named 'y'");
  });

  test("flags '.' used on a pointer and '->' used on a value", () => {
    const dot = semantics("struct P { int x; }; int main() { struct P *p; p.x = 1; return 0; }");
    expect(dot.findings.some((f) => f.rule === "invalid-member-access")).toBe(true);
    const arrow = semantics("struct P { int x; }; int main() { struct P p; p->x = 1; return 0; }");
    expect(arrow.findings.some((f) => f.rule === "invalid-member-access")).toBe(true);
  });

  test("detects struct member type mismatches", () => {
    const { findings } = semantics('typedef struct { int x; } S; int main() { S s; s.x = "oops"; return 0; }');
    expect(findings.some((f) => f.rule === "type-mismatch")).toBe(true);
  });

  test("allows assignment between values of the same struct type", () => {
    const { findings } = semantics("typedef struct { int x; } S; int main() { S a, b; a = b; return 0; }");
    expect(findings.some((f) => f.rule === "type-mismatch")).toBe(false);
  });

  test("detects duplicate struct members and struct redefinition", () => {
    const dup = semantics("struct S { int x; int x; }; int main() { return 0; }");
    expect(dup.findings.some((f) => f.rule === "duplicate-member")).toBe(true);
    const redef = semantics("struct S { int x; }; struct S { int y; }; int main() { return 0; }");
    expect(redef.findings.some((f) => f.rule === "duplicate-type")).toBe(true);
  });

  test("allows forward declarations of struct tags", () => {
    const { findings } = semantics("struct S; struct S { int x; }; int main() { struct S s; return 0; }");
    expect(findings.some((f) => f.rule === "duplicate-type" || f.rule === "duplicate-declaration")).toBe(false);
  });

  test("flags non-constant and non-integer case labels", () => {
    const nonConst = semantics("int main() { int x = 5; switch (x) { case x: return 1; default: return 0; } }");
    expect(nonConst.findings.some((f) => f.rule === "non-constant-case")).toBe(true);
    const badType = semantics(
      'int main() { double d = 1.5; switch (d) { case 1.5: return 1; } return 0; }',
    );
    expect(badType.findings.some((f) => f.rule === "invalid-switch-type")).toBe(true);
  });

  test("flags break/continue outside loops and allows them inside", () => {
    const bareBreak = semantics("int main() { break; return 0; }");
    expect(bareBreak.findings.some((f) => f.rule === "invalid-break")).toBe(true);
    const bareContinue = semantics("int main() { continue; return 0; }");
    expect(bareContinue.findings.some((f) => f.rule === "invalid-continue")).toBe(true);
    const inSwitch = semantics(
      "int main() { int x = 1; switch (x) { case 1: break; default: break; } return 0; }",
    );
    expect(inSwitch.findings.some((f) => f.rule === "invalid-break")).toBe(false);
    const inLoop = semantics("int main() { while (1) { break; } return 0; }");
    expect(inLoop.findings.some((f) => f.rule === "invalid-break")).toBe(false);
  });
});

describe("runtime analyzer: switch and loops", () => {
  test("detects division by zero inside a switch case", () => {
    const { findings } = runtime(
      "int main() { int x = 1; switch (x) { case 1: x = 10 / 0; break; default: x = 0; } return 0; }",
    );
    expect(findings.some((f) => f.rule === "division-by-zero")).toBe(true);
  });

  test("does not flag a for-loop counter as uninitialized", () => {
    const { findings } = runtime("int main() { int i; for (i = 0; i < 3; i++) { } return 0; }");
    expect(findings.some((f) => f.rule === "uninitialized-variable")).toBe(false);
  });

  test("does not flag struct member names as variable reads", () => {
    const { findings } = runtime(
      "typedef struct { int score; } S; int main() { S s; s.score = 5; return s.score; }",
    );
    expect(findings.some((f) => f.rule === "uninitialized-variable")).toBe(false);
  });
});

describe("security analyzer: struct members", () => {
  test("flags a hardcoded credential assigned to a struct member", () => {
    const { findings } = security(
      'typedef struct { char *api_key; } Cred; int main() { Cred c; c.api_key = "sk-123456"; return 0; }',
    );
    const f = findings.find((x) => x.rule === "hardcoded-secret");
    expect(f).toBeDefined();
    expect(f!.cwe).toBe("CWE-798");
  });
});

describe("orchestrator end-to-end: extended subset sample", () => {
  test("structs + switch sample produces no high/critical findings", () => {
    const code = `#include <stdio.h>

typedef struct {
    char name[32];
    int score;
} Student;

char grade_letter(int score) {
    switch (score / 10) {
        case 9:
        case 10:
            return 'A';
        case 8:
            return 'B';
        case 7:
            return 'C';
        case 6:
            return 'D';
        default:
            return 'F';
    }
}

int main() {
    Student students[3];
    int i;
    for (i = 0; i < 3; i++) {
        students[i].score = 70 + i * 10;
    }
    for (i = 0; i < 3; i++) {
        printf("Score %d -> %c\\n", students[i].score, grade_letter(students[i].score));
    }
    return 0;
}
`;
    const r = runAnalysisPipeline({ code, language: "c", filename: "structs_switch.c" });
    expect(r.success).toBe(true);
    expect(r.findings.filter((f) => f.severity === "HIGH" || f.severity === "CRITICAL")).toHaveLength(0);
    expect(r.ast).not.toBeNull();
    expect(r.symbolTable.some((s) => s.kind === "Type" && s.name === "Student")).toBe(true);
  });
});