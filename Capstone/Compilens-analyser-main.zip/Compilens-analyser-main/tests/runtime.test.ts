import { describe, expect, test } from "bun:test";
import { lexSource } from "../src/convex/analyzer/lexer";
import { parseTokens } from "../src/convex/analyzer/parser";
import { analyzeSemantics } from "../src/convex/analyzer/semantic";
import { analyzeRuntime } from "../src/convex/analyzer/runtime";

const analyze = (src: string) => {
  const lexed = lexSource(src);
  const { ast } = parseTokens(lexed.data);
  const symbolTable = analyzeSemantics(ast).data;
  return analyzeRuntime(ast, symbolTable);
};

describe("runtime analyzer", () => {
  test("detects obvious division by zero", () => {
    const { findings } = analyze(
      "#include <stdio.h>\nint main() { int a = 10; int b = 0; printf(\"%d\", a / b); return 0; }",
    );
    const f = findings.find((x) => x.rule === "division-by-zero");
    expect(f).toBeDefined();
    // Dividing by a variable known to hold 0 is MEDIUM; literal 0 is HIGH.
    expect(["HIGH", "MEDIUM"]).toContain(f!.severity);
    expect(f!.message.toLowerCase()).toContain("division");
    expect(f!.line).toBe(2);
  });

  test("does not flag division by a nonzero constant", () => {
    const { findings } = analyze(
      "#include <stdio.h>\nint main() { int a = 10; int b = 2; printf(\"%d\", a / b); return 0; }",
    );
    expect(findings.some((f) => f.rule === "division-by-zero")).toBe(false);
  });

  test("detects array out of bounds access", () => {
    const { findings } = analyze(
      "int main() { int array[5]; array[10] = 5; return 0; }",
    );
    const f = findings.find((x) => x.rule === "array-out-of-bounds");
    expect(f).toBeDefined();
    expect(f!.line).toBe(1);
  });

  test("detects use of uninitialized variable", () => {
    const { findings } = analyze(
      "#include <stdio.h>\nint main() { int x; printf(\"%d\", x); return 0; }",
    );
    const f = findings.find((x) => x.rule === "uninitialized-variable");
    expect(f).toBeDefined();
    expect(f!.line).toBe(2);
  });

  test("detects null pointer dereference", () => {
    const { findings } = analyze(
      "int main() { int *pointer = NULL; *pointer = 10; return 0; }",
    );
    const f = findings.find((x) => x.rule === "null-pointer-dereference");
    expect(f).toBeDefined();
  });

  test("reports when the AST is unusable", () => {
    const { findings, couldNotRun } = analyze("this is @@@ not c at all");
    expect(couldNotRun).toBe(true);
    // The lexer already flags the invalid chars; runtime stays silent.
    expect(findings.some((f) => f.rule === "division-by-zero")).toBe(false);
  });
});
