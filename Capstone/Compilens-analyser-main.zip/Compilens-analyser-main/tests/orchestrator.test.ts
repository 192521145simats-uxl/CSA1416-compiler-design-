import { describe, expect, test } from "bun:test";
import { runAnalysisPipeline } from "../src/convex/analyzer/orchestrator";

const analyze = (code: string, filename = "main.c") =>
  runAnalysisPipeline({ code, language: "c", filename });

describe("orchestrator end-to-end (demo scenarios)", () => {
  test("TEST 1: valid C code produces no major findings", () => {
    const code = `#include <stdio.h>

// Adds two integers safely.
int add(int a, int b) {
    return a + b;
}

int main() {
    int x = 5;
    int y = 7;
    int sum = add(x, y);
    printf("Sum: %d\\n", sum);
    return 0;
}`;
    const r = analyze(code);
    expect(r.success).toBe(true);
    expect(r.findings.filter((f) => f.severity === "HIGH" || f.severity === "CRITICAL")).toHaveLength(0);
    expect(r.tokens.length).toBeGreaterThan(10);
    expect(r.ast).not.toBeNull();
    expect(r.symbolTable.length).toBeGreaterThan(0);
    expect(r.summary.total).toBe(r.findings.length);
    expect(r.metadata.lineCount).toBe(code.split("\n").length);
  });

  test("TEST 2: missing semicolon is caught with the correct line", () => {
    const code = `#include <stdio.h>

int main() {
    int x = 10
    printf("%d", x);
    return 0;
}`;
    const r = analyze(code);
    const f = r.findings.find((x) => x.rule === "missing-semicolon");
    expect(f).toBeDefined();
    expect(f!.line).toBe(4);
    expect(f!.severity).toBe("MEDIUM");
    // security + runtime still ran despite the syntax error
    expect(r.metadata.runtimeCount).toBeGreaterThanOrEqual(0);
  });

  test("TEST 3: type mismatch is a semantic finding", () => {
    const code = `int main() {
    int x;
    x = "hello";
    return 0;
}`;
    const r = analyze(code);
    const f = r.findings.find(
      (x) => x.rule === "type-mismatch" || x.rule === "invalid-assignment",
    );
    expect(f).toBeDefined();
    expect(f!.category).toBe("SEMANTIC");
    expect(f!.line).toBe(3);
  });

  test("TEST 4: hardcoded password is a security finding (CWE-798)", () => {
    const code = `#include <stdio.h>

int main() {
    char *password = "admin123";
    printf("%s", password);
    return 0;
}`;
    const r = analyze(code);
    const f = r.findings.find((x) => x.rule === "hardcoded-secret");
    expect(f).toBeDefined();
    expect(f!.category).toBe("SECURITY");
    expect(f!.cwe).toBe("CWE-798");
    expect(f!.severity).toBe("HIGH");
    expect(f!.line).toBe(4);
  });

  test("TEST 5: division by zero is a potential runtime error", () => {
    const code = `#include <stdio.h>

int main() {
    int a = 10;
    int b = 0;
    printf("%d", a / b);
    return 0;
}`;
    const r = analyze(code);
    const f = r.findings.find((x) => x.rule === "division-by-zero");
    expect(f).toBeDefined();
    expect(f!.category).toBe("RUNTIME");
    // Variable divisor known to hold 0 → MEDIUM; literal 0 → HIGH.
    expect(["HIGH", "MEDIUM"]).toContain(f!.severity);
    expect(f!.line).toBe(6);
    expect(f!.message.toLowerCase()).toContain("potential");
  });

  test("unified finding model includes every field", () => {
    const code = "int main() { char *password = \"admin123\"; return 0; }";
    const r = analyze(code);
    for (const f of r.findings) {
      expect(typeof f.id).toBe("string");
      expect(["LEXICAL", "SYNTAX", "SEMANTIC", "SECURITY", "RUNTIME"]).toContain(f.category);
      expect(typeof f.message).toBe("string");
      expect(["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]).toContain(f.severity);
      expect(typeof f.cwe).toBe("string");
      expect(typeof f.recommendation).toBe("string");
      expect(typeof f.line).toBe("number");
      expect(typeof f.column).toBe("number");
      expect(f.line).toBeGreaterThanOrEqual(0);
    }
    expect(r.summary).toEqual({
      total: r.findings.length,
      critical: r.findings.filter((f) => f.severity === "CRITICAL").length,
      high: r.findings.filter((f) => f.severity === "HIGH").length,
      medium: r.findings.filter((f) => f.severity === "MEDIUM").length,
      low: r.findings.filter((f) => f.severity === "LOW").length,
      info: r.findings.filter((f) => f.severity === "INFO").length,
    });
  });

  test("empty input returns a clean INFO finding, not a crash", () => {
    const r = analyze("");
    expect(r.success).toBe(false);
    expect(r.findings).toHaveLength(1);
    expect(r.findings[0].severity).toBe("INFO");
  });

  test("findings carry correct line numbers and are line-sorted", () => {
    const code = [
      "#include <stdio.h>",
      "int main() {",
      "    char *password = \"admin123\";", // security HIGH line 3
      "    gets(password);", // security HIGH line 4
      "    printf(\"%s\", password);",
      "    return 0;",
      "}",
    ].join("\n");
    const r = analyze(code);
    const lines = r.findings.map((f) => f.line).filter((l) => l > 0);
    const sorted = [...lines].sort((a, b) => a - b);
    expect(lines).toEqual(sorted);
    const secret = r.findings.find((f) => f.rule === "hardcoded-secret")!;
    expect(secret.line).toBe(3);
    const gets = r.findings.find((f) => f.rule === "gets")!;
    expect(gets.line).toBe(4);
  });
});
