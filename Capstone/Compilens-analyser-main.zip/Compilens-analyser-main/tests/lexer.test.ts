import { describe, expect, test } from "bun:test";
import { lexSource } from "../src/convex/analyzer/lexer";

const tokensOf = (src: string) => lexSource(src).data.filter((t) => t.type !== "EOF");
const findingsOf = (src: string) => lexSource(src).findings;

describe("lexer", () => {
  test("recognizes keywords", () => {
    const toks = tokensOf("int main() { return 0; }");
    const values = toks.map((t) => t.value);
    expect(values).toContain("int");
    expect(values).toContain("return");
    expect(toks.find((t) => t.value === "int")!.type).toBe("KEYWORD");
  });

  test("recognizes identifiers", () => {
    const toks = tokensOf("int main() { return 0; }");
    const main = toks.find((t) => t.value === "main");
    expect(main).toBeDefined();
    expect(main!.type).toBe("IDENTIFIER");
    expect(main!.line).toBe(1);
    expect(main!.column).toBeGreaterThan(0);
  });

  test("recognizes integer and float literals", () => {
    const toks = tokensOf("int a = 42; float b = 3.14;");
    expect(toks.find((t) => t.value === "42")!.type).toBe("INTEGER");
    expect(toks.find((t) => t.value === "3.14")!.type).toBe("FLOAT");
  });

  test("recognizes string and char literals", () => {
    const toks = tokensOf('char c = \'x\'; printf("hello");');
    expect(toks.find((t) => t.value === '"hello"')!.type).toBe("STRING");
    expect(toks.find((t) => t.value === "'x'")!.type).toBe("CHAR");
  });

  test("recognizes operators and punctuation with positions", () => {
    const toks = tokensOf("a = b + c; a++; if (a >= b && c != d) return -1;");
    const values = toks.map((t) => t.value);
    for (const op of ["=", "+", "++", ">=", "&&", "!=", "-"]) {
      expect(values).toContain(op);
    }
    const plus = toks.find((t) => t.value === "++")!;
    expect(plus.type).toBe("OPERATOR");
    expect(plus.start).toBeLessThan(plus.end);
    expect(plus.line).toBe(1);
  });

  test("skips comments but keeps track of lines", () => {
    const src = "// line comment\nint x; /* block\ncomment */ int y;";
    const toks = tokensOf(src);
    expect(toks.map((t) => t.value)).not.toContain("//");
    expect(toks.find((t) => t.value === "x")).toBeDefined();
    expect(toks.find((t) => t.value === "y")).toBeDefined();
    // y lives after a multi-line block comment
    expect(toks.find((t) => t.value === "y")!.line).toBe(3);
  });

  test("handles preprocessor directives as a unit", () => {
    const toks = tokensOf("#include <stdio.h>\n#define MAX 10");
    const pp = toks.find((t) => t.type === "PREPROCESSOR");
    expect(pp).toBeDefined();
    expect(pp!.value).toContain("#include");
  });

  test("flags invalid characters", () => {
    const fs = findingsOf("int x = @;");
    expect(fs.some((f) => f.rule === "invalid-character")).toBe(true);
    expect(lexSource("int x = @;").data.some((t) => t.type === "INVALID")).toBe(true);
  });

  test("flags unterminated string", () => {
    const fs = findingsOf('char *s = "abc;');
    expect(fs.some((f) => f.rule === "unterminated-string")).toBe(true);
  });

  test("flags unterminated block comment", () => {
    const fs = findingsOf("int x; /* never closed");
    expect(fs.some((f) => f.rule === "unterminated-comment")).toBe(true);
  });
});
