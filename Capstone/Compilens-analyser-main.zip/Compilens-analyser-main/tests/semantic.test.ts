import { describe, expect, test } from "bun:test";
import { lexSource } from "../src/convex/analyzer/lexer";
import { parseTokens } from "../src/convex/analyzer/parser";
import { analyzeSemantics } from "../src/convex/analyzer/semantic";

const analyze = (src: string) => {
  const { data } = lexSource(src);
  const { ast } = parseTokens(data);
  return analyzeSemantics(ast);
};

describe("semantic analyzer", () => {
  test("builds a symbol table from a clean program", () => {
    const { data } = analyze(
      "#include <stdio.h>\nint global = 5;\nint add(int a, int b) { return a + b; }\nint main() { int local = add(global, 2); return 0; }",
    );
    const names = data.map((s) => s.name);
    expect(names).toContain("global");
    expect(names).toContain("add");
    expect(names).toContain("a");
    expect(names).toContain("b");
    expect(names).toContain("local");
    const add = data.find((s) => s.name === "add")!;
    expect(add.kind).toBe("Function");
    // Function symbols carry their full signature as the type.
    expect(add.type.startsWith("int")).toBe(true);
    expect(add.type).toContain("add");
    const global = data.find((s) => s.name === "global")!;
    expect(global.scope).toBe("global");
    expect(global.initialized).toBe(true);
  });

  test("detects undeclared identifiers", () => {
    const { findings } = analyze("int main() { x = 10; return 0; }");
    const f = findings.find((x) => x.rule === "undeclared-identifier");
    expect(f).toBeDefined();
    expect(f!.message.toLowerCase()).toContain("x");
    expect(f!.line).toBeGreaterThan(0);
  });

  test("detects duplicate declarations", () => {
    const { findings } = analyze("int main() { int x; int x; return 0; }");
    expect(findings.some((f) => f.rule === "duplicate-declaration")).toBe(true);
  });

  test("detects type mismatches in assignment", () => {
    const { findings } = analyze('int main() { int x; x = "hello"; return 0; }');
    expect(
      findings.some((f) => f.rule === "type-mismatch" || f.rule === "invalid-assignment"),
    ).toBe(true);
  });

  test("detects scope errors (variable used outside its scope)", () => {
    const { findings } = analyze(
      "int main() { { int inner = 1; } inner = 2; return 0; }",
    );
    const f = findings.find((x) => x.rule === "undeclared-identifier");
    expect(f).toBeDefined();
    expect(f!.message.toLowerCase()).toContain("inner");
  });

  test("detects unknown function calls", () => {
    const { findings } = analyze("int main() { mystery(1, 2); return 0; }");
    const f = findings.find((x) => x.rule === "undeclared-function");
    expect(f).toBeDefined();
  });

  test("detects wrong argument count", () => {
    const { findings } = analyze(
      "int add(int a, int b) { return a + b; }\nint main() { add(1); return 0; }",
    );
    const f = findings.find((x) => x.rule === "wrong-argument-count");
    expect(f).toBeDefined();
    expect(f!.line).toBe(2);
  });

  test("detects wrong argument types", () => {
    const { findings } = analyze(
      "int add(int a, int b) { return a + b; }\nint main() { add(\"s\", 2); return 0; }",
    );
    expect(findings.some((f) => f.rule === "wrong-argument-type")).toBe(true);
  });

  test("detects invalid return type", () => {
    const { findings } = analyze('int main() { return "oops"; }');
    const f = findings.find((x) => x.rule === "invalid-return-type");
    expect(f).toBeDefined();
  });
});
