import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Braces,
  CheckCircle2,
  ChevronRight,
  FileCode2,
  FlaskConical,
  Gauge,
  GitBranch,
  History,
  Layers,
  ListTree,
  ScanSearch,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Table2,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Logo } from "@/components/Logo";
import {
  AmbientScene,
  GlassBadge,
  GlassCard,
  SeverityBadge,
} from "@/components/Glass";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { SAMPLE_PROGRAMS } from "@/lib/samples";
import type { Severity } from "@/convex/analyzer/types";

const MODULES = [
  {
    icon: Braces,
    title: "Lexical analysis",
    text: "A real lexer tokenizes C into keywords, identifiers, numbers, strings, operators and more — with exact line and column positions, invalid-character and unterminated-literal detection.",
  },
  {
    icon: GitBranch,
    title: "Syntax analysis + AST",
    text: "A recursive-descent parser builds a genuine AST with error recovery — covering structs, typedefs, switch/case, member access and brace initializers, and reporting missing semicolons, braces and parens without giving up on the rest of the file.",
  },
  {
    icon: Table2,
    title: "Semantic analysis",
    text: "A scope-aware analyzer builds a symbol table and catches undeclared identifiers, duplicate declarations, type mismatches, wrong function arguments, invalid struct members and misuse of '.' vs '->'.",
  },
  {
    icon: ShieldAlert,
    title: "Security rules",
    text: "Eight modular rules flag hardcoded credentials (CWE-798), gets(), strcpy/strcat/sprintf, system/popen and unbounded %s scanf — each with severity, CWE and a fix.",
  },
  {
    icon: FlaskConical,
    title: "Runtime risk scan",
    text: "Static checks for division by zero, array out-of-bounds, uninitialized reads and NULL dereferences — honestly labeled as potential, never claimed as executed results.",
  },
  {
    icon: Layers,
    title: "Unified findings",
    text: "Every module emits one finding model (category, rule, line, column, severity, CWE, recommendation), aggregated and sorted by the orchestrator.",
  },
  {
    icon: History,
    title: "History & reports",
    text: "Every run is stored per user and exportable as HTML, JSON or TXT reports built from the real stored results — no placeholders.",
  },
  {
    icon: ScanSearch,
    title: "IDE-style analyzer",
    text: "Syntax-highlighted editor, file upload, jump-to-line from findings, sample programs that flow through the same pipeline as your own code.",
  },
];

const SEVERITIES: { s: Severity; text: string }[] = [
  { s: "CRITICAL", text: "Immediate action required" },
  { s: "HIGH", text: "Exploitable or crash-prone" },
  { s: "MEDIUM", text: "Needs review" },
  { s: "LOW", text: "Best practice" },
  { s: "INFO", text: "Informational" },
];

export default function Landing() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [sampleIdx, setSampleIdx] = useState(0);

  const primaryCta = () =>
    navigate(isAuthenticated ? "/analyzer" : "/auth?returnTo=%2Fanalyzer");

  const sample = SAMPLE_PROGRAMS[sampleIdx];

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <AmbientScene />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 opacity-70 [background-image:radial-gradient(oklch(1_0_0/0.6)_1px,transparent_1px)] [background-size:28px_28px]"
      />

      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-white/50 bg-white/55 backdrop-blur-xl">
        <div className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between px-4">
          <Logo onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} />
          <nav className="hidden items-center gap-1 lg:flex">
            {[
              ["#features", "Features"],
              ["#pipeline", "Pipeline"],
              ["#samples", "Samples"],
            ].map(([href, label]) => (
              <a
                key={href}
                href={href}
                className="rounded-lg px-3.5 py-2 text-sm font-semibold text-slate-600 transition-colors hover:bg-white/80 hover:text-foreground"
              >
                {label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <Button
                onClick={() => navigate("/dashboard")}
                className="cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 font-bold text-white"
              >
                Dashboard
                <ChevronRight className="ml-1 size-4" />
              </Button>
            ) : (
              <>
                <Button
                  variant="ghost"
                  onClick={() => navigate("/auth?mode=signin")}
                  className="cursor-pointer rounded-xl font-semibold text-slate-600 hover:bg-white/80"
                >
                  Sign in
                </Button>
                <Button
                  onClick={() => navigate("/auth?mode=signup")}
                  className="cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 font-bold text-white shadow-[0_10px_26px_-12px_rgba(37,99,235,0.9)] hover:from-sky-400 hover:to-indigo-500"
                >
                  Get started
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative mx-auto w-full max-w-7xl px-4 pb-16 pt-20 sm:pt-24">
        <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <div className="flex flex-wrap items-center gap-2">
                <GlassBadge tone="brand" className="px-3 py-1 text-xs">
                  <Sparkles className="size-3" />
                  Compiler-based analysis
                </GlassBadge>
                <GlassBadge tone="neutral" className="px-3 py-1 text-xs">
                  C language · v1.0
                </GlassBadge>
              </div>
              <h1 className="mt-5 text-4xl font-black leading-[1.08] tracking-tight text-foreground sm:text-6xl">
                Find the bug, the{" "}
                <span className="text-gradient-brand">flaw</span>, and the{" "}
                <span className="text-gradient-brand">vulnerability</span> in your C
                code.
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-600 sm:text-lg">
                A complete static analysis framework for the C language: real lexical
                and syntax analysis, a genuine AST and symbol table, semantic type
                checking, eight security rules and static runtime-risk detection —
                delivered with severity classification, line numbers and
                exportable reports.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Button
                  onClick={primaryCta}
                  size="lg"
                  className="cursor-pointer rounded-2xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 px-8 py-7 text-base font-bold text-white shadow-[0_18px_40px_-16px_rgba(37,99,235,0.9)] hover:from-sky-400 hover:via-blue-500 hover:to-indigo-500"
                >
                  {isAuthenticated ? "Open the analyzer" : "Start analyzing free"}
                  <ArrowRight className="ml-2 size-5" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() =>
                    (window.location.hash = "#pipeline")
                  }
                  className="glass-subtle cursor-pointer rounded-2xl px-6 py-7 text-base font-semibold text-slate-700 hover:bg-white/85"
                >
                  See the pipeline
                </Button>
              </div>
              <p className="mt-4 text-xs text-muted-foreground">
                Accounts with persistent sessions · runs stored per user · HTML /
                JSON / TXT reports from real results.
              </p>
            </motion.div>
          </div>

          {/* Hero code window */}
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.15, duration: 0.5 }}
            className="relative"
          >
            <div className="absolute -inset-4 -z-10 rounded-[2rem] bg-gradient-to-br from-sky-200/50 via-indigo-200/40 to-violet-200/40 blur-2xl" />
            <GlassCard className="overflow-hidden">
              <div className="flex items-center justify-between border-b border-white/60 bg-white/50 px-4 py-2.5">
                <div className="flex items-center gap-1.5">
                  <span className="size-2.5 rounded-full bg-rose-300" />
                  <span className="size-2.5 rounded-full bg-amber-300" />
                  <span className="size-2.5 rounded-full bg-emerald-300" />
                </div>
                <span className="font-mono text-[11px] font-semibold text-slate-400">
                  vulnerable_login.c
                </span>
                <GlassBadge tone="danger" className="text-[10px]">
                  <ShieldAlert className="size-3" />
                  3 findings
                </GlassBadge>
              </div>
              <pre className="scrollbar-thin overflow-x-auto p-5 font-mono text-[12.5px] leading-6 text-slate-600">
                <code>{`#include <stdio.h>

int main() {
    char *password = "admin123";   // CWE-798  HIGH
    char buffer[16];
    gets(buffer);                  // buffer overflow  HIGH
    printf("%s", buffer);
    return 0;
}`}</code>
              </pre>
              <div className="border-t border-white/60 bg-white/50 px-4 py-3">
                <div className="flex flex-wrap items-center gap-2">
                  <SeverityBadge severity="HIGH" />
                  <span className="text-xs font-medium text-slate-600">
                    Hardcoded credential
                  </span>
                  <span className="font-mono text-[11px] text-slate-400">L2</span>
                  <span className="mx-1 text-slate-300">·</span>
                  <SeverityBadge severity="HIGH" />
                  <span className="text-xs font-medium text-slate-600">
                    Unsafe gets()
                  </span>
                  <span className="font-mono text-[11px] text-slate-400">L5</span>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      {/* Feature modules */}
      <section id="features" className="mx-auto w-full max-w-7xl scroll-mt-20 px-4 py-14">
        <div className="text-center">
          <GlassBadge tone="brand" className="px-3 py-1">The engine</GlassBadge>
          <h2 className="mt-4 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
            Eight modules. One finding model.
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-slate-600">
            Each module is real, structured compiler logic — the lexer, parser,
            semantic analyzer, symbol table, security rules and runtime-risk checks
            share one typed pipeline that runs on the backend for every submission.
          </p>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {MODULES.map((m, i) => (
            <motion.div
              key={m.title}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: (i % 4) * 0.06, duration: 0.4 }}
            >
              <GlassCard className="group h-full p-5 transition-transform duration-200 hover:-translate-y-1">
                <div className="flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500/15 to-indigo-500/15 text-primary ring-1 ring-inset ring-blue-200/60 transition group-hover:from-sky-500 group-hover:to-indigo-600 group-hover:text-white">
                  <m.icon className="size-5" />
                </div>
                <h3 className="mt-4 text-[15px] font-bold text-foreground">{m.title}</h3>
                <p className="mt-2 text-[12.5px] leading-relaxed text-slate-600">{m.text}</p>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pipeline */}
      <section id="pipeline" className="mx-auto w-full max-w-7xl scroll-mt-20 px-4 py-14">
        <div className="grid items-start gap-10 lg:grid-cols-[1fr_1.1fr]">
          <div className="lg:sticky lg:top-24">
            <GlassBadge tone="neutral" className="px-3 py-1">How it works</GlassBadge>
            <h2 className="mt-4 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
              Your code, through the whole compiler pipeline.
            </h2>
            <p className="mt-4 max-w-lg text-sm leading-relaxed text-slate-600">
              Paste C, upload a <span className="font-mono">.c</span> file or open a
              sample. The orchestrator runs input validation → lexer → parser →
              AST → semantic analysis → symbol table → security rules → runtime
              scan → aggregation. Results stay in your account for history and
              export.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {SEVERITIES.map(({ s, text }) => (
                <div
                  key={s}
                  className="flex items-center gap-1.5 rounded-full border border-white/70 bg-white/60 py-1 pl-2 pr-3 backdrop-blur"
                >
                  <SeverityBadge severity={s} withDot={false} />
                  <span className="text-[11px] text-slate-600">{text}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="space-y-3">
            {[
              {
                n: "01",
                icon: FileCode2,
                t: "Input validation",
                d: "Empty files, unsupported sizes and file types are rejected with clear messages.",
              },
              {
                n: "02",
                icon: Braces,
                t: "Lexical analysis",
                d: "Every token gets a type, value, line, column and character range. Invalid symbols and unterminated strings/comments are findings.",
              },
              {
                n: "03",
                icon: ListTree,
                t: "Syntax analysis & AST",
                d: "Recursive-descent parsing with recovery builds the abstract syntax tree and reports every recoverable syntax error with a line number.",
              },
              {
                n: "04",
                icon: Table2,
                t: "Semantic analysis & symbol table",
                d: "Scope chains, declarations, types and call signatures are checked; each symbol is recorded with kind, scope and initialization state.",
              },
              {
                n: "05",
                icon: ShieldCheck,
                t: "Security & runtime scans",
                d: "Eight security rules plus static runtime-risk checks (div-by-zero, out-of-bounds, uninitialized reads, NULL deref) — code is never executed.",
              },
              {
                n: "06",
                icon: Gauge,
                t: "Aggregation, history, export",
                d: "All findings collapse into one severity summary, are stored to your history and export as HTML, JSON or TXT.",
              },
            ].map((step, i) => (
              <motion.div
                key={step.n}
                initial={{ opacity: 0, x: 24 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ delay: i * 0.05, duration: 0.35 }}
              >
                <GlassCard className="flex items-start gap-4 p-4">
                  <span className="font-mono text-lg font-black text-blue-200">
                    {step.n}
                  </span>
                  <div className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500/15 to-indigo-500/15 text-primary ring-1 ring-inset ring-blue-200/60">
                    <step.icon className="size-4" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-[14.5px] font-bold text-foreground">
                      {step.t}
                    </h3>
                    <p className="mt-0.5 text-[12.5px] leading-relaxed text-slate-600">
                      {step.d}
                    </p>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Samples */}
      <section id="samples" className="mx-auto w-full max-w-7xl scroll-mt-20 px-4 py-14">
        <div className="text-center">
          <GlassBadge tone="success" className="px-3 py-1">
            <CheckCircle2 className="size-3" />
            Real samples, real pipeline
          </GlassBadge>
          <h2 className="mt-4 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
            Try the demo scenarios
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-slate-600">
            Each sample is plain source code — nothing pre-scored. Open it in the
            analyzer and watch the pipeline produce the expected class of finding.
          </p>
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-[300px_1fr]">
          <div className="space-y-2">
            {SAMPLE_PROGRAMS.map((s, i) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setSampleIdx(i)}
                className={cn(
                  "flex w-full cursor-pointer items-center gap-3 rounded-2xl border px-4 py-3 text-left transition-all",
                  i === sampleIdx
                    ? "border-blue-300/80 bg-white/80 shadow-[0_10px_28px_-16px_rgba(37,99,235,0.5)]"
                    : "border-white/60 bg-white/40 hover:bg-white/70",
                )}
              >
                <span
                  className={cn(
                    "flex size-8 shrink-0 items-center justify-center rounded-lg text-xs font-black",
                    i === sampleIdx
                      ? "bg-gradient-to-br from-sky-500 to-indigo-600 text-white"
                      : "bg-white/80 text-slate-400 ring-1 ring-inset ring-slate-200",
                  )}
                >
                  {i + 1}
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-bold text-foreground">
                    {s.name}
                  </span>
                  <span className="block truncate text-[11.5px] text-muted-foreground">
                    {s.filename} — {s.description}
                  </span>
                </span>
              </button>
            ))}
          </div>

          <motion.div
            key={sample.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
          >
            <GlassCard className="flex h-full flex-col overflow-hidden">
              <div className="flex items-center justify-between border-b border-white/60 bg-white/50 px-4 py-2.5">
                <span className="flex items-center gap-2 font-mono text-xs font-semibold text-slate-500">
                  <FileCode2 className="size-4 text-primary" />
                  {sample.filename}
                </span>
                <Button
                  size="sm"
                  onClick={() => navigate(`/analyzer?sample=${sample.id}`)}
                  className="cursor-pointer rounded-lg bg-gradient-to-r from-sky-500 to-indigo-600 text-xs font-bold text-white"
                >
                  Open in analyzer
                  <ArrowRight className="ml-1.5 size-3.5" />
                </Button>
              </div>
              <pre className="scrollbar-thin flex-1 overflow-auto p-5 font-mono text-[13px] leading-6 text-slate-600">
                {sample.code}
              </pre>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto w-full max-w-5xl px-4 py-16">
        <GlassCard className="relative overflow-hidden p-10 text-center sm:p-14">
          <div
            aria-hidden
            className="pointer-events-none absolute -right-24 -top-24 size-72 rounded-full bg-gradient-to-br from-sky-300/50 to-indigo-400/40 blur-3xl"
          />
          <div
            aria-hidden
            className="pointer-events-none absolute -bottom-28 -left-24 size-72 rounded-full bg-gradient-to-tr from-cyan-200/60 to-violet-300/40 blur-3xl"
          />
          <h2 className="text-3xl font-black tracking-tight text-foreground sm:text-4xl">
            Analyze your first C program.
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-slate-600 sm:text-base">
            Clean syntax, hidden type bugs, hardcoded secrets and crash risks — the
            analyzer tells you what each one is, why it matters, and how to fix it.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button
              size="lg"
              onClick={primaryCta}
              className="cursor-pointer rounded-2xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 px-8 py-7 text-base font-bold text-white shadow-[0_18px_40px_-16px_rgba(37,99,235,0.9)] hover:from-sky-400 hover:to-indigo-500"
            >
              {isAuthenticated ? "Open the analyzer" : "Create free account"}
              <ArrowRight className="ml-2 size-5" />
            </Button>
          </div>
        </GlassCard>
      </section>

      <footer className="border-t border-white/50 bg-white/40 backdrop-blur">
        <div className="mx-auto flex w-full max-w-7xl flex-col items-center justify-between gap-4 px-4 py-8 text-center sm:flex-row sm:text-left">
          <div className="flex flex-col items-center gap-1 sm:items-start">
            <Logo compact />
            <p className="text-[11.5px] text-muted-foreground">
              Compiler-based secure source code analysis framework — C subset v1.1 (types, control flow, structs, typedefs, switch, member access).
            </p>
          </div>
          <p className="text-[11.5px] text-muted-foreground">
            Static analysis only · code is never executed · findings include
            severity, line numbers and recommendations.
          </p>
        </div>
      </footer>
    </div>
  );
}
