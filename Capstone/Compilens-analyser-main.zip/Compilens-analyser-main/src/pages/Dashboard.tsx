import { useQuery } from "convex/react";
import { useNavigate } from "react-router";
import {
  ArrowRight,
  FileCode2,
  FileWarning,
  FlaskConical,
  ShieldAlert,
  Sparkles,
} from "lucide-react";
import { api } from "@/convex/_generated/api";
import { useAuth } from "@/hooks/use-auth";
import { GlassCard, GlassBadge } from "@/components/Glass";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

function StatCard({
  label,
  value,
  icon: Icon,
  accent,
  delay,
}: {
  label: string;
  value: number;
  icon: typeof FileCode2;
  accent: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.35 }}
    >
      <GlassCard className="flex items-center gap-4 p-4">
        <div
          className={cn(
            "flex size-11 shrink-0 items-center justify-center rounded-xl text-white shadow-md",
            accent,
          )}
        >
          <Icon className="size-5" />
        </div>
        <div className="min-w-0">
          <p className="text-2xl font-bold leading-tight text-foreground tabular">
            {value}
          </p>
          <p className="truncate text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            {label}
          </p>
        </div>
      </GlassCard>
    </motion.div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const stats = useQuery(api.analyses.getDashboardStats);

  const firstName = (user?.name ?? "").trim().split(" ")[0] || "there";

  const cards = [
    {
      label: "Total Analyses",
      value: stats?.totalAnalyses ?? 0,
      icon: FileCode2,
      accent: "bg-gradient-to-br from-sky-500 to-blue-600",
    },
    {
      label: "Total Findings",
      value: stats?.totalFindings ?? 0,
      icon: FileWarning,
      accent: "bg-gradient-to-br from-slate-500 to-slate-700",
    },
    {
      label: "Critical Findings",
      value: stats?.critical ?? 0,
      icon: ShieldAlert,
      accent: "bg-gradient-to-br from-rose-500 to-red-600",
    },
    {
      label: "High Findings",
      value: stats?.high ?? 0,
      icon: FlaskConical,
      accent: "bg-gradient-to-br from-orange-400 to-amber-600",
    },
  ];

  const recent = stats?.recent ?? [];

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Welcome back, {firstName} <span className="align-middle">👋</span>
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Compiler-based secure source code analysis for C — syntax, semantic,
            security and runtime risk in one pipeline.
          </p>
        </div>
        <Button
          onClick={() => navigate("/analyzer")}
          className="cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 px-6 py-6 font-bold text-white shadow-[0_12px_28px_-12px_rgba(37,99,235,0.8)] hover:from-sky-400 hover:via-blue-500 hover:to-indigo-500"
        >
          <Sparkles className="size-4" />
          Open Analyzer
          <ArrowRight className="size-4" />
        </Button>
      </motion.section>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((card, i) => (
          <StatCard key={card.label} {...card} delay={0.05 * i} />
        ))}
      </div>

      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
      >
        <GlassCard className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/60 px-5 py-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-foreground">
              Recent analyses
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/history")}
              className="cursor-pointer rounded-lg text-xs font-semibold text-primary hover:bg-blue-50"
            >
              View all
              <ArrowRight className="ml-1 size-3.5" />
            </Button>
          </div>
          {stats === undefined ? (
            <div className="space-y-2 p-5">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-14 animate-pulse rounded-xl bg-slate-200/50" />
              ))}
            </div>
          ) : recent.length === 0 ? (
            <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
              <div className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-500/15 to-indigo-500/15 ring-1 ring-inset ring-blue-200/60">
                <FileCode2 className="size-7 text-primary" />
              </div>
              <div>
                <p className="text-sm font-bold text-foreground">No analyses yet</p>
                <p className="mt-1 max-w-sm text-[13px] text-muted-foreground">
                  Run your first analysis — paste C code, upload a .c file, or start
                  from a sample program.
                </p>
              </div>
              <Button
                onClick={() => navigate("/analyzer")}
                className="cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 font-semibold text-white"
              >
                Analyze your first program
              </Button>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100/80">
              {recent.map((row) => (
                <li key={row.id}>
                  <button
                    type="button"
                    onClick={() => navigate("/history", { state: { openAnalysis: row.id } })}
                    className="flex w-full cursor-pointer items-center gap-4 px-5 py-3.5 text-left transition-colors hover:bg-blue-50/40"
                  >
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-blue-100/70 text-primary">
                      <FileCode2 className="size-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-mono text-[13.5px] font-semibold text-foreground">
                        {row.filename}
                      </span>
                      <span className="block text-xs text-muted-foreground">
                        {new Date(row.createdAt).toLocaleString()}
                      </span>
                    </span>
                    <span className="hidden shrink-0 gap-1.5 sm:flex">
                      {row.summary.high > 0 && (
                        <GlassBadge tone="danger">{row.summary.high} high</GlassBadge>
                      )}
                      {row.summary.medium > 0 && (
                        <GlassBadge tone="warning">{row.summary.medium} med</GlassBadge>
                      )}
                      {row.summary.critical > 0 && (
                        <GlassBadge tone="danger">{row.summary.critical} crit</GlassBadge>
                      )}
                      {row.summary.total === 0 && (
                        <GlassBadge tone="success">clean</GlassBadge>
                      )}
                    </span>
                    <ArrowRight className="size-4 shrink-0 text-slate-300" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </GlassCard>
      </motion.section>
    </div>
  );
}
