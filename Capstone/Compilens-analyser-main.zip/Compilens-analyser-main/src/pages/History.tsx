import { useMemo, useState } from "react";
import { useLocation } from "react-router";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { toast } from "sonner";
import {
  Download,
  Eye,
  FileCode2,
  Loader2,
  Search,
  Trash2,
} from "lucide-react";
import { GlassCard, GlassBadge } from "@/components/Glass";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { AnalysisResult } from "@/convex/analyzer/types";
import { FindingsView, OverviewView } from "@/components/analysis-views";
import {
  buildHtmlReport,
  buildJsonReport,
  buildTxtReport,
  downloadReport,
  type ReportFormat,
} from "@/lib/reports";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import type { Id } from "@/convex/_generated/dataModel";

type AnalysisId = Id<"analyses">;

function formatWhen(ts: number): string {
  const d = new Date(ts);
  const today = new Date();
  const sameDay =
    d.getFullYear() === today.getFullYear() &&
    d.getMonth() === today.getMonth() &&
    d.getDate() === today.getDate();
  return sameDay
    ? `Today, ${d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
    : d.toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
}

export default function History() {
  const { user } = useAuth();
  const rows = useQuery(api.analyses.listAnalyses);
  const deleteAnalysis = useMutation(api.analyses.deleteAnalysis);
  const location = useLocation();
  const [query, setQuery] = useState("");
  const [deleteId, setDeleteId] = useState<AnalysisId | null>(null);
  const [viewId, setViewId] = useState<AnalysisId | null>(
    ((location.state as { openAnalysis?: AnalysisId } | null)?.openAnalysis as
      | AnalysisId
      | null) ?? null,
  );
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    if (!rows) return undefined;
    if (!query.trim()) return rows;
    const q = query.toLowerCase();
    return rows.filter(
      (r) =>
        r.filename.toLowerCase().includes(q) ||
        r.summary.total.toString().includes(q),
    );
  }, [rows, query]);

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    try {
      await deleteAnalysis({ id: deleteId });
      toast.success("Analysis deleted");
      setDeleteId(null);
    } catch (error) {
      toast.error("Delete failed", {
        description: error instanceof Error ? error.message : "Unknown error",
      });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Analysis history
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Every analysis run by <span className="font-semibold">{user?.email}</span>{" "}
            — only your own runs are shown.
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter by filename…"
            className="glass-subtle h-10 pl-9"
          />
        </div>
      </div>

      <GlassCard className="overflow-hidden">
        {filtered === undefined ? (
          <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
            <Loader2 className="size-5 animate-spin" />
            Loading history…
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 px-6 py-16 text-center">
            <FileCode2 className="size-10 text-slate-300" />
            <p className="text-sm font-semibold text-foreground">
              {rows?.length ? "No matching analyses" : "No analyses yet"}
            </p>
            <p className="max-w-sm text-[13px] text-muted-foreground">
              Run analyses in the analyzer to build up your history.
            </p>
          </div>
        ) : (
          <div className="scrollbar-thin overflow-x-auto">
            <table className="w-full min-w-[820px] border-collapse">
              <thead>
                <tr className="border-b border-slate-200/80 bg-white/50 text-left">
                  <th className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    File
                  </th>
                  <th className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    Analyzed
                  </th>
                  <th className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    Findings
                  </th>
                  <th className="px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    Size
                  </th>
                  <th className="px-4 py-2.5 text-right text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((row) => (
                  <tr
                    key={row.id}
                    className="border-b border-slate-100 transition-colors hover:bg-blue-50/30"
                  >
                    <td className="px-4 py-3">
                      <span className="flex items-center gap-2.5">
                        <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-blue-100/70 text-primary">
                          <FileCode2 className="size-4" />
                        </span>
                        <span className="min-w-0">
                          <span className="block max-w-[220px] truncate font-mono text-[13px] font-semibold text-foreground">
                            {row.filename}
                          </span>
                          <span className="text-[11px] text-muted-foreground">
                            {row.language.toUpperCase()} ·{" "}
                            {row.metadata.tokenCount} tokens
                          </span>
                        </span>
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[12.5px] text-slate-600">
                      {formatWhen(row.createdAt)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {row.summary.total === 0 ? (
                          <GlassBadge tone="success">clean</GlassBadge>
                        ) : (
                          <>
                            {row.summary.critical > 0 && (
                              <GlassBadge tone="danger">{row.summary.critical} crit</GlassBadge>
                            )}
                            {row.summary.high > 0 && (
                              <GlassBadge tone="danger">{row.summary.high} high</GlassBadge>
                            )}
                            {row.summary.medium > 0 && (
                              <GlassBadge tone="warning">{row.summary.medium} med</GlassBadge>
                            )}
                            {row.summary.low > 0 && (
                              <GlassBadge tone="brand">{row.summary.low} low</GlassBadge>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono text-[12px] text-slate-500 tabular">
                      {row.lineCount} lines
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="cursor-pointer rounded-lg text-slate-600 hover:bg-blue-50 hover:text-primary"
                          onClick={() => setViewId(row.id)}
                        >
                          <Eye className="mr-1 size-3.5" /> View
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="cursor-pointer rounded-lg text-rose-600 hover:bg-rose-50"
                          onClick={() => setDeleteId(row.id)}
                        >
                          <Trash2 className="mr-1 size-3.5" /> Delete
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>

      {viewId && (
        <HistoryDetailDialog id={viewId} onClose={() => setViewId(null)} />
      )}

      <AlertDialog
        open={deleteId !== null}
        onOpenChange={(open) => !open && setDeleteId(null)}
      >
        <AlertDialogContent className="glass">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this analysis?</AlertDialogTitle>
            <AlertDialogDescription>
              The stored findings, tokens, AST and report data for this run will be
              permanently removed. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting} className="cursor-pointer">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleDelete();
              }}
              disabled={deleting}
              className="cursor-pointer bg-rose-600 text-white hover:bg-rose-500"
            >
              {deleting && <Loader2 className="mr-2 size-4 animate-spin" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Detail dialog                                                       */
/* ------------------------------------------------------------------ */

function HistoryDetailDialog({ id, onClose }: { id: AnalysisId; onClose: () => void }) {
  const profile = useQuery(api.analyses.getProfile);
  const detail = useQuery(api.analyses.getAnalysis, { id });
  const [mode, setMode] = useState<"overview" | "findings">(
    "overview" as const,
  );

  const result: AnalysisResult | null = useMemo(() => {
    if (!detail) return null;
    return {
      success: true,
      language: detail.language,
      filename: detail.filename,
      tokens: (detail.tokens ?? []) as AnalysisResult["tokens"],
      ast: (detail.ast ?? null) as AnalysisResult["ast"],
      symbolTable: (detail.symbolTable ?? []) as AnalysisResult["symbolTable"],
      findings: (detail.findings ?? []) as AnalysisResult["findings"],
      summary: detail.summary,
      metadata: detail.metadata,
      notes: detail.notes ?? [],
    };
  }, [detail]);

  const exportReport = (format: ReportFormat) => {
    if (!detail || !result) return;
    const input = {
      projectName: profile?.fullName
        ? `${profile.fullName} workspace`
        : "Secure Code Analyzer",
      filename: detail.filename,
      language: detail.language,
      sourceCode: detail.sourceCode,
      createdAt: detail.createdAt,
      result,
    };
    const content =
      format === "json"
        ? buildJsonReport(input)
        : format === "html"
          ? buildHtmlReport(input)
          : buildTxtReport(input);
    downloadReport(content, format, detail.filename);
    toast.success(`Report exported as .${format}`);
  };

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="glass max-h-[85vh] overflow-y-auto sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-mono text-lg">
            <FileCode2 className="size-5 text-primary" />
            {detail?.filename ?? "Loading…"}
          </DialogTitle>
          <DialogDescription>
            {detail
              ? `Analyzed ${new Date(detail.createdAt).toLocaleString()} · ${detail.summary.total} finding${detail.summary.total === 1 ? "" : "s"}`
              : "Fetching stored analysis…"}
          </DialogDescription>
        </DialogHeader>

        {!result ? (
          <div className="flex items-center justify-center gap-2 py-12 text-muted-foreground">
            <Loader2 className="size-5 animate-spin" />
            Loading analysis…
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-2 border-y border-slate-200/70 bg-white/40 py-2 pl-1 pr-2">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setMode("overview")}
                  className={cn(
                    "cursor-pointer rounded-lg px-3 py-1.5 text-[12.5px] font-semibold",
                    mode === "overview"
                      ? "bg-blue-100/80 text-primary"
                      : "text-slate-500 hover:bg-white/70",
                  )}
                >
                  Summary
                </button>
                <button
                  type="button"
                  onClick={() => setMode("findings")}
                  className={cn(
                    "cursor-pointer rounded-lg px-3 py-1.5 text-[12.5px] font-semibold",
                    mode === "findings"
                      ? "bg-blue-100/80 text-primary"
                      : "text-slate-500 hover:bg-white/70",
                  )}
                >
                  Findings ({result.findings.length})
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                {(["html", "json", "txt"] as ReportFormat[]).map((f) => (
                  <Button
                    key={f}
                    size="sm"
                    variant="outline"
                    className="cursor-pointer rounded-lg"
                    onClick={() => exportReport(f)}
                  >
                    <Download className="mr-1 size-3.5" />
                    {f.toUpperCase()}
                  </Button>
                ))}
              </div>
            </div>

            {mode === "overview" ? (
              <OverviewView result={result} />
            ) : (
              <div className="max-h-[52vh] overflow-auto">
                <FindingsView findings={result.findings} />
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
