import { motion } from "framer-motion";
import { useNavigate } from "react-router";
import { ArrowLeft } from "lucide-react";
import { AmbientScene, GlassCard } from "@/components/Glass";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <AmbientScene />
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <GlassCard className="max-w-md p-10 text-center">
          <p className="font-mono text-6xl font-black text-gradient-brand">404</p>
          <h1 className="mt-3 text-xl font-bold text-foreground">
            This route does not exist
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            The page you are looking for was not found — maybe it was optimized out
            of existence.
          </p>
          <Button
            onClick={() => navigate("/")}
            className="mt-6 cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 font-bold text-white"
          >
            <ArrowLeft className="mr-2 size-4" />
            Back to home
          </Button>
        </GlassCard>
      </motion.div>
    </div>
  );
}
