import { useState } from "react";
import { useNavigate } from "react-router";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { toast } from "sonner";
import {
  FlaskConical,
  KeyRound,
  Loader2,
  LogOut,
  RefreshCw,
  Settings2,
  ShieldCheck,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { GlassCard, GlassBadge } from "@/components/Glass";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

export default function Settings() {
  const { user, isAuthenticated, signOut } = useAuth();
  const stats = useQuery(api.analyses.getDashboardStats);
  const navigate = useNavigate();
  const [signingOut, setSigningOut] = useState(false);
  const [hideInfo, setHideInfo] = useState(true);

  if (!isAuthenticated) return null;

  const handleSignOut = async () => {
    setSigningOut(true);
    try {
      await signOut();
      navigate("/");
    } catch (error) {
      toast.error("Sign out failed", {
        description: error instanceof Error ? error.message : "Unknown error",
      });
      setSigningOut(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Preferences and session management for this workspace.
        </p>
      </div>

      <GlassCard className="p-6">
        <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-foreground">
          <Settings2 className="size-4 text-primary" />
          Analyzer preferences
        </h3>
        <div className="mt-4 space-y-4">
          <div className="flex items-center justify-between gap-4 rounded-xl border border-slate-200/70 bg-white/50 px-4 py-3">
            <div>
              <p className="text-sm font-semibold text-foreground">
                Hide INFO findings
              </p>
              <p className="text-xs text-muted-foreground">
                Collapse low-signal informational findings in result views.
              </p>
            </div>
            <Switch
              checked={hideInfo}
              onCheckedChange={setHideInfo}
              aria-label="Hide INFO findings"
            />
          </div>
          <p className="text-xs text-muted-foreground">
            INFO findings (for example empty-source warnings) are rare; everything
            else is always shown. Findings are computed server-side on every run.
          </p>
        </div>
      </GlassCard>

      <GlassCard className="p-6">
        <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-foreground">
          <KeyRound className="size-4 text-primary" />
          Session & account
        </h3>
        <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
          <div className="rounded-xl border border-slate-200/70 bg-white/50 px-4 py-3">
            <dt className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Signed in as
            </dt>
            <dd className="mt-1 truncate font-semibold text-foreground">
              {user?.email ?? user?.name ?? "Authenticated user"}
            </dd>
          </div>
          <div className="rounded-xl border border-slate-200/70 bg-white/50 px-4 py-3">
            <dt className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Stored analyses
            </dt>
            <dd className="mt-1 font-semibold text-foreground tabular">
              {stats?.totalAnalyses ?? "…"}
            </dd>
          </div>
        </dl>

        <div className="mt-5 space-y-3">
          <div className="flex items-start gap-3 rounded-xl border border-emerald-200/70 bg-emerald-50/60 px-4 py-3">
            <ShieldCheck className="mt-0.5 size-4 shrink-0 text-emerald-600" />
            <div>
              <p className="text-sm font-semibold text-emerald-800">
                Data isolation is enforced server-side
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-emerald-700/90">
                Every query and mutation filters by your authenticated user id, so
                analyses and reports are only ever visible to the account that
                created them.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-xl border border-amber-200/70 bg-amber-50/60 px-4 py-3">
            <FlaskConical className="mt-0.5 size-4 shrink-0 text-amber-600" />
            <div>
              <p className="text-sm font-semibold text-amber-800">
                Controlled execution is unavailable
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-amber-700/90">
                No sandboxed C runtime exists in this environment, so the analyzer
                performs static runtime-risk analysis only. Findings are labeled
                as <em>potential</em> and code is never executed.
              </p>
            </div>
          </div>
        </div>
      </GlassCard>

      <GlassCard className="border-rose-200/70 p-6">
        <h3 className="text-sm font-bold uppercase tracking-wider text-rose-700">
          Danger zone
        </h3>
        <div className="mt-4 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
          <div>
            <p className="text-sm font-semibold text-foreground">Sign out</p>
            <p className="text-xs text-muted-foreground">
              Ends this session. Your analyses stay stored and are restored when you
              sign back in.
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="cursor-pointer rounded-xl"
              onClick={() => window.location.reload()}
            >
              <RefreshCw className="mr-2 size-4" />
              Refresh session
            </Button>
            <Button
              onClick={handleSignOut}
              disabled={signingOut}
              className="cursor-pointer rounded-xl bg-rose-600 font-semibold text-white hover:bg-rose-500"
            >
              {signingOut ? (
                <Loader2 className="mr-2 size-4 animate-spin" />
              ) : (
                <LogOut className="mr-2 size-4" />
              )}
              Sign out
            </Button>
          </div>
        </div>
      </GlassCard>

      <div className="flex flex-wrap items-center gap-2">
        <GlassBadge tone="brand">secure-code-analyzer v1.0</GlassBadge>
        <GlassBadge tone="neutral">C language subset</GlassBadge>
      </div>
    </div>
  );
}
