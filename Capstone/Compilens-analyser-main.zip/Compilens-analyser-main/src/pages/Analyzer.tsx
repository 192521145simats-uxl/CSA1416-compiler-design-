import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { useSearchParams } from "react-router";
import { api } from "@/convex/_generated/api";
import { toast } from "sonner";
import {
  AlertTriangle,
  Braces,
  CheckCircle2,
  FileCode2,
  FileUp,
  FlaskConical,
  GitBranch,
  ListTree,
  Loader2,
  Play,
  ScanSearch,
  ShieldCheck,
  Table2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { AnalysisResult } from "@/convex/analyzer/types";
import { SAMPLE_PROGRAMS } from "@/lib/samples";
import {
  CodeEditor,
  type EditorHandle,
} from "@/components/CodeEditor";
import {
  AstView,
  CategoryFindingsView,
  FindingsView,
  OverviewView,
  ReportView,
  SymbolsView,
  TokensView,
} from "@/components/analysis-views";
import { GlassCard, SeverityBadge } from "@/components/Glass";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const MAX_CODE_LENGTH = 60_000;

type TabId =
  | "overview"
  | "findings"
  | "tokens"
  | "ast"
  | "symbols"
  | "security"
  | "runtime"
  | "report";

interface AnalysisRun {
  analysisId: string;
  result: AnalysisResult;
}

const PHASE_STEPS = [
  { label: "Lexical analysis", icon: Braces },
  { label: "Syntax analysis / AST", icon: ListTree },
  { label: "Semantic analysis", icon: Table2 },
  { label: "Security scan", icon: ShieldCheck },
  { label: "Runtime risk scan", icon: FlaskConical },
];

export default function Analyzer() {
  const profile = useQuery(api.analyses.getProfile);
  const runAnalysis = useMutation(api.analyses.runAnalysis);
  const [searchParams] = useSearchParams();

  // Deep links (e.g. /analyzer?sample=runtime-error) preselect a sample once.
  const initialSample = useMemo(
    () =>
      SAMPLE_PROGRAMS.find((s) => s.id === searchParams.get("sample")) ??
      SAMPLE_PROGRAMS[0],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );
  const [code, setCode] = useState<string>(initialSample.code);
  const [filename, setFilename] = useState<string>(initialSample.filename);
  const [fileLabel, setFileLabel] = useState<string>(`sample:${initialSample.id}`);
  const [analyzing, setAnalyzing] = useState(false);
  const [run, setRun] = useState<AnalysisRun | null>(null);
  const [tab, setTab] = useState<TabId>("overview");
  const [phaseIdx, setPhaseIdx] = useState(0);
  const editorRef = useRef<EditorHandle>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const result = run?.result ?? null;
  const findings = result?.findings ?? [];

  // Animated pipeline progress while the mutation runs on the backend.
  useEffect(() => {
    if (!analyzing) return;
    setPhaseIdx(0);
    const timer = window.setInterval(() => {
      setPhaseIdx((i) => {
        if (i >= PHASE_STEPS.length) return i; // hold on last step
        return i + 1;
      });
    }, 110);
    return () => window.clearInterval(timer);
  }, [analyzing]);

  const loadSample = (sampleId: string) => {
    const sample = SAMPLE_PROGRAMS.find((s) => s.id === sampleId);
    if (!sample) return;
    setCode(sample.code);
    setFilename(sample.filename);
    setFileLabel(`sample:${sample.id}`);
    setRun(null);
  };

  const handleUpload = (file: File | undefined) => {
    if (!file) return;
    const name = file.name || "upload.c";
    if (!name.toLowerCase().endsWith(".c")) {
      toast.error("Invalid file type", {
        description: "Only .c source files can be analyzed.",
      });
      return;
    }
    if (file.size > MAX_CODE_LENGTH) {
      toast.error("File too large", {
        description: "Keep C files under 60 KB for analysis.",
      });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const content = String(reader.result ?? "");
      if (!content.trim()) {
        toast.error("Empty file", {
          description: "The uploaded file contains no source code.",
        });
        return;
      }
      setCode(content);
      setFilename(name);
      setFileLabel(`upload:${name}`);
      setRun(null);
      toast.success(`Loaded ${name}`);
    };
    reader.readAsText(file);
  };

  const handleAnalyze = useCallback(async () => {
    if (!code.trim()) {
      toast.error("Nothing to analyze", {
        description: "Paste C source code or load a sample first.",
      });
      return;
    }
    if (code.length > MAX_CODE_LENGTH) {
      toast.error("Source too large", {
        description: "Keep files under 60 KB for analysis.",
      });
      return;
    }
    setAnalyzing(true);
    setRun(null);
    try {
      const res = await runAnalysis({
        code,
        language: "c",
        filename: filename || "main.c",
      });
      setRun({ analysisId: res.analysisId, result: res.result });
      setTab(res.result.findings.length > 0 ? "findings" : "overview");
      const s = res.result.summary;
      toast.success(
        s.total === 0
          ? "Clean program — no findings"
          : `Analysis complete — ${s.total} finding${s.total === 1 ? "" : "s"}`,
        {
          description: `${s.high} high · ${s.medium} medium · ${s.low} low`,
        },
      );
    } catch (error) {
      console.error("Analysis failed:", error);
      toast.error("Analysis failed", {
        description:
          error instanceof Error ? error.message : "Unknown server error.",
      });
    } finally {
      setAnalyzing(false);
    }
  }, [code, filename, runAnalysis]);

  const jumpToLine = useCallback((line: number) => {
    editorRef.current?.focusLine(line);
  }, []);

  const counts: Record<string, number> = {
    findings: findings.length,
    tokens: result?.tokens.length ?? 0,
    symbols: result?.symbolTable.length ?? 0,
    security: findings.filter((f) => f.category === "SECURITY").length,
    runtime: findings.filter((f) => f.category === "RUNTIME").length,
  };

  const tabs: { id: TabId; label: string; count?: number; badge?: "high" | "ok" }[] = [
    { id: "overview", label: "Overview" },
    { id: "findings", label: "Findings", count: counts.findings, badge: counts.findings > 0 ? "high" : "ok" },
    { id: "tokens", label: "Tokens", count: counts.tokens },
    { id: "ast", label: "AST" },
    { id: "symbols", label: "Symbol Table", count: counts.symbols },
    { id: "security", label: "Security", count: counts.security, badge: counts.security > 0 ? "high" : "ok" },
    { id: "runtime", label: "Runtime", count: counts.runtime, badge: counts.runtime > 0 ? "high" : "ok" },
    { id: "report", label: "Report" },
  ];

  return (
    <div className="flex h-[calc(100dvh-6.5rem)] min-h-[560px] flex-col gap-3">
      {/* Summary rail content pulled inline for the IDE chrome */}
      <GlassCard className="flex items-center justify-between gap-3 px-4 py-2.5">
        <div className="flex min-w-0 items-center gap-3">
          <ScanSearch className="size-5 shrink-0 text-primary" />
          <p className="truncate text-sm font-semibold text-foreground">
            Static analysis pipeline
          </p>
          <p className="hidden truncate text-xs text-muted-foreground lg:block">
            {filename} · {code.split("\n").length} lines · {code.length} chars
          </p>
        </div>
        <div className="flex items-center gap-3">
          {result ? (
            <div className="hidden items-center gap-2 sm:flex">
              <SeverityBadge severity="CRITICAL" />
              <span className="text-xs font-bold text-slate-700 tabular">
                {result.summary.critical}
              </span>
              <SeverityBadge severity="HIGH" />
              <span className="text-xs font-bold text-slate-700 tabular">
                {result.summary.high}
              </span>
              <SeverityBadge severity="MEDIUM" />
              <span className="text-xs font-bold text-slate-700 tabular">
                {result.summary.medium}
              </span>
            </div>
          ) : (
            <span className="hidden text-xs text-muted-foreground sm:block">
              Run an analysis to see severity totals
            </span>
          )}
          <Button
            onClick={handleAnalyze}
            disabled={analyzing}
            className="cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 font-bold text-white shadow-[0_10px_24px_-10px_rgba(37,99,235,0.7)] hover:from-sky-400 hover:via-blue-500 hover:to-indigo-500"
          >
            {analyzing ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Play className="size-4 fill-current" />
            )}
            {analyzing ? "Analyzing…" : "Analyze Code"}
          </Button>
        </div>
      </GlassCard>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[210px_minmax(0,1fr)_235px]">
        {/* -------- Explorer -------- */}
        <GlassCard className="hidden min-h-0 flex-col overflow-hidden xl:flex">
          <div className="flex items-center justify-between border-b border-white/60 px-3 py-2">
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Project explorer
            </p>
            <Button
              variant="ghost"
              size="icon"
              className="size-6 cursor-pointer rounded-md"
              onClick={() => fileInputRef.current?.click()}
              aria-label="Upload .c file"
            >
              <FileUp className="size-3.5" />
            </Button>
          </div>
          <div className="scrollbar-thin min-h-0 flex-1 overflow-auto p-2">
            <p className="px-1.5 pb-1 pt-1 text-[10px] font-bold uppercase tracking-widest text-slate-400">
              Samples
            </p>
            <div className="space-y-1">
              {SAMPLE_PROGRAMS.map((sample) => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => loadSample(sample.id)}
                  title={sample.description}
                  className={cn(
                    "flex w-full cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[12.5px] font-medium transition-colors",
                    fileLabel === `sample:${sample.id}`
                      ? "bg-gradient-to-r from-sky-500/15 to-indigo-500/15 text-primary ring-1 ring-inset ring-blue-200/70"
                      : "text-slate-600 hover:bg-white/70",
                  )}
                >
                  <FileCode2 className="size-3.5 shrink-0 text-slate-400" />
                  <span className="truncate">{sample.name}</span>
                </button>
              ))}
            </div>
            <p className="px-1.5 pb-1 pt-3 text-[10px] font-bold uppercase tracking-widest text-slate-400">
              Current file
            </p>
            <div className="flex items-center gap-2 rounded-lg border border-blue-200/70 bg-blue-50/60 px-2 py-1.5 text-[12.5px] font-medium text-blue-800">
              <FileCode2 className="size-3.5 shrink-0" />
              <span className="truncate">{filename || "unnamed.c"}</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="mt-2 w-full cursor-pointer rounded-lg text-[12px]"
              onClick={() => fileInputRef.current?.click()}
            >
              <FileUp className="size-3.5" />
              Upload .c file
            </Button>
          </div>
        </GlassCard>

        {/* -------- Center: editor + results -------- */}
        <div className="flex min-h-0 min-w-0 flex-col gap-3">
          <GlassCard className="flex min-h-0 flex-1 flex-col overflow-hidden">
            <div className="flex items-center justify-between gap-2 border-b border-white/60 px-3 py-2">
              <div className="flex min-w-0 items-center gap-2">
                <FileCode2 className="size-4 shrink-0 text-primary" />
                <Input
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  className="h-7 w-44 cursor-text rounded-lg border-white/70 bg-white/70 px-2 font-mono text-[12.5px] shadow-none focus-visible:ring-1"
                  aria-label="Filename"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-white/70 bg-white/60 px-2.5 py-1 text-[12px] font-semibold text-slate-600 transition hover:bg-white/90 xl:hidden"
                >
                  <FileUp className="size-3.5" />
                  Upload
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    const blob = new Blob([code], { type: "text/plain" });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = filename || "main.c";
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="hidden cursor-pointer rounded-lg px-2 py-1 text-[12px] font-semibold text-slate-500 hover:bg-white/70 hover:text-slate-700 sm:block"
                >
                  Export .c
                </button>
              </div>
            </div>
            <div className="relative min-h-0 flex-1">
              <CodeEditor
                ref={editorRef}
                value={code}
                onChange={(v) => {
                  setCode(v);
                  setRun(null);
                }}
                onAnalyze={handleAnalyze}
                findings={findings}
                className="absolute inset-0"
              />
            </div>
          </GlassCard>

          {/* Results panel */}
          <GlassCard className="flex min-h-[240px] flex-1 flex-col overflow-hidden">
            <div className="scrollbar-thin flex items-center gap-0.5 overflow-x-auto border-b border-white/60 px-2 pt-1.5">
              {tabs.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "flex shrink-0 cursor-pointer items-center gap-1.5 rounded-t-lg border-b-2 px-3 py-2 text-[12.5px] font-semibold transition-colors",
                    tab === t.id
                      ? "border-primary bg-white/70 text-primary"
                      : "border-transparent text-slate-500 hover:bg-white/50 hover:text-slate-700",
                  )}
                >
                  {t.label}
                  {typeof t.count === "number" && t.count > 0 && (
                    <span
                      className={cn(
                        "rounded-full px-1.5 py-px font-mono text-[10px] font-bold tabular",
                        t.badge === "high"
                          ? "bg-rose-100 text-rose-700"
                          : "bg-blue-100 text-blue-700",
                      )}
                    >
                      {t.count}
                    </span>
                  )}
                  {t.badge === "ok" && (
                    <CheckCircle2 className="size-3 text-emerald-500" />
                  )}
                </button>
              ))}
            </div>
            <div className="min-h-0 flex-1 overflow-hidden">
              {analyzing ? (
                <PipelineProgress phaseIdx={phaseIdx} />
              ) : !result ? (
                <EmptyResults />
              ) : (
                <div className="h-full overflow-y-auto">
                  {tab === "overview" && <OverviewView result={result} />}
                  {tab === "findings" && (
                    <FindingsView findings={findings} onJump={jumpToLine} />
                  )}
                  {tab === "tokens" && <TokensView tokens={result.tokens} />}
                  {tab === "ast" && <AstView ast={result.ast} />}
                  {tab === "symbols" && <SymbolsView symbols={result.symbolTable} />}
                  {tab === "security" && (
                    <CategoryFindingsView
                      findings={findings}
                      category="SECURITY"
                      onJump={jumpToLine}
                      emptyMessage="No security findings — no dangerous patterns detected."
                    />
                  )}
                  {tab === "runtime" && (
                    <CategoryFindingsView
                      findings={findings}
                      category="RUNTIME"
                      onJump={jumpToLine}
                      emptyMessage="No potential runtime errors detected."
                    />
                  )}
                  {tab === "report" && (
                    <ReportView
                      projectName={
                        profile?.fullName ? `${profile.fullName} workspace` : "Secure Code Analyzer"
                      }
                      result={result}
                      sourceCode={code}
                    />
                  )}
                </div>
              )}
            </div>
          </GlassCard>
        </div>

        {/* -------- Right rail: module summary -------- */}
        <GlassCard className="hidden min-h-0 flex-col overflow-hidden xl:flex">
          <div className="border-b border-white/60 px-3 py-2">
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Analysis summary
            </p>
          </div>
          <div className="scrollbar-thin min-h-0 flex-1 space-y-3 overflow-auto p-3">
            <ModuleChip
              label="Syntax"
              icon={GitBranch}
              done={result !== null}
              issues={result?.metadata.syntaxErrorCount ?? 0}
            />
            <ModuleChip
              label="Semantic"
              icon={Table2}
              done={result !== null}
              issues={result?.metadata.semanticErrorCount ?? 0}
            />
            <ModuleChip
              label="Security"
              icon={ShieldCheck}
              done={result !== null}
              issues={result?.metadata.securityCount ?? 0}
            />
            <ModuleChip
              label="Runtime"
              icon={FlaskConical}
              done={result !== null}
              issues={result?.metadata.runtimeCount ?? 0}
            />
            <div className="glass-subtle rounded-xl p-3">
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                Totals
              </p>
              {result ? (
                <ul className="mt-2 space-y-1.5 text-[12.5px] font-semibold text-slate-700">
                  <li className="flex justify-between">
                    <span>Findings</span>
                    <span className="tabular">{result.summary.total}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-400">Tokens</span>
                    <span className="tabular">{result.metadata.tokenCount}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-400">Time</span>
                    <span className="tabular">{result.metadata.analysisTimeMs} ms</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-400">Symbols</span>
                    <span className="tabular">{result.symbolTable.length}</span>
                  </li>
                </ul>
              ) : (
                <p className="mt-1.5 text-[12px] leading-relaxed text-slate-400">
                  Results appear here after an analysis run.
                </p>
              )}
            </div>
          </div>
        </GlassCard>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept=".c"
        className="hidden"
        onChange={(e) => {
          handleUpload(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
    </div>
  );
}

function PipelineProgress({ phaseIdx }: { phaseIdx: number }) {
  return (
    <div className="flex h-full items-center justify-center p-6">
      <div className="w-full max-w-sm rounded-2xl border border-white/60 bg-white/60 p-6 backdrop-blur">
        <p className="text-center text-sm font-bold uppercase tracking-widest text-primary">
          Analyzing source code
        </p>
        <ul className="mt-5 space-y-3">
          {PHASE_STEPS.map((step, i) => {
            const state = i < phaseIdx ? "done" : i === phaseIdx ? "active" : "todo";
            return (
              <li key={step.label} className="flex items-center gap-3 text-sm">
                {state === "done" ? (
                  <CheckCircle2 className="size-5 text-emerald-500" />
                ) : state === "active" ? (
                  <Loader2 className="size-5 animate-spin text-primary" />
                ) : (
                  <span className="flex size-5 items-center justify-center">
                    <span className="size-2 rounded-full border-2 border-slate-300" />
                  </span>
                )}
                <step.icon
                  className={cn(
                    "size-4",
                    state === "todo" ? "text-slate-300" : "text-slate-600",
                  )}
                />
                <span
                  className={cn(
                    "font-medium",
                    state === "todo" ? "text-slate-400" : "text-slate-700",
                  )}
                >
                  {step.label}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

function EmptyResults() {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
      <div className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-500/15 to-indigo-500/15 ring-1 ring-inset ring-blue-200/60">
        <ScanSearch className="size-7 text-primary" />
      </div>
      <div>
        <p className="text-sm font-bold text-foreground">Ready to analyze</p>
        <p className="mx-auto mt-1 max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">
          Load a sample from the explorer, upload a <span className="font-mono">.c</span>{" "}
          file, or write C code — then press{" "}
          <span className="font-semibold text-foreground">Analyze Code</span>. Real
          lexical, syntax, semantic, security and runtime-risk results appear here.
        </p>
      </div>
      <p className="flex items-center gap-1.5 rounded-full border border-amber-200/80 bg-amber-50/70 px-3 py-1 text-[11.5px] font-medium text-amber-800">
        <AlertTriangle className="size-3.5" />
        Code is never executed — runtime items are labeled as potential.
      </p>
    </div>
  );
}

function ModuleChip({
  label,
  icon: Icon,
  done,
  issues,
}: {
  label: string;
  icon: typeof GitBranch;
  done: boolean;
  issues: number;
}) {
  return (
    <div className="glass-subtle flex items-center justify-between rounded-xl px-3 py-2.5">
      <span className="flex items-center gap-2 text-[12.5px] font-semibold text-slate-700">
        <Icon className="size-4 text-slate-400" />
        {label}
      </span>
      {!done ? (
        <span className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wide text-slate-400">
          <X className="size-3.5" /> pending
        </span>
      ) : issues === 0 ? (
        <span className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wide text-emerald-600">
          <CheckCircle2 className="size-3.5" /> pass
        </span>
      ) : (
        <span className="flex items-center gap-1 rounded-full bg-rose-100 px-2 py-0.5 font-mono text-[11px] font-bold text-rose-700 tabular">
          {issues} issue{issues === 1 ? "" : "s"}
        </span>
      )}
    </div>
  );
}

export { MAX_CODE_LENGTH };
