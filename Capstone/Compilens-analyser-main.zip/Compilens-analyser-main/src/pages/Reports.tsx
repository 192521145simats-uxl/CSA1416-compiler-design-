import { useEffect, useMemo, useState } from "react";
import { useConvex, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { toast } from "sonner";
import { Copy, Download, FileBarChart2, Loader2, RefreshCw } from "lucide-react";
import { GlassCard, GlassBadge } from "@/components/Glass";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { AnalysisResult } from "@/convex/analyzer/types";
import {
  buildHtmlReport,
  buildJsonReport,
  buildTxtReport,
  downloadReport,
  type ReportFormat,
} from "@/lib/reports";

interface StoredDetail {
  id: string;
  filename: string;
  language: string;
  sourceCode: string;
  createdAt: number;
  summary: AnalysisResult["summary"];
  metadata: AnalysisResult["metadata"];
  notes: string[];
  tokens: unknown;
  ast: unknown;
  symbolTable: unknown;
  findings: AnalysisResult["findings"];
}

export default function Reports() {
  const convex = useConvex();
  const profile = useQuery(api.analyses.getProfile);
  const rows = useQuery(api.analyses.listAnalyses);
  const [selectedId, setSelectedId] = useState<string>("");
  const [detail, setDetail] = useState<StoredDetail | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [format, setFormat] = useState<ReportFormat>("html");
  const [copying, setCopying] = useState(false);

  useEffect(() => {
    if (rows && rows.length > 0 && !selectedId) {
      setSelectedId(String(rows[0].id));
    }
  }, [rows, selectedId]);

  useEffect(() => {
    if (!selectedId) return;
    let cancelled = false;
    setLoadingDetail(true);
    convex
      .query(api.analyses.getAnalysis, { id: selectedId as never })
      .then((data) => {
        if (!cancelled) setDetail(data as unknown as StoredDetail);
      })
      .catch((error) => {
        if (!cancelled) {
          toast.error("Could not load analysis", {
            description: error instanceof Error ? error.message : "Unknown error",
          });
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingDetail(false);
      });
    return () => {
      cancelled = true;
    };
  }, [convex, selectedId]);

  const result: AnalysisResult | null = useMemo(() => {
    if (!detail) return null;
    return {
      success: true,
      language: detail.language,
      filename: detail.filename,
      tokens: (detail.tokens ?? []) as AnalysisResult["tokens"],
      ast: (detail.ast ?? null) as AnalysisResult["ast"],
      symbolTable: (detail.symbolTable ?? []) as AnalysisResult["symbolTable"],
      findings: detail.findings,
      summary: detail.summary,
      metadata: detail.metadata,
      notes: detail.notes ?? [],
    };
  }, [detail]);

  const projectName = profile?.fullName
    ? `${profile.fullName} workspace`
    : "Secure Code Analyzer";

  const content = useMemo(() => {
    if (!detail || !result) return "";
    const input = {
      projectName,
      filename: detail.filename,
      language: detail.language,
      sourceCode: detail.sourceCode,
      createdAt: detail.createdAt,
      result,
    };
    return format === "json"
      ? buildJsonReport(input)
      : format === "html"
        ? buildHtmlReport(input)
        : buildTxtReport(input);
  }, [detail, result, format, projectName]);

  const handleCopy = async () => {
    if (!content) return;
    try {
      await navigator.clipboard.writeText(content);
      setCopying(true);
      toast.success("Report copied to clipboard");
      window.setTimeout(() => setCopying(false), 1200);
    } catch {
      toast.error("Could not copy — select the text manually");
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">
          Report generation
        </h1>
        <p className="text-sm text-muted-foreground">
          Export any stored analysis as an HTML, JSON or TXT report built from the
          real stored findings.
        </p>
      </div>

      <GlassCard className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
          <div className="flex items-center gap-2">
            <FileBarChart2 className="size-4 shrink-0 text-primary" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Analysis
            </span>
          </div>
          <Select value={selectedId || undefined} onValueChange={setSelectedId}>
            <SelectTrigger className="glass-subtle h-10 w-full min-w-0 cursor-pointer sm:w-80">
              <SelectValue placeholder="Select an analysis" />
            </SelectTrigger>
            <SelectContent>
              {rows === undefined && (
                <div className="flex items-center gap-2 px-2 py-2 text-xs text-muted-foreground">
                  <Loader2 className="size-3.5 animate-spin" /> Loading…
                </div>
              )}
              {rows?.map((row) => (
                <SelectItem key={String(row.id)} value={String(row.id)}>
                  {row.filename} · {new Date(row.createdAt).toLocaleDateString()} ·{" "}
                  {row.summary.total} findings
                </SelectItem>
              ))}
              {rows?.length === 0 && (
                <p className="px-3 py-2 text-xs text-muted-foreground">
                  No analyses stored yet.
                </p>
              )}
            </SelectContent>
          </Select>
          {detail && (
            <div className="flex flex-wrap items-center gap-1.5">
              <GlassBadge tone="brand">{detail.language.toUpperCase()}</GlassBadge>
              <GlassBadge tone={detail.summary.total > 0 ? "danger" : "success"}>
                {detail.summary.total} findings
              </GlassBadge>
              <span className="text-[11.5px] text-muted-foreground">
                analyzed {new Date(detail.createdAt).toLocaleString()}
              </span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          {(["html", "json", "txt"] as ReportFormat[]).map((f) => (
            <Button
              key={f}
              size="sm"
              variant={format === f ? "default" : "outline"}
              onClick={() => setFormat(f)}
              className={cn2(
                "cursor-pointer rounded-lg uppercase",
                format === f &&
                  "bg-gradient-to-r from-sky-500 to-indigo-600 text-white",
              )}
            >
              {f}
            </Button>
          ))}
          <Button
            size="sm"
            disabled={!content || loadingDetail}
            onClick={handleCopy}
            className="cursor-pointer rounded-lg"
            variant="outline"
          >
            {copying ? <RefreshCw className="mr-1 size-3.5 animate-spin" /> : <Copy className="mr-1 size-3.5" />}
            Copy
          </Button>
          <Button
            size="sm"
            disabled={!content || loadingDetail}
            onClick={() => {
              if (content && detail) {
                downloadReport(content, format, detail.filename);
                toast.success(`Report downloaded as .${format}`);
              }
            }}
            className="cursor-pointer rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 font-semibold text-white hover:from-emerald-500 hover:to-teal-500"
          >
            <Download className="mr-1 size-3.5" />
            Download
          </Button>
        </div>
      </GlassCard>

      <GlassCard className="overflow-hidden">
        <div className="border-b border-white/60 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-slate-500">
          Preview
        </div>
        {loadingDetail ? (
          <div className="flex items-center justify-center gap-2 py-20 text-muted-foreground">
            <Loader2 className="size-5 animate-spin" />
            Loading stored analysis…
          </div>
        ) : format === "html" && content ? (
          <iframe
            title="Report preview"
            className="h-[62vh] w-full border-0 bg-white"
            srcDoc={content}
            sandbox=""
          />
        ) : (
          <pre className="scrollbar-thin max-h-[62vh] overflow-auto whitespace-pre-wrap p-5 font-mono text-[12px] leading-relaxed text-slate-700">
            {content || "Select an analysis and a format to preview its report."}
          </pre>
        )}
      </GlassCard>
    </div>
  );
}

/** tiny local cn to avoid an extra import cycle */
function cn2(...parts: (string | false | undefined | null)[]): string {
  return parts.filter(Boolean).join(" ");
}
