import { Suspense, useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight,
  Eye,
  EyeOff,
  Loader2,
  LockKeyhole,
  Mail,
  ShieldCheck,
  UserRound,
  UserX,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { AmbientScene, GlassCard } from "@/components/Glass";
import { LogoMark } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface AuthProps {
  redirectAfterAuth?: string;
}

function resolveRedirectAfterAuth(
  returnTo: string | null,
  fallback = "/dashboard",
) {
  if (returnTo?.startsWith("/") && !returnTo.startsWith("//")) return returnTo;
  return fallback;
}

type Mode = "signin" | "signup";

function Auth({ redirectAfterAuth }: AuthProps = {}) {
  const { isLoading: authLoading, isAuthenticated, signIn } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = resolveRedirectAfterAuth(
    searchParams.get("returnTo"),
    redirectAfterAuth,
  );

  const [mode, setMode] = useState<Mode>(
    (searchParams.get("mode") as Mode) === "signup" ? "signup" : "signin",
  );
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      navigate(redirect, { replace: true });
    }
  }, [authLoading, isAuthenticated, navigate, redirect]);

  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

  const friendlyError = (modeNow: Mode, raw: unknown): string => {
    const msg = raw instanceof Error ? raw.message : String(raw);
    if (/already exists|already registered|account.*exist/i.test(msg)) {
      return "An account with this email already exists. Sign in instead, or use a different email.";
    }
    if (/invalid credentials|incorrect|password/i.test(msg) && modeNow === "signin") {
      return "Invalid email or password. Please try again.";
    }
    if (/at least 8|password.*short/i.test(msg)) {
      return "Password must be at least 8 characters long.";
    }
    if (/not found|no user/i.test(msg)) {
      return "No account found for this email. Create one instead.";
    }
    return msg;
  };

  const validate = (): string | null => {
    if (mode === "signup" && name.trim().length < 2) {
      return "Please enter your full name.";
    }
    if (!emailOk) return "Please enter a valid email address.";
    if (password.length < 8) {
      return "Password must be at least 8 characters long.";
    }
    if (mode === "signup" && password !== confirm) {
      return "Passwords do not match.";
    }
    return null;
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    const problem = validate();
    if (problem) {
      setError(problem);
      return;
    }
    setLoading(true);
    try {
      if (mode === "signup") {
        await signIn("password", {
          flow: "signUp",
          email: email.trim(),
          password,
          name: name.trim(),
        });
      } else {
        await signIn("password", {
          flow: "signIn",
          email: email.trim(),
          password,
        });
      }
      // Auth state updates asynchronously; the effect above navigates.
    } catch (raw) {
      console.error("Password auth error:", raw);
      setError(friendlyError(mode, raw));
      setLoading(false);
    }
  };

  const handleGuest = async () => {
    setError(null);
    setLoading(true);
    try {
      await signIn("anonymous");
    } catch (raw) {
      console.error("Guest login error:", raw);
      setError("Guest login is unavailable right now. Create an account instead.");
      setLoading(false);
    }
  };

  const switchMode = (next: Mode) => {
    setMode(next);
    setError(null);
    setPassword("");
    setConfirm("");
  };

  const inputCls =
    "glass-subtle h-11 rounded-xl pl-10 pr-10 text-[14px] shadow-none focus-visible:ring-2 focus-visible:ring-blue-400/60";

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-10">
      <AmbientScene />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 opacity-60 [background-image:radial-gradient(oklch(1_0_0/0.55)_1px,transparent_1px)] [background-size:26px_26px]"
      />

      <AnimatePresence mode="wait">
        <motion.div
          key={mode}
          initial={{ opacity: 0, y: 16, scale: 0.985 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.99 }}
          transition={{ duration: 0.28, ease: "easeOut" }}
          className="w-full max-w-md"
        >
          <GlassCard className="overflow-hidden p-8 sm:p-10">
            <div className="flex flex-col items-center text-center">
              <button
                type="button"
                onClick={() => navigate("/")}
                className="cursor-pointer"
                aria-label="Back to home"
              >
                <LogoMark className="size-14 rounded-2xl" />
              </button>
              <h1 className="mt-5 text-2xl font-black tracking-tight text-foreground">
                SECURE CODE <span className="text-gradient-brand">ANALYZER</span>
              </h1>
              <p className="mt-1.5 max-w-sm text-[13px] leading-relaxed text-muted-foreground">
                Compiler-based secure source code analysis framework for C —
                syntax, semantic, security and runtime error detection.
              </p>
            </div>

            <div className="mx-auto mt-7 grid grid-cols-2 rounded-xl border border-white/70 bg-white/50 p-1 backdrop-blur">
              {(["signin", "signup"] as Mode[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => switchMode(m)}
                  className={cn(
                    "cursor-pointer rounded-lg py-2 text-sm font-bold transition-all",
                    mode === m
                      ? "bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md"
                      : "text-slate-500 hover:text-slate-700",
                  )}
                >
                  {m === "signin" ? "Sign In" : "Create Account"}
                </button>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              {mode === "signup" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="space-y-1.5"
                >
                  <Label htmlFor="name" className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Full name
                  </Label>
                  <div className="relative">
                    <UserRound className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ada Lovelace"
                      autoComplete="name"
                      className={inputCls}
                      disabled={loading}
                    />
                  </div>
                </motion.div>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Email address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    autoComplete="email"
                    className={inputCls}
                    disabled={loading}
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Password
                </Label>
                <div className="relative">
                  <LockKeyhole className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={mode === "signup" ? "At least 8 characters" : "Your password"}
                    autoComplete={mode === "signup" ? "new-password" : "current-password"}
                    className={inputCls}
                    disabled={loading}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer text-muted-foreground transition hover:text-foreground"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>

              {mode === "signup" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="space-y-1.5"
                >
                  <Label htmlFor="confirm" className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Confirm password
                  </Label>
                  <div className="relative">
                    <ShieldCheck className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="confirm"
                      type={showPassword ? "text" : "password"}
                      value={confirm}
                      onChange={(e) => setConfirm(e.target.value)}
                      placeholder="Repeat your password"
                      autoComplete="new-password"
                      className={inputCls}
                      disabled={loading}
                    />
                  </div>
                </motion.div>
              )}

              {error && (
                <div
                  role="alert"
                  className="rounded-xl border border-rose-200/80 bg-rose-50/80 px-4 py-2.5 text-[13px] font-medium leading-relaxed text-rose-700"
                >
                  {error}
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="h-12 w-full cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 text-[15px] font-bold text-white shadow-[0_14px_30px_-12px_rgba(37,99,235,0.8)] transition-all hover:from-sky-400 hover:via-blue-500 hover:to-indigo-500"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 size-4 animate-spin" />
                    {mode === "signup" ? "Creating account…" : "Signing in…"}
                  </>
                ) : (
                  <>
                    {mode === "signup" ? "Create account" : "Sign in"}
                    <ArrowRight className="ml-2 size-4" />
                  </>
                )}
              </Button>
            </form>

            <div className="mt-5 flex items-center gap-3 text-[11px] font-semibold uppercase tracking-widest text-slate-400">
              <span className="h-px flex-1 bg-slate-200/80" />
              or
              <span className="h-px flex-1 bg-slate-200/80" />
            </div>

            <Button
              type="button"
              variant="outline"
              onClick={handleGuest}
              disabled={loading}
              className="glass-subtle mt-4 h-11 w-full cursor-pointer rounded-xl font-semibold text-slate-600 hover:bg-white/80"
            >
              {loading ? (
                <Loader2 className="mr-2 size-4 animate-spin" />
              ) : (
                <UserX className="mr-2 size-4" />
              )}
              Continue as guest
            </Button>

            <p className="mt-6 text-center text-xs leading-relaxed text-muted-foreground">
              {mode === "signin" ? (
                <>
                  New here?{" "}
                  <button
                    type="button"
                    onClick={() => switchMode("signup")}
                    className="cursor-pointer font-bold text-primary hover:underline"
                  >
                    Create an account
                  </button>
                </>
              ) : (
                <>
                  Already registered?{" "}
                  <button
                    type="button"
                    onClick={() => switchMode("signin")}
                    className="cursor-pointer font-bold text-primary hover:underline"
                  >
                    Sign in
                  </button>
                </>
              )}
              <br />
              Sessions persist — you stay signed in across browser restarts.
            </p>
          </GlassCard>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

export default function AuthPage(props: AuthProps) {
  return (
    <Suspense>
      <Auth {...props} />
    </Suspense>
  );
}
