import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { toast } from "sonner";
import { BadgeCheck, Loader2, Save, UserRound } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { GlassCard } from "@/components/Glass";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function Profile() {
  const { user, isAuthenticated } = useAuth();
  const profile = useQuery(api.analyses.getProfile);
  const stats = useQuery(api.analyses.getDashboardStats);
  const updateProfile = useMutation(api.analyses.updateProfile);

  const [fullName, setFullName] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  if (!isAuthenticated) return null;
  const currentName = fullName ?? profile?.fullName ?? user?.name ?? "";
  const email = profile?.email || user?.email || "";
  const initials = (currentName || email || "U").slice(0, 2).toUpperCase();

  const handleSave = async () => {
    if (!fullName?.trim()) return;
    setSaving(true);
    try {
      await updateProfile({ fullName: fullName.trim() });
      toast.success("Profile updated");
      setFullName(null);
    } catch (error) {
      toast.error("Could not update profile", {
        description: error instanceof Error ? error.message : "Unknown error",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Profile</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Your account details within the Secure Code Analyzer workspace.
        </p>
      </div>

      <GlassCard className="flex flex-col items-center gap-4 p-6 sm:flex-row sm:items-start">
        <Avatar className="size-20">
          <AvatarFallback className="bg-gradient-to-br from-sky-500 to-indigo-600 text-xl font-bold text-white">
            {initials}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 text-center sm:text-left">
          <h2 className="flex items-center justify-center gap-2 text-lg font-bold text-foreground sm:justify-start">
            {currentName || "Unnamed user"}
            <BadgeCheck className="size-4 text-sky-500" />
          </h2>
          <p className="text-sm text-muted-foreground">{email}</p>
          {profile?.createdAt ? (
            <p className="mt-1 text-xs text-muted-foreground">
              Member since {new Date(profile.createdAt).toLocaleDateString()}
            </p>
          ) : null}
          <div className="mt-3 flex flex-wrap justify-center gap-2 sm:justify-start">
            <span className="rounded-full border border-blue-200/80 bg-blue-50/80 px-3 py-1 text-xs font-semibold text-blue-700">
              {stats?.totalAnalyses ?? "…"} analyses
            </span>
            <span className="rounded-full border border-slate-200/80 bg-white/70 px-3 py-1 text-xs font-semibold text-slate-600">
              {stats?.totalFindings ?? "…"} findings
            </span>
            {stats && stats.totalFindings > 0 && (
              <span className="rounded-full border border-rose-200/80 bg-rose-50/80 px-3 py-1 text-xs font-semibold text-rose-700">
                {stats.critical + stats.high} high/critical
              </span>
            )}
          </div>
        </div>
      </GlassCard>

      <GlassCard className="p-6">
        <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-foreground">
          <UserRound className="size-4 text-primary" />
          Edit profile
        </h3>
        <div className="mt-5 grid gap-5">
          <div className="grid gap-2">
            <Label htmlFor="fullName">Full name</Label>
            <Input
              id="fullName"
              value={fullName ?? profile?.fullName ?? user?.name ?? ""}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Your full name"
              className="glass-subtle h-11"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              value={email}
              disabled
              className="glass-subtle h-11 cursor-not-allowed opacity-70"
            />
            <p className="text-xs text-muted-foreground">
              Email is managed by your authentication provider and cannot be changed here.
            </p>
          </div>
          <div className="flex justify-end">
            <Button
              onClick={handleSave}
              disabled={saving || !fullName?.trim() || fullName.trim() === (profile?.fullName ?? user?.name)}
              className="cursor-pointer rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 px-6 font-bold text-white hover:from-sky-400 hover:to-indigo-500"
            >
              {saving ? (
                <Loader2 className="mr-2 size-4 animate-spin" />
              ) : (
                <Save className="mr-2 size-4" />
              )}
              Save changes
            </Button>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}
