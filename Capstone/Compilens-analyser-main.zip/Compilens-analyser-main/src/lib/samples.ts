/**
 * Sample programs shown in the Analyzer's project explorer.
 *
 * IMPORTANT: these are only source texts — they are never pre-scored. Every
 * sample goes through the real analysis pipeline when the user runs it.
 */

export interface SampleProgram {
  id: string;
  name: string;
  filename: string;
  description: string;
  code: string;
}

export const SAMPLE_PROGRAMS: SampleProgram[] = [
  {
    id: "clean",
    name: "Clean Program",
    filename: "clean.c",
    description: "A tidy program — no major findings expected.",
    code: `#include <stdio.h>

// Adds two integers safely and prints the result.
int add(int a, int b) {
    return a + b;
}

int main() {
    int x = 5;
    int y = 7;
    int sum = add(x, y);
    printf("Sum: %d\\n", sum);
    return 0;
}
`,
  },
  {
    id: "syntax-error",
    name: "Syntax Error",
    filename: "syntax_error.c",
    description: "Missing semicolon on line 4 — expect a syntax finding.",
    code: `#include <stdio.h>

int main() {
    int x = 10
    printf("%d", x);
    return 0;
}
`,
  },
  {
    id: "semantic-error",
    name: "Semantic Error",
    filename: "semantic_error.c",
    description: "Assigning a string to an int — expect a type mismatch.",
    code: `int main() {
    int x;
    x = "hello";
    return 0;
}
`,
  },
  {
    id: "security-error",
    name: "Security Error",
    filename: "security_error.c",
    description: "Hardcoded password — expect CWE-798 (HIGH).",
    code: `#include <stdio.h>

int main() {
    char *password = "admin123";
    printf("%s", password);
    return 0;
}
`,
  },
  {
    id: "runtime-error",
    name: "Runtime Risk",
    filename: "runtime_risk.c",
    description: "Division by a zero constant — expect a potential runtime error.",
    code: `#include <stdio.h>

int main() {
    int a = 10;
    int b = 0;
    printf("%d", a / b);
    return 0;
}
`,
  },
  {
    id: "structs-switch",
    name: "Structs & Switch",
    filename: "structs_switch.c",
    description: "Typedef struct, member access and a switch on scores — exercises the extended C subset.",
    code: `#include <stdio.h>

// A grade record: name buffer plus an integer score.
typedef struct {
    char name[32];
    int score;
} Student;

// Convert a numeric score into a letter grade.
char grade_letter(int score) {
    switch (score / 10) {
        case 9:
        case 10:
            return 'A';
        case 8:
            return 'B';
        case 7:
            return 'C';
        case 6:
            return 'D';
        default:
            return 'F';
    }
}

int main() {
    Student students[3];
    int i;
    for (i = 0; i < 3; i++) {
        students[i].score = 70 + i * 10;
    }
    for (i = 0; i < 3; i++) {
        printf("Score %d -> %c\\n", students[i].score, grade_letter(students[i].score));
    }
    return 0;
}
`,
  },
];
