/**
 * AnalysisOrchestrator
 *
 * Source Code
 *   → Input Validation
 *   → Lexer
 *   → Parser (AST)
 *   → Semantic Analysis + Symbol Table
 *   → Security Analysis
 *   → Runtime Analysis
 *   → Aggregate Findings → Severity Summary → Final Result
 *
 * Modules degrade gracefully: if the parser reports syntax errors, semantic
 * analysis still runs on the recovered tree and security analysis always
 * runs (via AST or token fallback). Notes explain when a module could not
 * run in full.
 */
import { lexSource } from "./lexer";
import { parseTokens } from "./parser";
import { analyzeSemantics } from "./semantic";
import { analyzeSecurity } from "./security";
import { analyzeRuntime } from "./runtime";
import {
  buildSummary,
  compareFindings,
  type AnalysisResult,
  type Finding,
  type Token,
} from "./types";

export interface AnalyzeRequest {
  code: string;
  language: string;
  filename: string;
}

const MAX_CODE_LENGTH = 60_000;

export function runAnalysisPipeline(request: AnalyzeRequest): AnalysisResult {
  const startedAt = Date.now();
  const notes: string[] = [];
  const filename = request.filename || "main.c";
  const language = request.language || "c";
  const code = request.code ?? "";

  if (code.trim().length === 0) {
    return {
      success: false,
      language,
      filename,
      tokens: [],
      ast: null,
      symbolTable: [],
      findings: [
        {
          id: "INPUT-1",
          category: "LEXICAL",
          rule: "empty-source",
          message: "No source code provided",
          description: "The editor is empty. Paste C source code or load a file before analyzing.",
          line: 0,
          column: 0,
          severity: "INFO",
          cwe: "",
          recommendation: "Paste C source code or load a .c file, then run the analysis again.",
          source: "Input Validation",
        },
      ],
      summary: {
        total: 1,
        critical: 0,
        high: 0,
        medium: 0,
        low: 0,
        info: 1,
      },
      metadata: {
        lineCount: 0,
        tokenCount: 0,
        analysisTimeMs: Date.now() - startedAt,
        syntaxErrorCount: 0,
        semanticErrorCount: 0,
        securityCount: 0,
        runtimeCount: 0,
      },
      notes: [],
    };
  }

  if (code.length > MAX_CODE_LENGTH) {
    return {
      success: false,
      language,
      filename,
      tokens: [],
      ast: null,
      symbolTable: [],
      findings: [
        {
          id: "INPUT-1",
          category: "LEXICAL",
          rule: "source-too-large",
          message: "Source code exceeds the size limit",
          description: `Files larger than ${MAX_CODE_LENGTH.toLocaleString()} characters are not supported by the analyzer.`,
          line: 0,
          column: 0,
          severity: "INFO",
          cwe: "",
          recommendation: "Split the program into smaller files or reduce the code size.",
          source: "Input Validation",
        },
      ],
      summary: {
        total: 1,
        critical: 0,
        high: 0,
        medium: 0,
        low: 0,
        info: 1,
      },
      metadata: {
        lineCount: code.split("\n").length,
        tokenCount: 0,
        analysisTimeMs: Date.now() - startedAt,
        syntaxErrorCount: 0,
        semanticErrorCount: 0,
        securityCount: 0,
        runtimeCount: 0,
      },
      notes: [],
    };
  }

  // 1. Lexical analysis
  const lexed = lexSource(code);
  const tokens: Token[] = lexed.data;
  const lexicalFindings: Finding[] = lexed.findings;

  // 2. Syntax analysis
  const parsed = parseTokens(tokens);
  const ast = parsed.ast;
  const syntaxFindings: Finding[] = parsed.findings;

  const astUsable = ast !== null && Array.isArray(ast.body) && (ast.body as unknown[]).length > 0;

  // 3. Semantic analysis + symbol table
  let symbolTable: AnalysisResult["symbolTable"] = [];
  let semanticFindings: Finding[] = [];
  if (astUsable) {
    const semantic = analyzeSemantics(ast);
    symbolTable = semantic.data;
    semanticFindings = semantic.findings;
  } else {
    notes.push(
      "Semantic analysis was limited because the parser could not build a usable syntax tree.",
    );
  }

  // 4. Security analysis (always runs; token fallback if the AST is unusable)
  const security = analyzeSecurity(ast, tokens);
  const securityFindings: Finding[] = security.findings;

  // 5. Static runtime analysis
  const runtime = analyzeRuntime(ast, symbolTable);
  const runtimeFindings: Finding[] = runtime.findings;
  if (!astUsable) {
    notes.push(
      "Static runtime analysis was skipped because the parser could not build a syntax tree. Controlled code execution is not available in this environment; runtime findings are static risk estimates only.",
    );
  } else {
    notes.push(
      "Runtime findings are static risk estimates. The analyzer does not execute code, so they are labeled as potential runtime errors.",
    );
  }

  // 6. Aggregate + sort
  const findings = [
    ...lexicalFindings,
    ...syntaxFindings,
    ...semanticFindings,
    ...securityFindings,
    ...runtimeFindings,
  ].sort(compareFindings);

  const syntaxErrorCount = syntaxFindings.length;
  const semanticErrorCount = semanticFindings.length;
  const securityCount = securityFindings.length;
  const runtimeCount = runtimeFindings.length;

  const lineCount = code.split("\n").length;
  const tokenCount = tokens.filter((t) => t.type !== "EOF").length;

  return {
    success: true,
    language,
    filename,
    tokens,
    ast,
    symbolTable,
    findings,
    summary: buildSummary(findings),
    metadata: {
      lineCount,
      tokenCount,
      analysisTimeMs: Date.now() - startedAt,
      syntaxErrorCount,
      semanticErrorCount,
      securityCount,
      runtimeCount,
    },
    notes,
  };
}