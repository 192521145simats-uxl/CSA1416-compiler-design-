/**
 * Semantic analyzer.
 *
 * Walks the AST with a proper scope chain (global → function → nested
 * blocks) and builds a real symbol table. Detects undeclared identifiers,
 * duplicate declarations, type mismatches, wrong argument counts/types and
 * invalid return types. Type inference is performed on expressions so that
 * findings point at real, structured problems rather than regex matches.
 */
import type {
  AstNode,
  Finding,
  ModuleOutput,
  SourceLocation,
  SymbolEntry,
} from "./types";

interface Scope {
  name: string;
  parent: Scope | null;
  symbols: Map<string, SymbolEntry>;
}

/** Built-in libc functions we pre-declare so ordinary programs analyze cleanly. */
interface Builtin {
  name: string;
  type: string;
  params: { type: string; variadic?: boolean }[];
}

const BUILTINS: Builtin[] = [
  { name: "printf", type: "int", params: [{ type: "char*" }, { type: "int", variadic: true }] },
  { name: "scanf", type: "int", params: [{ type: "char*" }, { type: "int", variadic: true }] },
  { name: "sprintf", type: "int", params: [{ type: "char*" }, { type: "char*" }, { type: "int", variadic: true }] },
  { name: "fprintf", type: "int", params: [{ type: "void*" }, { type: "char*" }, { type: "int", variadic: true }] },
  { name: "gets", type: "char*", params: [{ type: "char*" }] },
  { name: "puts", type: "int", params: [{ type: "char*" }] },
  { name: "fgets", type: "char*", params: [{ type: "char*" }, { type: "int" }, { type: "void*" }] },
  { name: "strcpy", type: "char*", params: [{ type: "char*" }, { type: "char*" }] },
  { name: "strncpy", type: "char*", params: [{ type: "char*" }, { type: "char*" }, { type: "int" }] },
  { name: "strcat", type: "char*", params: [{ type: "char*" }, { type: "char*" }] },
  { name: "strncat", type: "char*", params: [{ type: "char*" }, { type: "char*" }, { type: "int" }] },
  { name: "strlen", type: "int", params: [{ type: "char*" }] },
  { name: "strcmp", type: "int", params: [{ type: "char*" }, { type: "char*" }] },
  { name: "strncmp", type: "int", params: [{ type: "char*" }, { type: "char*" }, { type: "int" }] },
  { name: "strchr", type: "char*", params: [{ type: "char*" }, { type: "int" }] },
  { name: "strstr", type: "char*", params: [{ type: "char*" }, { type: "char*" }] },
  { name: "system", type: "int", params: [{ type: "char*" }] },
  { name: "popen", type: "void*", params: [{ type: "char*" }, { type: "char*" }] },
  { name: "pclose", type: "int", params: [{ type: "void*" }] },
  { name: "malloc", type: "void*", params: [{ type: "int" }] },
  { name: "calloc", type: "void*", params: [{ type: "int" }, { type: "int" }] },
  { name: "realloc", type: "void*", params: [{ type: "void*" }, { type: "int" }] },
  { name: "free", type: "void", params: [{ type: "void*" }] },
  { name: "memset", type: "void*", params: [{ type: "void*" }, { type: "int" }, { type: "int" }] },
  { name: "memcpy", type: "void*", params: [{ type: "void*" }, { type: "void*" }, { type: "int" }] },
  { name: "atoi", type: "int", params: [{ type: "char*" }] },
  { name: "atof", type: "double", params: [{ type: "char*" }] },
  { name: "abs", type: "int", params: [{ type: "int" }] },
  { name: "pow", type: "double", params: [{ type: "double" }, { type: "double" }] },
  { name: "sqrt", type: "double", params: [{ type: "double" }] },
  { name: "rand", type: "int", params: [] },
  { name: "srand", type: "void", params: [{ type: "int" }] },
  { name: "exit", type: "void", params: [{ type: "int" }] },
  { name: "fopen", type: "void*", params: [{ type: "char*" }, { type: "char*" }] },
  { name: "fclose", type: "int", params: [{ type: "void*" }] },
  { name: "fread", type: "int", params: [{ type: "void*" }, { type: "int" }, { type: "int" }, { type: "void*" }] },
  { name: "fwrite", type: "int", params: [{ type: "void*" }, { type: "int" }, { type: "int" }, { type: "void*" }] },
  { name: "perror", type: "void", params: [{ type: "char*" }] },
  { name: "putchar", type: "int", params: [{ type: "int" }] },
  { name: "getchar", type: "int", params: [] },
  { name: "toupper", type: "int", params: [{ type: "int" }] },
  { name: "tolower", type: "int", params: [{ type: "int" }] },
  { name: "isdigit", type: "int", params: [{ type: "int" }] },
  { name: "isalpha", type: "int", params: [{ type: "int" }] },
];

const NUMERIC_TYPES = new Set(["int", "char", "float", "double"]);
const INTEGER_TYPES = new Set(["int", "char"]);

interface StructRecord {
  fields: Map<string, string>;
  defined: boolean;
  loc: SourceLocation | null;
}

const childNodes = (node: AstNode): AstNode[] => {
  const result: AstNode[] = [];
  for (const key of Object.keys(node)) {
    if (key === "kind" || key === "loc") continue;
    const value = node[key];
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item && typeof item === "object" && typeof (item as AstNode).kind === "string") {
          result.push(item as AstNode);
        }
      }
    } else if (value && typeof value === "object" && typeof (value as AstNode).kind === "string") {
      result.push(value as AstNode);
    }
  }
  return result;
};

export class SemanticAnalyzer {
  symbolTable: SymbolEntry[] = [];
  findings: Finding[] = [];
  private scopes: Scope[] = [];
  private structs = new Map<string, StructRecord>();
  private loopDepth = 0;
  private switchDepth = 0;
  private idCounter = 0;

  constructor() {
    const global: Scope = { name: "global", parent: null, symbols: new Map() };
    this.scopes.push(global);
    for (const b of BUILTINS) {
      const entry: SymbolEntry = {
        name: b.name,
        type: `${b.type} ${b.name}(${b.params.map((p) => (p.variadic ? "..." : p.type)).join(", ")})`,
        kind: "Builtin",
        scope: "libc",
        line: 0,
        initialized: true,
        builtin: true,
      };
      global.symbols.set(b.name, entry);
      this.symbolTable.push(entry);
    }
    const nullConst: SymbolEntry = {
      name: "NULL",
      type: "void*",
      kind: "Constant",
      scope: "libc",
      line: 0,
      initialized: true,
      builtin: true,
    };
    global.symbols.set("NULL", nullConst);
    this.symbolTable.push(nullConst);
  }

  private current(): Scope {
    return this.scopes[this.scopes.length - 1];
  }

  private scopeName(): string {
    return this.current().name;
  }

  private pushScope(localName: string): void {
    const parent = this.current();
    this.scopes.push({
      name: parent.name === "global" ? localName : `${parent.name} > ${localName}`,
      parent,
      symbols: new Map(),
    });
  }

  private popScope(): void {
    this.scopes.pop();
  }

  private nextId(): string {
    this.idCounter += 1;
    return `SEM-${this.idCounter}`;
  }

  private addFinding(
    rule: string,
    message: string,
    description: string,
    severity: "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
    loc: SourceLocation | null,
    recommendation: string,
  ): void {
    this.findings.push({
      id: this.nextId(),
      category: "SEMANTIC",
      rule,
      message,
      description,
      line: loc?.line ?? 0,
      column: loc?.column ?? 0,
      severity,
      cwe: "",
      recommendation,
      source: "Semantic",
    });
  }

  private declare(
    name: string,
    type: string,
    kind: SymbolEntry["kind"],
    loc: SourceLocation,
    initialized: boolean,
  ): SymbolEntry | null {
    const scope = this.current();
    const existing = scope.symbols.get(name);
    if (existing) {
      this.addFinding(
        "duplicate-declaration",
        `Duplicate declaration of '${name}'`,
        `'${name}' is already declared in this scope (line ${existing.line}). Duplicate declarations are a semantic error in C.`,
        "HIGH",
        loc,
        `Remove the duplicate declaration of '${name}'.`,
      );
      return null;
    }
    const entry: SymbolEntry = {
      name,
      type,
      kind,
      scope: this.scopeName(),
      line: loc.line,
      initialized,
    };
    scope.symbols.set(name, entry);
    this.symbolTable.push(entry);
    return entry;
  }

  private resolve(name: string): SymbolEntry | null {
    for (let i = this.scopes.length - 1; i >= 0; i--) {
      const found = this.scopes[i].symbols.get(name);
      if (found) return found;
    }
    return null;
  }

  /** Extract the struct tag from a canonical type string like "struct Point*[3]". */
  private structTagOf(type: string): string | null {
    const m = type.match(/^struct\s+([A-Za-z_][A-Za-z0-9_]*)/);
    return m ? m[1] : null;
  }

  /** Register a struct definition/forward-declaration and its fields. */
  private registerStruct(node: AstNode): void {
    const tag = node.tag as string;
    if (!tag) return;
    const members = (node.members as AstNode[]) ?? [];
    const isDef = (node.isDefinition as boolean) === true;
    const existing = this.structs.get(tag);
    if (existing) {
      if (isDef && existing.defined) {
        this.addFinding(
          "duplicate-type",
          `Redefinition of struct '${tag}'`,
          `The struct '${tag}' is defined more than once (line ${node.loc?.line}).`,
          "HIGH",
          node.loc,
          "Remove the duplicate struct definition or rename one of them.",
        );
        return;
      }
      if (isDef) {
        existing.fields = this.buildStructFields(tag, members, node);
        existing.defined = true;
        existing.loc = node.loc;
      }
      return;
    }
    this.structs.set(tag, {
      fields: this.buildStructFields(tag, members, node),
      defined: isDef,
      loc: node.loc,
    });
    // Struct tags live in their own namespace; repeated declarations of the
    // same tag (including forward declarations) are legal in C.
    if (!tag.startsWith("anon_")) {
      const name = `struct ${tag}`;
      if (!this.current().symbols.has(name)) {
        const entry: SymbolEntry = {
          name,
          type: "struct",
          kind: "Type",
          scope: this.scopeName(),
          line: node.loc?.line ?? 0,
          initialized: true,
        };
        this.current().symbols.set(name, entry);
        this.symbolTable.push(entry);
      }
    }
  }

  private buildStructFields(tag: string, members: AstNode[], node: AstNode): Map<string, string> {
    const fields = new Map<string, string>();
    for (const m of members) {
      const name = m.name as string;
      const type = m.type as string;
      if (!name) continue;
      if (fields.has(name)) {
        this.addFinding(
          "duplicate-member",
          `Duplicate member '${name}' in struct '${tag}'`,
          `Struct '${tag}' declares the member '${name}' more than once (line ${m.loc?.line}).`,
          "HIGH",
          m.loc,
          "Rename one of the duplicate members.",
        );
        continue;
      }
      if (type === "void") {
        this.addFinding(
          "invalid-member",
          `Struct member '${name}' cannot have type void`,
          `A struct member cannot have an incomplete type (line ${m.loc?.line}).`,
          "HIGH",
          m.loc,
          "Give the member a concrete type such as int or char.",
        );
        continue;
      }
      fields.set(name, type);
    }
    void node;
    return fields;
  }

  /** Declare a typedef alias as a type symbol (duplicate typedefs are errors). */
  private declareTypedef(node: AstNode): void {
    this.declare(
      node.name as string,
      node.type as string,
      "Type",
      node.loc ?? { line: 0, column: 0, start: 0, end: 0 },
      true,
    );
  }

  /**
   * Resolve the type of `obj.property` without emitting findings.
   * `kind` explains why resolution failed so callers can emit precise errors.
   */
  private memberLookup(
    objectType: string | null,
    property: string,
    pointer: boolean,
  ): { type: string | null; kind: "ok" | "unknown-object" | "arrow-on-value" | "dot-on-pointer" | "not-struct" | "incomplete" | "no-member" } {
    if (!objectType) return { type: null, kind: "unknown-object" };
    if (pointer && !objectType.endsWith("*")) return { type: null, kind: "arrow-on-value" };
    if (!pointer && objectType.endsWith("*")) return { type: null, kind: "dot-on-pointer" };
    let base = objectType.replace(/\[.*\]$/, "");
    if (pointer) base = base.replace(/\*+$/, "");
    const tag = this.structTagOf(base);
    if (!tag) return { type: null, kind: "not-struct" };
    const rec = this.structs.get(tag);
    if (!rec || !rec.defined) return { type: null, kind: "incomplete" };
    const fieldType = rec.fields.get(property);
    if (fieldType === undefined) return { type: null, kind: "no-member" };
    return { type: fieldType, kind: "ok" };
  }

  private describeLvalue(node: AstNode): string {
    if (node.kind === "Identifier") return node.name as string;
    if (node.kind === "MemberAccess") {
      return `${this.describeLvalue(node.object as AstNode)}.${node.property as string}`;
    }
    if (node.kind === "ArrayAccess") {
      return `${this.describeLvalue(node.object as AstNode)}[...]`;
    }
    return node.kind;
  }

  private containsIdentifier(node: AstNode): boolean {
    if (node.kind === "Identifier") return true;
    for (const child of childNodes(node)) {
      if (this.containsIdentifier(child)) return true;
    }
    return false;
  }

  /** Check whether `from` can be assigned to `to`. Returns {ok, note?}. */
  private assignable(to: string, from: string, fromLiteralKind?: string): { ok: boolean; note?: string } {
    if (to === from) return { ok: true };
    // Brace initializers are only valid for aggregates (structs and arrays).
    if (from === "initializer-list") {
      return { ok: to.startsWith("struct") || to.includes("[") };
    }
    const baseOf = (t: string) => t.replace(/\[.*\]$/, "").replace(/\*+$/, "*").replace(/\*$/, "*");
    if (NUMERIC_TYPES.has(to) && NUMERIC_TYPES.has(from)) {
      if ((to === "int" || to === "char") && (from === "float" || from === "double")) {
        return {
          ok: true,
          note: `implicit conversion from ${from} to ${to} may truncate the value`,
        };
      }
      return { ok: true };
    }
    if (to === "char*" && from === "string") return { ok: true };
    if (to === "void*" || from === "void*") return { ok: true };
    if (fromLiteralKind === "string" && NUMERIC_TYPES.has(to)) {
      return { ok: false };
    }
    // pointer-to-pointer
    if (to.endsWith("*") && from.endsWith("*")) {
      const tBase = baseOf(to);
      const fBase = baseOf(from);
      if (tBase === fBase) return { ok: true };
    }
    return { ok: false };
  }

  /** Infer the C type of an expression node, or null when unknown. */
  private inferType(node: AstNode | null): string | null {
    if (!node) return null;
    switch (node.kind) {
      case "Literal": {
        const vt = node.valueType as string;
        if (vt === "string") return "char*";
        if (vt === "char") return "char";
        if (vt === "float") return "float";
        return "int";
      }
      case "Identifier": {
        const sym = this.resolve(node.name as string);
        if (!sym) return null;
        return this.symbolTypeOf(sym);
      }
      case "BinaryExpression": {
        const op = node.operator as string;
        if (["&&", "||", "==", "!=", "<", ">", "<=", ">="].includes(op)) return "int";
        const left = this.inferType(node.left as AstNode);
        const right = this.inferType(node.right as AstNode);
        if (left === "double" || right === "double") return "double";
        if (left === "float" || right === "float") return "float";
        if (left === "int" || right === "int") return "int";
        return left ?? right ?? "int";
      }
      case "UnaryExpression": {
        const op = node.operator as string;
        const operand = this.inferType(node.operand as AstNode);
        if (op === "*") return operand ? operand.replace(/\[.*\]$/, "").replace(/\*$/, "") || "int" : null;
        if (op === "&") return operand ? `${operand}*` : null;
        if (op === "sizeof") return "int";
        return operand && NUMERIC_TYPES.has(operand) ? operand : "int";
      }
      case "AssignmentExpression":
        return this.inferType(node.left as AstNode);
      case "CallExpression": {
        const sym = this.resolve(node.name as string);
        if (!sym) return null;
        if (sym.kind === "Function" || sym.kind === "Builtin") return sym.type.split(" ")[0];
        return null;
      }
      case "ArrayAccess": {
        const objType = this.inferType(node.object as AstNode);
        if (!objType) return null;
        const m = objType.match(/^(.*)\[[^\]]*\]$/);
        return m ? m[1] : objType;
      }
      case "MemberAccess": {
        const objType = this.inferType(node.object as AstNode);
        return this.memberLookup(objType, node.property as string, (node.pointer as boolean) === true).type;
      }
      case "InitializerList":
        return "initializer-list";
      default:
        return null;
    }
  }

  private symbolTypeOf(sym: SymbolEntry): string {
    if (sym.kind === "Function" || sym.kind === "Builtin") {
      return sym.type.split(" ")[0];
    }
    return sym.type;
  }

  // --- Public API ------------------------------------------------------------

  analyze(ast: AstNode | null): void {
    if (!ast || ast.kind !== "Program") {
      this.addFinding(
        "analysis-unavailable",
        "Semantic analysis could not run",
        "The parser did not produce a valid program tree, so semantic analysis was skipped.",
        "INFO",
        null,
        "Fix the syntax errors first, then re-run the analysis.",
      );
      return;
    }

    // Pass 1: hoist functions into the global scope.
    for (const top of ast.body as AstNode[]) {
      if (top.kind === "FunctionDeclaration") {
        this.declareFunction(top);
      }
    }

    // Pass 2: walk every top-level node.
    for (const top of ast.body as AstNode[]) {
      this.visitNode(top, true);
    }
  }

  private declareFunction(node: AstNode): void {
    const name = node.name as string;
    const params = (node.params as AstNode[]) ?? [];
    const existing = this.current().symbols.get(name);
    if (existing) {
      this.addFinding(
        "duplicate-declaration",
        `Duplicate declaration of function '${name}'`,
        `A symbol named '${name}' is already declared (line ${existing.line}).`,
        "HIGH",
        node.loc,
        `Rename the function or remove the duplicate.`,
      );
      return;
    }
    const signature = `${node.returnType as string} ${name}(${params
      .map((p) => (p.name ? `${p.type} ${p.name}` : p.type))
      .join(", ")})`;
    this.current().symbols.set(name, {
      name,
      type: signature,
      kind: "Function",
      scope: "global",
      line: node.loc?.line ?? 0,
      initialized: true,
    });
    this.symbolTable.push({
      name,
      type: signature,
      kind: "Function",
      scope: "global",
      line: node.loc?.line ?? 0,
      initialized: true,
    });
  }

  private visitNode(node: AstNode, isTopLevel: boolean): void {
    switch (node.kind) {
      case "FunctionDeclaration": {
        if (!node.body) return; // prototype — already hoisted
        const funcScopeName = `function:${node.name as string}`;
        this.pushScope(funcScopeName);
        for (const param of (node.params as AstNode[]) ?? []) {
          if (param.kind === "Parameter" && param.name) {
            const paramLoc =
              (param.loc ?? node.loc) ?? { line: 0, column: 0, start: 0, end: 0 };
            this.declare(param.name as string, param.type as string, "Parameter", paramLoc, true);
          }
        }
        this.checkReturns(node);
        const bodyBlock = node.body as AstNode;
        if (bodyBlock.kind === "BlockStatement") {
          for (const stmt of (bodyBlock.body as AstNode[]) ?? []) {
            this.visitStatement(stmt);
          }
        }
        this.popScope();
        return;
      }
      case "VariableDeclaration": {
        for (const decl of (node.declarations as AstNode[]) ?? []) {
          this.checkVariableDeclarator(node, decl);
        }
        return;
      }
      case "StructDeclaration": {
        this.registerStruct(node);
        return;
      }
      case "TypedefDeclaration": {
        this.declareTypedef(node);
        return;
      }
      case "PreprocessorDirective": {
        this.checkDefine(node);
        return;
      }
      default: {
        this.visitBlockChildren(node);
      }
    }
    void isTopLevel;
  }

  private visitBlockChildren(node: AstNode): void {
    for (const child of childNodes(node)) {
      this.visitNode(child, false);
    }
  }

  private checkVariableDeclarator(parent: AstNode, decl: AstNode): void {
    const name = decl.name as string;
    const type = decl.type as string;
    const init = (decl.init as AstNode) ?? null;
    const loc = decl.loc ?? parent.loc;

    const sizeMatch = type.match(/\[(\d+)\]$/);
    if (sizeMatch && parseInt(sizeMatch[1], 10) <= 0) {
      this.addFinding(
        "invalid-array-size",
        `Array '${name}' has an invalid size`,
        `Arrays must have a positive size.`,
        "HIGH",
        loc,
        "Use a positive integer for the array size.",
      );
    }

    const declared = this.declare(name, type, "Variable", loc ?? { line: 0, column: 0, start: 0, end: 0 }, !!init);
    if (declared && init) {
      const initType = this.inferType(init);
      if (initType) {
        const literalKind =
          init.kind === "Literal" ? (init.valueType as string) : undefined;
        const check = this.assignable(type, initType, literalKind);
        if (!check.ok) {
          this.addFinding(
            "type-mismatch",
            `Type mismatch: cannot initialize '${name}' of type ${type} with a value of type ${initType}`,
            `Variable '${name}' (${type}) on line ${loc?.line} is initialized with a value of type ${initType}, which is not assignable.`,
            "HIGH",
            init.loc ?? loc,
            `Change the initializer to a value of type ${type} or change the variable type to ${initType}.`,
          );
        } else if (check.note) {
          this.addFinding(
            "implicit-conversion",
            `Implicit conversion in initializer of '${name}'`,
            check.note.charAt(0).toUpperCase() + check.note.slice(1) + ".",
            "INFO",
            init.loc ?? loc,
            "Cast explicitly, e.g. (int)value, if the truncation is intentional.",
          );
        }
      }
    }
  }

  private checkReturns(fn: AstNode): void {
    const returnType = fn.returnType as string;
    const name = fn.name as string;
    const walk = (node: AstNode) => {
      if (node.kind === "ReturnStatement") {
        const arg = (node.argument as AstNode) ?? null;
        if (returnType === "void") {
          if (arg) {
            this.addFinding(
              "invalid-return-type",
              `Function '${name}' returns void but a value is returned`,
              `A void function cannot return a value.`,
              "HIGH",
              node.loc,
              "Remove the return value, or change the function's return type.",
            );
          }
          return;
        }
        if (!arg) {
          this.addFinding(
            "missing-return-value",
            `Function '${name}' must return a value of type ${returnType}`,
            `'return;' was used in a function declared to return ${returnType}.`,
            "HIGH",
            node.loc,
            `Return a value of type ${returnType}.`,
          );
          return;
        }
        const argType = this.inferType(arg);
        if (argType) {
          const check = this.assignable(returnType, argType, arg.kind === "Literal" ? (arg.valueType as string) : undefined);
          if (!check.ok) {
            this.addFinding(
              "invalid-return-type",
              `Return type mismatch in function '${name}'`,
              `Function '${name}' is declared to return ${returnType} but returns a value of type ${argType} (line ${node.loc?.line}).`,
              "HIGH",
              node.loc,
              `Return a value of type ${returnType}, or change the declared return type.`,
            );
          }
        }
        return;
      }
      for (const child of childNodes(node)) walk(child);
    };
    walk(fn);
  }

  /** Visits a statement and its children while tracking scope for blocks. */
  private visitStatement(node: AstNode): void {
    switch (node.kind) {
      case "BlockStatement": {
        this.pushScope("block");
        for (const child of (node.body as AstNode[]) ?? []) this.visitStatement(child);
        this.popScope();
        return;
      }
      case "IfStatement": {
        this.visitExpression(node.test as AstNode);
        if (node.consequent) this.visitStatement(node.consequent as AstNode);
        if (node.alternate) this.visitStatement(node.alternate as AstNode);
        return;
      }
      case "WhileStatement": {
        this.visitExpression(node.test as AstNode);
        this.loopDepth += 1;
        if (node.body) this.visitStatement(node.body as AstNode);
        this.loopDepth -= 1;
        return;
      }
      case "ForStatement": {
        this.pushScope("for");
        this.loopDepth += 1;
        if (node.init) this.visitNode(node.init as AstNode, false);
        if (node.cond) this.visitExpression(node.cond as AstNode);
        if (node.update) this.visitExpression(node.update as AstNode);
        if (node.body) this.visitStatement(node.body as AstNode);
        this.loopDepth -= 1;
        this.popScope();
        return;
      }
      case "SwitchStatement": {
        this.visitExpression(node.discriminant as AstNode);
        const discType = this.inferType(node.discriminant as AstNode);
        if (discType && !INTEGER_TYPES.has(discType)) {
          this.addFinding(
            "invalid-switch-type",
            "Switch quantity is not an integer",
            `The switch expression on line ${node.loc?.line} has type ${discType}; C requires an integer (int or char) switch expression.`,
            "HIGH",
            node.loc,
            "Use an int or char expression as the switch selector.",
          );
        }
        this.switchDepth += 1;
        for (const c of (node.cases as AstNode[]) ?? []) {
          const test = (c.test as AstNode) ?? null;
          if (test) {
            this.visitExpression(test);
            if (this.containsIdentifier(test)) {
              this.addFinding(
                "non-constant-case",
                "Case label is not a constant",
                `A case label must be a constant integer expression (line ${test.loc?.line ?? node.loc?.line}).`,
                "HIGH",
                test.loc ?? node.loc,
                "Replace the case value with a constant expression.",
              );
            } else if (discType && INTEGER_TYPES.has(discType)) {
              const caseType = this.inferType(test);
              if (caseType && !INTEGER_TYPES.has(caseType)) {
                this.addFinding(
                  "case-type-mismatch",
                  "Case label does not have an integer type",
                  `The case label on line ${test.loc?.line ?? node.loc?.line} has type ${caseType}, which cannot be compared with the switch expression.`,
                  "MEDIUM",
                  test.loc ?? node.loc,
                  "Use an integer constant for the case label.",
                );
              }
            }
          }
          for (const stmt of (c.body as AstNode[]) ?? []) this.visitStatement(stmt);
        }
        this.switchDepth -= 1;
        return;
      }
      case "BreakStatement": {
        if (this.loopDepth + this.switchDepth === 0) {
          this.addFinding(
            "invalid-break",
            "'break' outside a loop or switch",
            `'break' on line ${node.loc?.line} is not inside a loop or switch statement, so it has no effect.`,
            "MEDIUM",
            node.loc,
            "Move the 'break' inside a loop or switch, or remove it.",
          );
        }
        return;
      }
      case "ContinueStatement": {
        if (this.loopDepth === 0) {
          this.addFinding(
            "invalid-continue",
            "'continue' outside a loop",
            `'continue' on line ${node.loc?.line} is not inside a loop, so it has no effect.`,
            "MEDIUM",
            node.loc,
            "Move the 'continue' inside a loop, or remove it.",
          );
        }
        return;
      }
      case "VariableDeclaration": {
        for (const decl of (node.declarations as AstNode[]) ?? []) {
          this.checkVariableDeclarator(node, decl);
        }
        return;
      }
      case "StructDeclaration": {
        this.registerStruct(node);
        return;
      }
      case "TypedefDeclaration": {
        this.declareTypedef(node);
        return;
      }
      case "ExpressionStatement": {
        this.visitExpression(node.expression as AstNode);
        return;
      }
      case "ReturnStatement": {
        if (node.argument) this.visitExpression(node.argument as AstNode);
        return;
      }
      case "PreprocessorDirective": {
        this.checkDefine(node);
        return;
      }
      default: {
        for (const child of childNodes(node)) this.visitStatement(child);
      }
    }
  }

  private checkDefine(node: AstNode): void {
    const value = node.value as string;
    const m = value.match(/^#define\s+([A-Za-z_][A-Za-z0-9_]*)\s+(.+)$/);
    if (!m) return;
    const name = m[1];
    const rhs = m[2].trim();
    const type = /^".*"$/.test(rhs) ? "char*" : /^'[^']*'$/.test(rhs) ? "char" : /^[+-]?(\d+\.\d*|\.\d+|\d+[eE][+-]?\d+)/.test(rhs) ? "double" : /^[+-]?\d+$/.test(rhs) ? "int" : "unknown";
    this.declare(
      name,
      type,
      "Constant",
      { line: node.loc?.line ?? 0, column: node.loc?.column ?? 0, start: 0, end: 0 },
      true,
    );
  }

  private visitExpression(node: AstNode | null): void {
    if (!node) return;
    switch (node.kind) {
      case "Identifier": {
        const name = node.name as string;
        const sym = this.resolve(name);
        if (!sym) {
          this.addFinding(
            "undeclared-identifier",
            `Undeclared identifier '${name}'`,
            `'${name}' is used on line ${node.loc?.line} but has not been declared in any visible scope.`,
            "HIGH",
            node.loc,
            `Declare '${name}' before using it, or check the spelling.`,
          );
        }
        return;
      }
      case "AssignmentExpression": {
        const left = node.left as AstNode;
        const right = node.right as AstNode;
        this.visitExpression(left);
        this.visitExpression(right);
        const rhsType = this.inferType(right);
        const rhsLiteralKind =
          right.kind === "Literal" ? (right.valueType as string) : undefined;

        // Functions are never assignable lvalues.
        if (left.kind === "Identifier") {
          const sym = this.resolve(left.name as string);
          if (sym && (sym.kind === "Function" || sym.kind === "Builtin")) {
            this.addFinding(
              "invalid-assignment",
              `Cannot assign to function '${left.name as string}'`,
              `Functions are not assignable lvalues in C.`,
              "HIGH",
              node.loc,
              "Use a different variable name for the assignment target.",
            );
            return;
          }
        }

        let lvalueType: string | null = null;
        if (left.kind === "Identifier") {
          const sym = this.resolve(left.name as string);
          if (sym) lvalueType = this.symbolTypeOf(sym);
        } else if (left.kind === "MemberAccess" || left.kind === "ArrayAccess") {
          lvalueType = this.inferType(left);
        } else if (left.kind === "UnaryExpression" && (left.operator as string) === "*") {
          lvalueType = this.inferType(left);
        }

        if (lvalueType && rhsType) {
          const check = this.assignable(lvalueType, rhsType, rhsLiteralKind);
          if (!check.ok) {
            this.addFinding(
              "type-mismatch",
              `Type mismatch: cannot assign a value of type ${rhsType} to '${this.describeLvalue(left)}' (${lvalueType})`,
              `Assignment on line ${node.loc?.line} stores a value of type ${rhsType} into an lvalue of type ${lvalueType}.`,
              "HIGH",
              node.loc,
              `Assign a value of type ${lvalueType}, or change the target type.`,
            );
          } else if (check.note) {
            this.addFinding(
              "implicit-conversion",
              `Implicit conversion on assignment to '${this.describeLvalue(left)}'`,
              check.note.charAt(0).toUpperCase() + check.note.slice(1) + ".",
              "INFO",
              node.loc,
              "Use an explicit cast if the conversion is intentional.",
            );
          }
        }
        return;
      }
      case "BinaryExpression": {
        this.visitExpression(node.left as AstNode);
        this.visitExpression(node.right as AstNode);
        const op = node.operator as string;
        const leftT = this.inferType(node.left as AstNode);
        const rightT = this.inferType(node.right as AstNode);
        if (leftT && rightT) {
          const bothNumeric = NUMERIC_TYPES.has(leftT) && NUMERIC_TYPES.has(rightT);
          if (op === "%" && (!INTEGER_TYPES.has(leftT) || !INTEGER_TYPES.has(rightT))) {
            this.addFinding(
              "invalid-operands",
              `The '%' operator requires integer operands`,
              `'%' is applied to operands of type ${leftT} and ${rightT} on line ${node.loc?.line}.`,
              "MEDIUM",
              node.loc,
              "Use integer operands with '%', or use fmod() for floating point.",
            );
          } else if (["+", "-", "*", "/"].includes(op) && !bothNumeric && !(leftT === "char*" && rightT === "int") && !(leftT === "int" && rightT === "char*")) {
            const typeName = leftT === "char*" || rightT === "char*" ? "string" : leftT;
            this.addFinding(
              "invalid-operands",
              `Invalid operands to '${op}' (${leftT} and ${rightT})`,
              `Operator '${op}' on line ${node.loc?.line} is applied to incompatible operand types ${leftT} and ${rightT}.`,
              "HIGH",
              node.loc,
              "Convert one operand to a compatible numeric type before applying the operator.",
            );
          }
        }
        return;
      }
      case "UnaryExpression": {
        this.visitExpression(node.operand as AstNode);
        return;
      }
      case "CallExpression": {
        this.checkCall(node);
        return;
      }
      case "ArrayAccess": {
        this.visitExpression(node.object as AstNode);
        this.visitExpression(node.index as AstNode);
        return;
      }
      case "MemberAccess": {
        this.visitExpression(node.object as AstNode);
        const objType = this.inferType(node.object as AstNode);
        const prop = node.property as string;
        const pointer = (node.pointer as boolean) === true;
        const res = this.memberLookup(objType, prop, pointer);
        if (res.kind === "arrow-on-value") {
          this.addFinding(
            "invalid-member-access",
            "Left of '->' is not a pointer",
            `The left operand of '->' on line ${node.loc?.line} has type ${objType}; only pointers can be dereferenced with '->'.`,
            "HIGH",
            node.loc,
            "Use '.' if the value is a struct, or make it a pointer.",
          );
        } else if (res.kind === "dot-on-pointer") {
          this.addFinding(
            "invalid-member-access",
            "Left of '.' is a pointer; use '->'",
            `The left operand of '.' on line ${node.loc?.line} has type ${objType}. Member access through a pointer requires '->'.`,
            "HIGH",
            node.loc,
            `Replace '.' with '->' (or dereference first: (*ptr).${prop}).`,
          );
        } else if (res.kind === "not-struct") {
          this.addFinding(
            "invalid-member-access",
            `Request for member '${prop}' in something not a struct`,
            `The type ${objType} has no members (line ${node.loc?.line}).`,
            "HIGH",
            node.loc,
            "Only structs expose members; check the type of the expression.",
          );
        } else if (res.kind === "incomplete") {
          this.addFinding(
            "incomplete-type",
            "Member access on incomplete struct",
            `The struct type ${objType} is declared but not defined, so its members are unknown (line ${node.loc?.line}).`,
            "HIGH",
            node.loc,
            "Define the struct before accessing its members.",
          );
        } else if (res.kind === "no-member") {
          const tag = this.structTagOf(
            (objType ?? "").replace(/\[.*\]$/, "").replace(/\*+$/, ""),
          );
          this.addFinding(
            "invalid-member",
            `'struct ${tag}' has no member named '${prop}'`,
            `Member '${prop}' on line ${node.loc?.line} does not exist in 'struct ${tag}'.`,
            "HIGH",
            node.loc,
            `Check the spelling or add '${prop}' to the struct definition.`,
          );
        }
        return;
      }
      case "InitializerList": {
        for (const el of (node.elements as AstNode[]) ?? []) this.visitExpression(el);
        return;
      }
      default: {
        for (const child of childNodes(node)) this.visitExpression(child);
      }
    }
  }

  private checkCall(node: AstNode): void {
    const name = node.name as string;
    const args = (node.arguments as AstNode[]) ?? [];
    const sym = this.resolve(name);

    if (!sym) {
      this.addFinding(
        "undeclared-function",
        `Call to undeclared function '${name}'`,
        `Function '${name}' is called on line ${node.loc?.line} but has not been declared.`,
        "HIGH",
        node.loc,
        `Declare or define '${name}' before calling it, or include the right header.`,
      );
      return;
    }

    if (sym.kind !== "Function" && sym.kind !== "Builtin") {
      this.addFinding(
        "not-a-function",
        `'${name}' is not a function`,
        `'${name}' was declared as a ${sym.kind.toLowerCase()} but is called like a function on line ${node.loc?.line}.`,
        "HIGH",
        node.loc,
        "Use a function name for the call, or rename the variable.",
      );
    }

    // Argument checking for known signatures (builtins + declared functions).
    const signature = sym.type;
    const paramsPart = signature.slice(signature.indexOf("(") + 1, signature.lastIndexOf(")"));
    const paramTypes: (string | null)[] = [];
    let variadic = false;
    for (const p of paramsPart.split(",")) {
      const t = p.trim();
      if (!t) continue;
      if (t === "...") {
        variadic = true;
        continue;
      }
      const pieces = t.split(/\s+/);
      paramTypes.push(pieces[0] ?? null);
    }

    const required = paramTypes.length;
    if (!variadic && args.length !== required) {
      this.addFinding(
        "wrong-argument-count",
        `Function '${name}' expects ${required} argument(s) but ${args.length} were provided`,
        `Call on line ${node.loc?.line} passes ${args.length} argument(s) to '${name}', which takes ${required}.`,
        args.length < required ? "HIGH" : "MEDIUM",
        node.loc,
        `Pass exactly ${required} argument(s) to '${name}'.`,
      );
    } else if (variadic && args.length < required) {
      this.addFinding(
        "wrong-argument-count",
        `Function '${name}' expects at least ${required} argument(s) but ${args.length} were provided`,
        `Call on line ${node.loc?.line} passes too few arguments to '${name}'.`,
        "HIGH",
        node.loc,
        `Pass at least ${required} argument(s) to '${name}'.`,
      );
    }

    for (let i = 0; i < args.length && i < paramTypes.length; i++) {
      const expected = paramTypes[i];
      if (!expected) continue;
      const arg = args[i];
      const actual = this.inferType(arg);
      if (!actual) continue;
      const check = this.assignable(
        expected,
        actual,
        arg.kind === "Literal" ? (arg.valueType as string) : undefined,
      );
      if (!check.ok) {
        this.addFinding(
          "wrong-argument-type",
          `Argument ${i + 1} of '${name}' expects type ${expected} but got ${actual}`,
          `Call on line ${node.loc?.line} passes a value of type ${actual} where ${expected} was expected.`,
          "MEDIUM",
          arg.loc ?? node.loc,
          `Pass a value of type ${expected} as argument ${i + 1}.`,
        );
      }
    }

    // Recurse into arguments for undeclared identifiers etc.
    for (const arg of args) this.visitExpression(arg);
  }
}

export function analyzeSemantics(ast: AstNode | null): ModuleOutput<SymbolEntry[]> {
  const analyzer = new SemanticAnalyzer();
  analyzer.analyze(ast);
  return {
    data: analyzer.symbolTable,
    findings: analyzer.findings,
  };
}