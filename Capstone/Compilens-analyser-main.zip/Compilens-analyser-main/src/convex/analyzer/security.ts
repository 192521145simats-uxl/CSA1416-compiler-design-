/**
 * Security analysis.
 *
 * Modular rule engine. Every rule has an id, name, description, severity,
 * CWE reference and a `detect` implementation. Detection walks the real AST
 * (and falls back to a token scan when the parser could not build a tree),
 * so findings are derived from actual code, never hardcoded.
 */
import type { AstNode, Finding, ModuleOutput, Token } from "./types";

export interface SecurityRule {
  id: string;
  name: string;
  description: string;
  severity: "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  cwe: string;
  recommendation: string;
}

const RULES: Record<string, SecurityRule> = {
  "hardcoded-secret": {
    id: "hardcoded-secret",
    name: "Hardcoded Credential",
    description:
      "A variable whose name suggests a credential (password, secret, API key, token) is initialized with a string literal, meaning the credential is embedded in the source code.",
    severity: "HIGH",
    cwe: "CWE-798",
    recommendation:
      "Do not hardcode credentials in source code. Load them from secure configuration, environment variables, or a secret manager at runtime.",
  },
  gets: {
    id: "gets",
    name: "Unsafe gets() Call",
    description:
      "gets() reads input into a fixed buffer with no bounds checking and cannot prevent a buffer overflow.",
    severity: "HIGH",
    cwe: "CWE-242",
    recommendation:
      "Replace gets() with fgets(buffer, sizeof(buffer), stdin), which bounds the read.",
  },
  strcpy: {
    id: "strcpy",
    name: "Unsafe strcpy() Call",
    description:
      "strcpy() copies a string without bounds checking. If the source is longer than the destination buffer it causes a buffer overflow.",
    severity: "HIGH",
    cwe: "CWE-120",
    recommendation:
      "Use strncpy() or snprintf() with an explicit size limit, or better, copy into a dynamically sized buffer.",
  },
  strcat: {
    id: "strcat",
    name: "Unsafe strcat() Call",
    description:
      "strcat() appends a string without checking the destination capacity and can overflow the buffer.",
    severity: "HIGH",
    cwe: "CWE-120",
    recommendation:
      "Use strncat(dest, src, sizeof(dest) - strlen(dest) - 1) with an explicit bound.",
  },
  sprintf: {
    id: "sprintf",
    name: "Unsafe sprintf() Call",
    description:
      "sprintf() writes formatted output into a buffer with no length check and can overflow it.",
    severity: "HIGH",
    cwe: "CWE-120",
    recommendation:
      "Use snprintf(buffer, sizeof(buffer), format, ...) which guarantees the buffer cannot be overrun.",
  },
  system: {
    id: "system",
    name: "System Command Execution",
    description:
      "system() executes a shell command. If any part of the command is derived from user input, it enables OS command injection.",
    severity: "HIGH",
    cwe: "CWE-78",
    recommendation:
      "Avoid system(). If it is required, never interpolate untrusted input; use execve() with an argument array instead.",
  },
  popen: {
    id: "popen",
    name: "Popen Command Execution",
    description:
      "popen() spawns a shell command and pipes its output. Untrusted input in the command string enables command injection.",
    severity: "HIGH",
    cwe: "CWE-78",
    recommendation:
      "Avoid popen() with interpolated input. Use fork/exec with explicit arguments when possible.",
  },
  "unsafe-scanf": {
    id: "unsafe-scanf",
    name: "Unbounded scanf() %s",
    description:
      "scanf() with a '%s' conversion has no width limit, so a long input line will overflow the destination buffer.",
    severity: "MEDIUM",
    cwe: "CWE-120",
    recommendation:
      "Limit the width, e.g. scanf(\"%31s\", buffer) for a 32-byte buffer, or use fgets() instead.",
  },
};

const SECRET_NAME_PATTERN =
  /\b(password|passwd|pwd|secret|apikey|api[_-]?key|access[_-]?key|private[_-]?key|session[_-]?key|auth[_-]?token|token)\b/i;

const DANGEROUS_CALLS = new Set(["gets", "strcpy", "strcat", "sprintf", "system", "popen"]);

const childNodes = (node: AstNode): AstNode[] => {
  const result: AstNode[] = [];
  for (const key of Object.keys(node)) {
    if (key === "kind" || key === "loc") continue;
    const value = node[key];
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item && typeof item === "object" && typeof (item as AstNode).kind === "string") {
          result.push(item as AstNode);
        }
      }
    } else if (value && typeof value === "object" && typeof (value as AstNode).kind === "string") {
      result.push(value as AstNode);
    }
  }
  return result;
};

function locOf(node: AstNode | null, fallbackLine = 0, fallbackCol = 0) {
  return {
    line: node?.loc?.line ?? fallbackLine,
    column: node?.loc?.column ?? fallbackCol,
  };
}

export function analyzeSecurity(
  ast: AstNode | null,
  tokens: Token[],
): ModuleOutput<Finding[]> {
  const findings: Finding[] = [];
  const emit = (
    ruleId: string,
    message: string,
    description: string,
    line: number,
    column: number,
  ) => {
    const rule = RULES[ruleId];
    findings.push({
      id: `SEC-${findings.length + 1}`,
      category: "SECURITY",
      rule: rule.id,
      message,
      description,
      line,
      column,
      severity: rule.severity,
      cwe: rule.cwe,
      recommendation: rule.recommendation,
      source: "Security",
    });
  };

  const checkCall = (node: AstNode) => {
    const name = node.name as string;
    const args = (node.arguments as AstNode[]) ?? [];
    const { line, column } = locOf(node);

    if (DANGEROUS_CALLS.has(name)) {
      emit(
        name,
        `${name}() is a known unsafe function`,
        `${RULES[name].description} (line ${line})`,
        line,
        column,
      );
    }

    if (name === "scanf" && args.length > 0 && args[0]?.kind === "Literal") {
      const format = (args[0].value as string).slice(1, -1);
      // Flag unbounded string reads: %s or %[..] without a leading width.
      const unbounded = /%(?!\d+)(\[[^\]]*\]|[s])/.test(format);
      if (unbounded) {
        emit(
          "unsafe-scanf",
          "Unbounded %s read in scanf()",
          `${RULES["unsafe-scanf"].description} (line ${line})`,
          line,
          column,
        );
      }
    }
  };

  const walk = (node: AstNode | null) => {
    if (!node) return;
    if (node.kind === "CallExpression") checkCall(node);
    if (node.kind === "VariableDeclaration") {
      for (const decl of (node.declarations as AstNode[]) ?? []) {
        const init = decl.init as AstNode | null;
        const name = decl.name as string;
        if (init && init.kind === "Literal" && (init.valueType as string) === "string") {
          if (SECRET_NAME_PATTERN.test(name)) {
            const { line, column } = locOf(decl);
            emit(
              "hardcoded-secret",
              `Hardcoded credential in '${name}'`,
              `${RULES["hardcoded-secret"].description} (line ${line})`,
              line,
              column,
            );
          }
        }
      }
    }
    if (node.kind === "AssignmentExpression") {
      const left = node.left as AstNode | null;
      const right = node.right as AstNode | null;
      let targetName: string | null = null;
      if (left?.kind === "Identifier") targetName = left.name as string;
      else if (left?.kind === "MemberAccess") targetName = left.property as string;
      if (targetName && right?.kind === "Literal" && (right.valueType as string) === "string") {
        if (SECRET_NAME_PATTERN.test(targetName)) {
          const { line, column } = locOf(node);
          emit(
            "hardcoded-secret",
            `Hardcoded credential assigned to '${targetName}'`,
            `${RULES["hardcoded-secret"].description} (line ${line})`,
            line,
            column,
          );
        }
      }
    }
    for (const child of childNodes(node)) walk(child);
  };

  const astUsable = ast !== null && (ast.body as AstNode[] | undefined)?.length !== 0;

  if (astUsable) {
    walk(ast);
  } else {
    // Parser failed to build a tree — fall back to a token scan so security
    // analysis still produces useful results.
    for (const token of tokens) {
      if (token.type === "IDENTIFIER" && DANGEROUS_CALLS.has(token.value)) {
        // Only flag identifier uses that look like calls (next non-comment token is '(')
        emit(
          token.value,
          `${token.value}() is a known unsafe function`,
          `${RULES[token.value].description} (line ${token.line})`,
          token.line,
          token.column,
        );
      }
    }
  }

  return { data: findings, findings };
}