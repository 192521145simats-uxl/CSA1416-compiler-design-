/**
 * Shared type definitions for the C source code analysis engine.
 * This module is intentionally free of any Convex or server dependencies so
 * it can be imported both by the Convex backend (server-side analysis) and by
 * the frontend (editor highlighting + type safety).
 */

export type Severity = "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export type FindingCategory =
  | "LEXICAL"
  | "SYNTAX"
  | "SEMANTIC"
  | "SECURITY"
  | "RUNTIME";

export type TokenType =
  | "KEYWORD"
  | "IDENTIFIER"
  | "INTEGER"
  | "FLOAT"
  | "STRING"
  | "CHAR"
  | "OPERATOR"
  | "PUNCTUATION"
  | "PREPROCESSOR"
  | "COMMENT"
  | "INVALID"
  | "EOF";

export interface Token {
  type: TokenType;
  value: string;
  /** 1-based line */
  line: number;
  /** 1-based column */
  column: number;
  /** 0-based character offset in the source */
  start: number;
  /** exclusive end offset */
  end: number;
}

export interface Finding {
  id: string;
  category: FindingCategory;
  rule: string;
  message: string;
  description: string;
  line: number;
  column: number;
  severity: Severity;
  /** e.g. "CWE-798", or "" when not applicable */
  cwe: string;
  recommendation: string;
  /** module that produced the finding: Lexical, Parser, Semantic, Security, Runtime */
  source: string;
}

export interface SourceLocation {
  line: number;
  column: number;
  start: number;
  end: number;
}

/** AST nodes are plain objects with a `kind` + optional `loc`; other fields vary per kind. */
export interface AstNode {
  kind: string;
  loc: SourceLocation | null;
  [key: string]: unknown;
}

export interface SymbolEntry {
  name: string;
  type: string;
  kind: "Variable" | "Function" | "Parameter" | "Constant" | "Builtin" | "Type";
  scope: string;
  /** 1-based declaration line, 0 for builtins */
  line: number;
  initialized: boolean;
  builtin?: boolean;
}

export interface SeveritySummary {
  total: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  info: number;
}

export interface AnalysisMetadata {
  lineCount: number;
  tokenCount: number;
  analysisTimeMs: number;
  syntaxErrorCount: number;
  semanticErrorCount: number;
  securityCount: number;
  runtimeCount: number;
}

export interface AnalysisResult {
  success: boolean;
  language: string;
  filename: string;
  tokens: Token[];
  ast: AstNode | null;
  symbolTable: SymbolEntry[];
  findings: Finding[];
  summary: SeveritySummary;
  metadata: AnalysisMetadata;
  /** human-readable notes explaining why a module was partially skipped, if any */
  notes: string[];
}

/** What a single analyzer module produced. */
export interface ModuleOutput<T> {
  data: T;
  findings: Finding[];
}

export const SEVERITY_ORDER: Record<Severity, number> = {
  CRITICAL: 0,
  HIGH: 1,
  MEDIUM: 2,
  LOW: 3,
  INFO: 4,
};

export const SEVERITY_COLORS: Record<Severity, string> = {
  CRITICAL: "#dc2626",
  HIGH: "#ea580c",
  MEDIUM: "#d97706",
  LOW: "#2563eb",
  INFO: "#64748b",
};

export function severityRank(severity: Severity): number {
  return SEVERITY_ORDER[severity];
}

export function compareFindings(a: Finding, b: Finding): number {
  if (a.line !== b.line) return a.line - b.line;
  if (a.column !== b.column) return a.column - b.column;
  return severityRank(a.severity) - severityRank(b.severity);
}

export function buildSummary(findings: Finding[]): SeveritySummary {
  const summary: SeveritySummary = {
    total: findings.length,
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    info: 0,
  };
  for (const f of findings) {
    summary[f.severity.toLowerCase() as "critical" | "high" | "medium" | "low" | "info"] += 1;
  }
  return summary;
}