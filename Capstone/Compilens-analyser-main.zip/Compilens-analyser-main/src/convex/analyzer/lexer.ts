/**
 * Lexical analyzer for the supported C subset.
 *
 * Produces a real token stream with 1-based line/column and 0-based
 * character offsets, plus lexical findings for malformed input
 * (invalid characters, unterminated strings, unterminated block comments).
 */
import type { Finding, ModuleOutput, SourceLocation, Token, TokenType } from "./types";

const KEYWORDS = new Set([
  "int",
  "char",
  "float",
  "double",
  "void",
  "if",
  "else",
  "while",
  "for",
  "return",
  "sizeof",
  "switch",
  "case",
  "default",
  "break",
  "continue",
  "struct",
  "typedef",
  "const",
]);

const TWO_CHAR_OPERATORS = [
  "++",
  "--",
  "==",
  "!=",
  ">=",
  "<=",
  "&&",
  "||",
  "+=",
  "-=",
  "*=",
  "/=",
  "%=",
  "->",
];

const ONE_CHAR_OPERATORS = new Set([
  "+",
  "-",
  "*",
  "/",
  "%",
  "=",
  "!",
  ">",
  "<",
  "&",
  "|",
  "~",
  "^",
  "?",
  ":",
  ".",
]);

const PUNCTUATION = new Set(["(", ")", "{", "}", "[", "]", ";", ","]);

const DIGITS = new Set("0123456789");

function isDigit(ch: string): boolean {
  return ch >= "0" && ch <= "9";
}

function isHexDigit(ch: string): boolean {
  return isDigit(ch) || (ch >= "a" && ch <= "f") || (ch >= "A" && ch <= "F");
}

function isIdentStart(ch: string): boolean {
  return (ch >= "a" && ch <= "z") || (ch >= "A" && ch <= "Z") || ch === "_";
}

function isIdentPart(ch: string): boolean {
  return isIdentStart(ch) || isDigit(ch);
}

export interface LexerState {
  tokens: Token[];
  findings: Finding[];
}

export function lexSource(source: string): ModuleOutput<Token[]> {
  const tokens: Token[] = [];
  const findings: Finding[] = [];
  let pos = 0;
  let line = 1;
  let column = 1;
  const n = source.length;

  const loc = (start: number, end: number, l = line, c = column): SourceLocation => ({
    line: l,
    column: c,
    start,
    end,
  });

  const pushToken = (type: TokenType, start: number, startLine: number, startCol: number) => {
    tokens.push({
      type,
      value: source.slice(start, pos),
      line: startLine,
      column: startCol,
      start,
      end: pos,
    });
  };

  const pushFinding = (
    rule: string,
    message: string,
    description: string,
    severity: "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
    start: number,
    startLine: number,
    startCol: number,
    recommendation: string,
  ) => {
    findings.push({
      id: `LEX-${findings.length + 1}`,
      category: "LEXICAL",
      rule,
      message,
      description,
      line: startLine,
      column: startCol,
      severity,
      cwe: "",
      recommendation,
      source: "Lexical",
    });
    void loc(start, pos, startLine, startCol);
  };

  const advance = () => {
    const ch = source[pos];
    pos += 1;
    if (ch === "\n") {
      line += 1;
      column = 1;
    } else {
      column += 1;
    }
    return ch;
  };

  const peek = (offset = 0): string => source[pos + offset] ?? "";

  while (pos < n) {
    const ch = source[pos];

    // Whitespace
    if (ch === " " || ch === "\t" || ch === "\r" || ch === "\n") {
      advance();
      continue;
    }

    const start = pos;
    const startLine = line;
    const startCol = column;

    // Preprocessor directives: #include <stdio.h>, #define X 5, ...
    if (ch === "#") {
      while (pos < n && source[pos] !== "\n") advance();
      pushToken("PREPROCESSOR", start, startLine, startCol);
      continue;
    }

    // Line comment
    if (ch === "/" && peek(1) === "/") {
      while (pos < n && source[pos] !== "\n") advance();
      pushToken("COMMENT", start, startLine, startCol);
      continue;
    }

    // Block comment
    if (ch === "/" && peek(1) === "*") {
      advance();
      advance();
      let closed = false;
      while (pos < n) {
        if (source[pos] === "*" && peek(1) === "/") {
          advance();
          advance();
          closed = true;
          break;
        }
        advance();
      }
      if (!closed) {
        pushToken("COMMENT", start, startLine, startCol);
        pushFinding(
          "unterminated-comment",
          "Unterminated block comment",
          `A block comment starting on line ${startLine} is never closed with "*/". Everything after it is treated as a comment, which usually hides the rest of the program.`,
          "HIGH",
          start,
          startLine,
          startCol,
          "Close the block comment with */, or convert it to a // line comment.",
        );
        continue;
      }
      pushToken("COMMENT", start, startLine, startCol);
      continue;
    }

    // String literal
    if (ch === '"') {
      advance();
      let closed = false;
      while (pos < n) {
        const c = source[pos];
        if (c === "\\") {
          advance();
          if (pos < n) advance();
          continue;
        }
        if (c === '"') {
          advance();
          closed = true;
          break;
        }
        if (c === "\n") break;
        advance();
      }
      pushToken("STRING", start, startLine, startCol);
      if (!closed) {
        pushFinding(
          "unterminated-string",
          "Unterminated string literal",
          `A string literal starting on line ${startLine} is missing its closing double quote.`,
          "HIGH",
          start,
          startLine,
          startCol,
          "Add the closing \" to terminate the string literal.",
        );
      }
      continue;
    }

    // Character literal
    if (ch === "'") {
      advance();
      let closed = false;
      while (pos < n) {
        const c = source[pos];
        if (c === "\\") {
          advance();
          if (pos < n) advance();
          continue;
        }
        if (c === "'") {
          advance();
          closed = true;
          break;
        }
        if (c === "\n") break;
        advance();
      }
      pushToken("CHAR", start, startLine, startCol);
      if (!closed) {
        pushFinding(
          "unterminated-char",
          "Unterminated character literal",
          `A character literal starting on line ${startLine} is missing its closing single quote.`,
          "MEDIUM",
          start,
          startLine,
          startCol,
          "Add the closing ' to terminate the character literal.",
        );
      }
      continue;
    }

    // Numbers: integer (decimal/hex) and float
    if (isDigit(ch) || (ch === "." && isDigit(peek(1)))) {
      let isFloat = false;
      if (ch === "0" && (peek(1) === "x" || peek(1) === "X")) {
        advance();
        advance();
        while (pos < n && isHexDigit(source[pos])) advance();
        pushToken("INTEGER", start, startLine, startCol);
        continue;
      }
      while (pos < n && isDigit(source[pos])) advance();
      if (source[pos] === "." ) {
        isFloat = true;
        advance();
        while (pos < n && isDigit(source[pos])) advance();
      }
      if (source[pos] === "e" || source[pos] === "E") {
        const savePos = pos;
        const saveLine = line;
        const saveCol = column;
        advance();
        if (source[pos] === "+" || source[pos] === "-") advance();
        if (isDigit(source[pos])) {
          isFloat = true;
          while (pos < n && isDigit(source[pos])) advance();
        } else {
          // Not an exponent after all; rewind.
          pos = savePos;
          line = saveLine;
          column = saveCol;
        }
      }
      pushToken(isFloat ? "FLOAT" : "INTEGER", start, startLine, startCol);
      continue;
    }

    // Identifier / keyword
    if (isIdentStart(ch)) {
      while (pos < n && isIdentPart(source[pos])) advance();
      const word = source.slice(start, pos);
      pushToken(KEYWORDS.has(word) ? "KEYWORD" : "IDENTIFIER", start, startLine, startCol);
      continue;
    }

    // Two-character operators
    const two = source.slice(pos, pos + 2);
    if (TWO_CHAR_OPERATORS.includes(two)) {
      advance();
      advance();
      pushToken("OPERATOR", start, startLine, startCol);
      continue;
    }

    // Single-char operators / punctuation
    if (ONE_CHAR_OPERATORS.has(ch)) {
      advance();
      pushToken("OPERATOR", start, startLine, startCol);
      continue;
    }
    if (PUNCTUATION.has(ch)) {
      advance();
      pushToken("PUNCTUATION", start, startLine, startCol);
      continue;
    }

    // Anything else: invalid symbol
    advance();
    pushToken("INVALID", start, startLine, startCol);
    pushFinding(
      "invalid-character",
      `Invalid character '${ch}'`,
      `The character '${ch}' on line ${startLine}, column ${startCol} is not valid in C source code and cannot be tokenized.`,
      "MEDIUM",
      start,
      startLine,
      startCol,
      "Remove the invalid character or replace it with valid C syntax.",
    );
  }

  // EOF token (not emitted as a finding, used by the parser)
  tokens.push({
    type: "EOF",
    value: "",
    line,
    column,
    start: pos,
    end: pos,
  });

  return { data: tokens, findings };
}