/**
 * Static runtime-risk analysis.
 *
 * This module performs static analysis only — findings are reported as
 * *potential* runtime errors, never as guaranteed ones, because the code is
 * not executed in a sandbox. It tracks simple constant values declared in the
 * code and checks obvious cases of division by zero, out-of-bounds array
 * access, use of uninitialized variables and null pointer dereferences.
 */
import type { AstNode, Finding, ModuleOutput, SymbolEntry } from "./types";

const childNodes = (node: AstNode): AstNode[] => {
  const result: AstNode[] = [];
  for (const key of Object.keys(node)) {
    if (key === "kind" || key === "loc") continue;
    const value = node[key];
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item && typeof item === "object" && typeof (item as AstNode).kind === "string") {
          result.push(item as AstNode);
        }
      }
    } else if (value && typeof value === "object" && typeof (value as AstNode).kind === "string") {
      result.push(value as AstNode);
    }
  }
  return result;
};

interface FlowState {
  /** name → known constant value (numbers only; null for unknown/string). */
  constants: Map<string, number | null>;
  /** name → true once it may have been assigned / address taken. */
  initialized: Map<string, boolean>;
  /** name → declared array size. */
  arrays: Map<string, number>;
  /** name → true when the variable was initialized with NULL or 0 as a pointer. */
  nullPointers: Set<string>;
}

export interface RuntimeOutput extends ModuleOutput<Finding[]> {
  couldNotRun: boolean;
}

export function analyzeRuntime(
  ast: AstNode | null,
  symbolTable: SymbolEntry[],
): RuntimeOutput {
  const findings: Finding[] = [];
  const couldNotRun =
    ast === null ||
    ast.kind !== "Program" ||
    !Array.isArray(ast.body) ||
    (ast.body as AstNode[]).length === 0;

  const declaredVars = new Set(
    symbolTable
      .filter((s) => s.kind === "Variable" || s.kind === "Parameter" || s.kind === "Constant")
      .map((s) => s.name),
  );

  let idCounter = 0;
  const emit = (
    rule: string,
    message: string,
    description: string,
    severity: "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
    cwe: string,
    node: AstNode | null,
    recommendation: string,
  ) => {
    idCounter += 1;
    findings.push({
      id: `RT-${idCounter}`,
      category: "RUNTIME",
      rule,
      message,
      description,
      line: node?.loc?.line ?? 0,
      column: node?.loc?.column ?? 0,
      severity,
      cwe,
      recommendation,
      source: "Runtime",
    });
  };

  if (couldNotRun) {
    return {
      data: findings,
      findings,
      couldNotRun: true,
    };
  }

  /** Try to get a numeric constant for an expression. */
  const constValueOf = (node: AstNode | null, state: FlowState): number | null => {
    if (!node) return null;
    if (node.kind === "Literal") {
      const v = node.value as string;
      const t = node.valueType as string;
      if (t === "int") return parseInt(v, 10);
      if (t === "float") {
        const f = parseFloat(v);
        return Number.isFinite(f) ? f : null;
      }
      return null;
    }
    if (node.kind === "Identifier") {
      const name = node.name as string;
      if (name === "NULL") return 0;
      return state.constants.has(name) ? state.constants.get(name) ?? null : null;
    }
    if (node.kind === "UnaryExpression" && node.operator === "-") {
      const v = constValueOf(node.operand as AstNode, state);
      return v === null ? null : -v;
    }
    if (node.kind === "BinaryExpression") {
      const l = constValueOf(node.left as AstNode, state);
      const r = constValueOf(node.right as AstNode, state);
      if (l === null || r === null) return null;
      switch (node.operator) {
        case "+": return l + r;
        case "-": return l - r;
        case "*": return l * r;
        case "/": return r === 0 ? null : l / r;
        case "%": return r === 0 ? null : l % r;
        default: return null;
      }
    }
    return null;
  };

  const markRead = (node: AstNode | null, state: FlowState, _scopeLabel?: string): void => {
    if (!node) return;
    if (node.kind === "Identifier") {
      const name = node.name as string;
      if (!declaredVars.has(name)) return;
      const isConstant = state.constants.has(name);
      const initState = state.initialized.get(name);
      if (initState !== true && !isConstant && name !== "NULL") {
        emit(
          "uninitialized-variable",
          `Potential use of uninitialized variable '${name}'`,
          `Variable '${name}' may be read on line ${node.loc?.line} before it has been assigned a value. This is undefined behavior in C.`,
          "MEDIUM",
          "CWE-457",
          node,
          `Initialize '${name}' before reading it, e.g. ${name} = 0; at its declaration.`,
        );
      }
      return;
    }
    // Composite expressions (binaries, calls, array accesses, assignments …)
    // get the full walk so division-by-zero, bounds, null-pointer and
    // uninitialized checks run no matter where the expression is nested.
    visitExpression(node, state);
  };

  const markWrite = (node: AstNode | null, state: FlowState): void => {
    if (!node) return;
    if (node.kind === "Identifier") {
      state.initialized.set(node.name as string, true);
      return;
    }
    if (node.kind === "ArrayAccess") {
      // Writing arr[i] = ... initializes the array but still reads `i` and
      // can go out of bounds, so both are checked here.
      checkArrayAccess(node, state);
      markRead(node.index as AstNode | null, state);
      const obj = node.object as AstNode | null;
      if (obj?.kind === "Identifier") {
        state.initialized.set(obj.name as string, true);
      }
      return;
    }
    if (node.kind === "UnaryExpression" && node.operator === "*") {
      // *p = … writes through p but still dereferences it.
      checkNullDeref(node, state);
      markWrite(node.operand as AstNode | null, state);
      return;
    }
    if (node.kind === "UnaryExpression" && node.operator === "&") {
      // Address taken (e.g. &x passed to scanf) — treat as possibly written.
      const operand = node.operand as AstNode | null;
      if (operand?.kind === "Identifier") {
        state.initialized.set(operand.name as string, true);
      }
      return;
    }
    for (const child of childNodes(node)) markWrite(child, state);
  };

  const checkBinary = (node: AstNode, state: FlowState): void => {
    const op = node.operator as string;
    if (op === "/" || op === "%") {
      const divisor = constValueOf(node.right as AstNode, state);
      if (divisor === 0) {
        const divisorDesc =
          (node.right as AstNode)?.kind === "Identifier"
            ? `variable '${(node.right as AstNode).name as string}' is known to be 0`
            : "the divisor is the constant 0";
        emit(
          "division-by-zero",
          "Potential division by zero",
          `The ${op === "/" ? "division" : "modulo"} on line ${node.loc?.line} divides by zero (${divisorDesc}). This will crash the program at runtime.`,
          (node.right as AstNode)?.kind === "Identifier" ? "MEDIUM" : "HIGH",
          "",
          node,
          "Guard the operation, e.g. if (b != 0) { ... } or check the divisor before dividing.",
        );
      }
    }
  };

  const checkArrayAccess = (node: AstNode, state: FlowState): void => {
    const obj = node.object as AstNode | null;
    if (!obj || obj.kind !== "Identifier") return;
    const size = state.arrays.get(obj.name as string);
    if (size === undefined) return;
    const idx = constValueOf(node.index as AstNode, state);
    if (idx === null) return;
    if (idx < 0 || idx >= size) {
      emit(
        "array-out-of-bounds",
        `Potential array out of bounds access`,
        `Array '${obj.name as string}' has size ${size} but index ${idx} is used on line ${node.loc?.line}, which is outside the valid range [0, ${size - 1}].`,
        "MEDIUM",
        "CWE-129",
        node,
        `Use an index between 0 and ${size - 1}, or check the index against the array size before accessing it.`,
      );
    }
  };

  const checkNullDeref = (node: AstNode, state: FlowState): void => {
    if (node.kind === "UnaryExpression" && node.operator === "*") {
      const operand = node.operand as AstNode | null;
      if (operand?.kind === "Identifier" && state.nullPointers.has(operand.name as string)) {
        emit(
          "null-pointer-dereference",
          `Potential null pointer dereference`,
          `Pointer '${operand.name as string}' is known to be NULL (line ${node.loc?.line}), and dereferencing NULL crashes the program.`,
          "HIGH",
          "CWE-476",
          node,
          "Check the pointer for NULL before dereferencing it, e.g. if (p != NULL) { ... }.",
        );
      }
    }
  };

  const visitStatement = (node: AstNode | null, state: FlowState): void => {
    if (!node) return;
    switch (node.kind) {
      case "BlockStatement": {
        for (const stmt of (node.body as AstNode[]) ?? []) visitStatement(stmt, state);
        return;
      }
      case "VariableDeclaration": {
        for (const decl of (node.declarations as AstNode[]) ?? []) {
          const name = decl.name as string;
          const type = decl.type as string;
          const init = decl.init as AstNode | null;
          const size = decl.arraySize as number | null;
          if (size !== null && size !== undefined) {
            state.arrays.set(name, size);
          }
          if (init) {
            const constVal = constValueOf(init, state);
            state.initialized.set(name, true);
            state.constants.set(name, constVal);
            // Pointer initialized to NULL or 0.
            if (type.endsWith("*")) {
              const raw =
                init.kind === "Identifier" && (init.name as string) === "NULL";
              const zero = init.kind === "Literal" && (init.valueType as string) === "int" && parseInt(init.value as string, 10) === 0;
              if (raw || zero) state.nullPointers.add(name);
            }
            if (init.kind !== "Literal") markRead(init, state, "");
          } else {
            state.initialized.set(name, false);
          }
        }
        return;
      }
      case "ExpressionStatement": {
        const expr = node.expression as AstNode | null;
        if (expr) visitExpression(expr, state);
        return;
      }
      case "IfStatement": {
        const test = node.test as AstNode | null;
        markRead(test, state);
        visitStatement(node.consequent as AstNode | null, state);
        visitStatement(node.alternate as AstNode | null, state);
        return;
      }
      case "WhileStatement": {
        const test = node.test as AstNode | null;
        markRead(test, state);
        visitStatement(node.body as AstNode | null, state);
        return;
      }
      case "ForStatement": {
        const init = node.init as AstNode | null;
        if (init) {
          // The initializer can be a declaration or an expression (e.g. i = 0).
          if (init.kind === "VariableDeclaration") visitStatement(init, state);
          else visitExpression(init, state);
        }
        const cond = node.cond as AstNode | null;
        markRead(cond, state);
        visitStatement(node.body as AstNode | null, state);
        if (node.update) visitExpression(node.update as AstNode, state);
        return;
      }
      case "SwitchStatement": {
        markRead(node.discriminant as AstNode | null, state);
        for (const c of (node.cases as AstNode[]) ?? []) {
          markRead((c.test as AstNode | null) ?? null, state);
          for (const stmt of (c.body as AstNode[]) ?? []) visitStatement(stmt, state);
        }
        return;
      }
      case "BreakStatement":
      case "ContinueStatement":
        return;
      case "ReturnStatement": {
        markRead(node.argument as AstNode | null, state);
        return;
      }
      case "EmptyStatement":
      case "PreprocessorDirective":
        return;
      default: {
        for (const child of childNodes(node)) visitStatement(child, state);
      }
    }
  };

  const visitExpression = (node: AstNode | null, state: FlowState): void => {
    if (!node) return;
    switch (node.kind) {
      case "Identifier": {
        markRead(node, state, "");
        return;
      }
      case "BinaryExpression": {
        markRead(node.left as AstNode | null, state, "");
        markRead(node.right as AstNode | null, state, "");
        checkBinary(node, state);
        return;
      }
      case "UnaryExpression": {
        const op = node.operator as string;
        if (op === "&") {
          markWrite(node, state);
        } else if (op === "++" || op === "--") {
          markRead(node.operand as AstNode | null, state, "");
          markWrite(node.operand as AstNode | null, state);
        } else {
          markRead(node.operand as AstNode | null, state, "");
        }
        checkNullDeref(node, state);
        if (op === "sizeof") return;
        return;
      }
      case "AssignmentExpression": {
        markWrite(node.left as AstNode | null, state);
        const right = node.right as AstNode | null;
        markRead(right, state, "");
        const leftIdent =
          (node.left as AstNode | null)?.kind === "Identifier"
            ? ((node.left as AstNode).name as string)
            : null;
        if (leftIdent) {
          const v = constValueOf(right, state);
          state.constants.set(leftIdent, v);
          if (right?.kind === "Literal" && (right.valueType as string) === "string") {
            state.constants.set(leftIdent, null);
          }
        }
        return;
      }
      case "CallExpression": {
        for (const arg of (node.arguments as AstNode[]) ?? []) markRead(arg, state, "");
        return;
      }
      case "ArrayAccess": {
        markRead(node.object as AstNode | null, state, "");
        markRead(node.index as AstNode | null, state, "");
        checkArrayAccess(node, state);
        return;
      }
      case "MemberAccess": {
        // p.x reads the object; the member name is a string, not a symbol.
        markRead(node.object as AstNode | null, state, "");
        return;
      }
      default: {
        for (const child of childNodes(node)) visitExpression(child, state);
      }
    }
  };

  const rootState: FlowState = {
    constants: new Map(),
    initialized: new Map(),
    arrays: new Map(),
    nullPointers: new Set(),
  };

  // Seed #define constants so macro-style values are treated as initialized.
  for (const top of (ast.body as AstNode[]) ?? []) {
    if (top.kind === "PreprocessorDirective") {
      const m = (top.value as string).match(/^#define\s+([A-Za-z_][A-Za-z0-9_]*)\s+(.+)$/);
      if (m) {
        const v = m[2].trim();
        if (/^[+-]?\d+$/.test(v)) {
          rootState.constants.set(m[1], parseInt(v, 10));
        } else {
          rootState.constants.set(m[1], null);
        }
      }
    }
  }

  for (const top of (ast.body as AstNode[]) ?? []) {
    if (top.kind === "FunctionDeclaration" && top.body) {
      const funcState: FlowState = {
        constants: new Map(rootState.constants),
        initialized: new Map(rootState.initialized),
        arrays: new Map(rootState.arrays),
        nullPointers: new Set(rootState.nullPointers),
      };
      for (const param of (top.params as AstNode[]) ?? []) {
        if (param.name) funcState.initialized.set(param.name as string, true);
      }
      const body = top.body as AstNode;
      for (const stmt of (body.body as AstNode[]) ?? []) {
        visitStatement(stmt, funcState);
      }
    } else if (top.kind === "VariableDeclaration") {
      visitStatement(top, rootState);
    }
  }

  return { data: findings, findings, couldNotRun };
}