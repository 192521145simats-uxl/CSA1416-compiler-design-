/**
 * Recursive-descent parser for the supported C subset.
 *
 * Produces a real AST annotated with source locations and continues parsing
 * after errors (error recovery), so a single broken statement does not stop
 * the rest of the file from being analyzed. Syntax problems are reported as
 * findings with rule ids and line/column info.
 */
import type { AstNode, Finding, ModuleOutput, SourceLocation, Token, TokenType } from "./types";

const TYPE_KEYWORDS = new Set(["int", "char", "float", "double", "void"]);
const STATEMENT_KEYWORDS = new Set([
  "if",
  "else",
  "while",
  "for",
  "return",
  "switch",
  "case",
  "default",
  "break",
  "continue",
]);

const MAX_SYNTAX_ERRORS = 30;

const ASSIGN_OPS = new Set(["=", "+=", "-=", "*=", "/=", "%="]);

export interface ParserOutput {
  ast: AstNode | null;
  findings: Finding[];
}

const opPrecedence: Record<string, number> = {
  "||": 1,
  "&&": 2,
  "==": 3,
  "!=": 3,
  "<": 4,
  ">": 4,
  "<=": 4,
  ">=": 4,
  "+": 5,
  "-": 5,
  "*": 6,
  "/": 6,
  "%": 6,
};

class Cursor {
  tokens: Token[];
  pos = 0;

  constructor(tokens: Token[]) {
    this.tokens = tokens;
  }

  /** Skip comments (kept in the stream for display but irrelevant to parsing). */
  private skipComments(): void {
    while (this.tokens[this.pos]?.type === "COMMENT") this.pos += 1;
  }

  current(): Token {
    this.skipComments();
    return this.tokens[this.pos] ?? this.tokens[this.tokens.length - 1];
  }

  peek(offset = 0): Token {
    let p = this.pos;
    let skipped = 0;
    while (p < this.tokens.length && skipped <= offset) {
      if (this.tokens[p].type === "COMMENT") {
        p += 1;
        continue;
      }
      if (skipped === offset) return this.tokens[p];
      skipped += 1;
      p += 1;
    }
    return this.tokens[this.tokens.length - 1];
  }

  at(value: string): boolean {
    return this.current().value === value;
  }

  atType(type: TokenType): boolean {
    return this.current().type === type;
  }

  atValueIn(values: Set<string>): boolean {
    return values.has(this.current().value);
  }

  /** Consume the current token if it matches `value`; returns true on match. */
  match(value: string): boolean {
    if (this.at(value)) {
      this.pos += 1;
      return true;
    }
    return false;
  }

  /** Consume the current token of `type` if it matches; returns true on match. */
  matchType(type: TokenType): boolean {
    if (this.atType(type)) {
      this.pos += 1;
      return true;
    }
    return false;
  }

  advance(): Token {
    const t = this.current();
    this.pos += 1;
    return t;
  }
}

export function parseTokens(tokens: Token[]): ParserOutput {
  const cursor = new Cursor(tokens);
  const findings: Finding[] = [];

  // Names usable as types: typedef aliases (resolved to their underlying type)
  // and struct tags. Tags live in their own namespace, so only typedef aliases
  // are plain identifiers the parser treats as type names.
  const typeNames = new Set<string>();
  const typedefResolutions = new Map<string, string>();
  const structTags = new Set<string>();
  let anonStructCounter = 0;

  let idCounter = 0;
  const nextId = (rule: string) => {
    idCounter += 1;
    return `SYN-${idCounter}`;
  };

  const error = (
    rule: string,
    message: string,
    description: string,
    severity: "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
    token: Token | null,
    recommendation: string,
  ) => {
    if (findings.length >= MAX_SYNTAX_ERRORS) return;
    const t = token ?? cursor.current();
    findings.push({
      id: nextId(rule),
      category: "SYNTAX",
      rule,
      message,
      description,
      line: t.line,
      column: t.column,
      severity,
      cwe: "",
      recommendation,
      source: "Parser",
    });
  };

  const lastSignificantToken = (): Token => {
    let p = cursor.pos - 1;
    while (p >= 0 && (tokens[p].type === "COMMENT" || tokens[p].type === "EOF")) p -= 1;
    return p >= 0 ? tokens[p] : cursor.current();
  };

  const locOf = (t: Token): SourceLocation => ({
    line: t.line,
    column: t.column,
    start: t.start,
    end: t.end,
  });

  const node = (kind: string, t: Token, extra: Record<string, unknown> = {}): AstNode => ({
    kind,
    loc: locOf(t),
    ...extra,
  });

  /** A token that can begin a declaration: a type keyword, qualifier, struct/typedef, or typedef name. */
  const isTypeStart = (tok: Token): boolean =>
    (tok.type === "KEYWORD" && (TYPE_KEYWORDS.has(tok.value) || tok.value === "const")) ||
    tok.value === "struct" ||
    tok.value === "typedef" ||
    (tok.type === "IDENTIFIER" && typeNames.has(tok.value));

  /** Recovery: skip tokens until a statement boundary. Consumes a trailing ';' if found. */
  const synchronize = (): void => {
    while (!cursor.atType("EOF")) {
      const v = cursor.current().value;
      if (v === ";") {
        cursor.advance();
        return;
      }
      if (v === "}") return;
      if (cursor.atType("KEYWORD") && (STATEMENT_KEYWORDS.has(v) || TYPE_KEYWORDS.has(v))) return;
      if (v === "struct" || v === "typedef") return;
      if (cursor.atType("IDENTIFIER") && typeNames.has(v)) return;
      cursor.advance();
    }
  };

  const expectValue = (value: string, what: string, severity: "MEDIUM" | "HIGH" = "MEDIUM"): boolean => {
    if (cursor.match(value)) return true;
    error(
      "missing-token",
      `Expected '${value}' but found '${cursor.current().value || "end of file"}'`,
      `Expected ${what}. Found '${cursor.current().value || "end of file"}' on line ${cursor.current().line}.`,
      severity,
      null,
      `Insert the missing '${value}' at the reported location.`,
    );
    return false;
  };

  const missingSemicolon = () => {
    const t = lastSignificantToken();
    error(
      "missing-semicolon",
      "Missing semicolon",
      `A statement ending on line ${t.line} is missing its terminating semicolon.`,
      "MEDIUM",
      t,
      "Add ';' at the end of the statement on line " + t.line + ".",
    );
  };

  // --- Types & declarators -------------------------------------------------

  interface ParsedType {
    /** Canonical type string, e.g. "int", "char*", "struct Point", "struct anon_1". */
    type: string;
    /** When the specifier also defined a struct body, the StructDeclaration node to emit. */
    inlineStruct: AstNode | null;
    token: Token;
  }

  const parseTypeSpecifier = (): ParsedType | null => {
    const t = cursor.current();

    // `const` is a type qualifier — accept and ignore it.
    if (t.type === "KEYWORD" && t.value === "const") {
      cursor.advance();
      const inner = parseTypeSpecifier();
      return inner ?? { type: "", inlineStruct: null, token: t };
    }

    if (t.type === "KEYWORD" && TYPE_KEYWORDS.has(t.value)) {
      cursor.advance();
      return { type: t.value, inlineStruct: null, token: t };
    }

    if (t.type === "KEYWORD" && t.value === "struct") {
      cursor.advance();
      let tag = "";
      let tagTok: Token | null = null;
      if (cursor.atType("IDENTIFIER")) {
        tagTok = cursor.advance();
        tag = tagTok.value;
        structTags.add(tag);
      } else if (!cursor.at("{")) {
        error(
          "expected-struct-tag",
          "Expected a struct tag",
          `Expected a struct name or '{' after 'struct' but found '${cursor.current().value || "end of file"}' on line ${cursor.current().line}.`,
          "HIGH",
          null,
          "Name the struct, e.g. struct Point, or define it inline with '{ ... }'.",
        );
      }
      const members: AstNode[] = [];
      let isDefinition = false;
      if (cursor.at("{")) {
        isDefinition = true;
        cursor.advance();
        while (!cursor.at("}") && !cursor.atType("EOF")) {
          const mt = cursor.current();
          const memberType = parseTypeSpecifier();
          if (!memberType || memberType.type === "") {
            error(
              "invalid-struct-member",
              "Invalid struct member declaration",
              `Expected a type for the struct member but found '${mt.value || "end of file"}' on line ${mt.line}.`,
              "HIGH",
              null,
              "Declare each struct member with a valid type, e.g. int x;",
            );
            synchronize();
            break;
          }
          while (true) {
            const decl = parseDeclarator(memberType.type);
            if (!decl) break;
            members.push(
              node("StructMember", decl.token, {
                name: decl.name,
                type: decl.type,
                arraySize: decl.arraySize,
                pointerDepth: decl.pointerDepth,
              }),
            );
            if (!cursor.match(",")) break;
          }
          if (!cursor.match(";")) {
            missingSemicolon();
            break;
          }
        }
        if (cursor.atType("EOF")) {
          error(
            "missing-brace",
            "Missing '}' for struct definition",
            `The struct definition opened on line ${t.line} is never closed.`,
            "HIGH",
            t,
            "Add '}' to close the struct body.",
          );
        } else {
          cursor.advance(); // consume '}'
        }
      }
      if (!tagTok) {
        // Anonymous struct: generate a stable internal tag so member access
        // and typedef aliases can resolve against the field registry.
        anonStructCounter += 1;
        tag = `anon_${anonStructCounter}`;
      }
      return {
        type: `struct ${tag}`,
        inlineStruct: node("StructDeclaration", t, {
          tag,
          isDefinition,
          members,
        }),
        token: t,
      };
    }

    if (t.type === "IDENTIFIER" && typeNames.has(t.value)) {
      cursor.advance();
      return {
        type: typedefResolutions.get(t.value) ?? t.value,
        inlineStruct: null,
        token: t,
      };
    }

    error(
      "expected-type",
      "Expected a type specifier",
      `Expected a type specifier (int, char, float, double, void, a struct type or a typedef name) but found '${t.value || "end of file"}' on line ${t.line}.`,
      "HIGH",
      null,
      "Add a valid type specifier such as 'int'.",
    );
    return null;
  };

  interface Declarator {
    name: string;
    type: string;
    arraySize: number | null;
    pointerDepth: number;
    token: Token;
  }

  const parseDeclarator = (baseType: string): Declarator | null => {
    let pointerDepth = 0;
    while (cursor.at("*")) {
      cursor.advance();
      pointerDepth += 1;
    }
    const nameTok = cursor.current();
    if (nameTok.type !== "IDENTIFIER") {
      error(
        "expected-identifier",
        "Expected an identifier",
        `Expected a variable or function name but found '${nameTok.value || "end of file"}' on line ${nameTok.line}.`,
        "HIGH",
        null,
        "Provide a valid C identifier.",
      );
      synchronize();
      return null;
    }
    cursor.advance();

    let arraySize: number | null = null;
    if (cursor.at("[")) {
      cursor.advance();
      const sizeTok = cursor.current();
      if (sizeTok.type === "INTEGER") {
        arraySize = parseInt(sizeTok.value, 10);
        cursor.advance();
      } else if (cursor.at("]")) {
        error(
          "missing-array-size",
          "Array declaration is missing its size",
          `Array '${nameTok.value}' must declare a constant integer size, e.g. ${baseType} ${nameTok.value}[10];`,
          "MEDIUM",
          sizeTok,
          "Provide a constant array size in brackets.",
        );
      } else {
        error(
          "invalid-array-size",
          "Array size must be a constant integer",
          `Array '${nameTok.value}' on line ${sizeTok.line} has a non-constant size.`,
          "MEDIUM",
          sizeTok,
          "Use a constant integer literal for the array size.",
        );
        synchronize();
      }
      if (cursor.at("]")) cursor.advance();
      else {
        error(
          "missing-bracket",
          "Missing ']' in array declaration",
          `Expected ']' to close the array size for '${nameTok.value}'.`,
          "MEDIUM",
          null,
          "Add the closing ']'.",
        );
      }
    }

    const star = pointerDepth > 0 ? "*".repeat(pointerDepth) : "";
    const arrayPart = arraySize !== null ? `[${arraySize}]` : "";
    return {
      name: nameTok.value,
      type: `${baseType}${star}${arrayPart}`,
      arraySize,
      pointerDepth,
      token: nameTok,
    };
  };

  const parseBraceList = (openTok: Token): AstNode => {
    const elements: AstNode[] = [];
    while (!cursor.at("}") && !cursor.atType("EOF")) {
      if (cursor.at("{")) {
        const innerTok = cursor.advance();
        elements.push(parseBraceList(innerTok));
      } else {
        const el = parseAssignment();
        if (el) elements.push(el);
      }
      if (!cursor.match(",")) break;
    }
    if (cursor.atType("EOF")) {
      error(
        "missing-brace",
        "Missing '}' in initializer list",
        `The initializer list opened on line ${openTok.line} is never closed.`,
        "HIGH",
        openTok,
        "Add '}' to close the initializer list.",
      );
    } else {
      cursor.advance();
    }
    return node("InitializerList", openTok, { elements });
  };

  /** Parse the value after an already-consumed '=' (handles brace lists). */
  const parseInitializerAfterEq = (): AstNode | null => {
    if (cursor.at("{")) {
      const openTok = cursor.advance();
      return parseBraceList(openTok);
    }
    return parseAssignment();
  };

  const parseInitializer = (): AstNode | null => {
    if (cursor.match("=")) return parseInitializerAfterEq();
    return null;
  };

  /** Parses `type decl, decl, ...;` — used at top level and inside blocks. */
  const parseDeclarationFromType = (
    parsed: ParsedType,
    consumeSemicolon: boolean,
    context: "global" | "block" | "for",
  ): AstNode | null => {
    const declarations: AstNode[] = [];
    while (true) {
      const decl = parseDeclarator(parsed.type);
      if (!decl) {
        // We may be at ';' — recover
        if (cursor.at(";")) cursor.advance();
        break;
      }
      const init = parseInitializer();
      declarations.push(
        node("VariableDeclarator", decl.token, {
          id: node("Identifier", decl.token, { name: decl.name }),
          name: decl.name,
          type: decl.type,
          arraySize: decl.arraySize,
          pointerDepth: decl.pointerDepth,
          init,
        }),
      );
      if (cursor.at(",")) {
        cursor.advance();
        continue;
      }
      break;
    }
    const semi = consumeSemicolon && cursor.match(";");
    if (!semi && consumeSemicolon) missingSemicolon();
    return node("VariableDeclaration", parsed.token, {
      context,
      baseType: parsed.type,
      declarations,
    });
  };

  /** Handles `struct ...;`, `typedef ...;` and ordinary declarations in blocks. */
  const parseDeclarationStatement = (body: AstNode[], context: "global" | "block" | "for"): void => {
    if (cursor.at("typedef")) {
      parseTypedef(body);
      return;
    }
    const parsed = parseTypeSpecifier();
    if (!parsed) {
      synchronize();
      return;
    }
    if (cursor.at(";")) {
      // Standalone `struct Tag;` (forward declaration) or `struct { ... };`.
      cursor.advance();
      if (parsed.inlineStruct) body.push(parsed.inlineStruct);
      return;
    }
    if (context !== "for" && parsed.inlineStruct && parsed.inlineStruct.isDefinition === true) {
      body.push(parsed.inlineStruct);
    }
    const decl = parseDeclarationFromType(parsed, true, context);
    if (decl) body.push(decl);
  };

  /** Parses `typedef <type> name [, name2 ...];` and records the aliases. */
  const parseTypedef = (body: AstNode[]): void => {
    cursor.advance(); // 'typedef'
    const parsed = parseTypeSpecifier();
    if (!parsed) {
      synchronize();
      return;
    }
    if (parsed.inlineStruct) body.push(parsed.inlineStruct);
    while (true) {
      const decl = parseDeclarator(parsed.type);
      if (!decl) break;
      typedefResolutions.set(decl.name, decl.type);
      typeNames.add(decl.name);
      body.push(
        node("TypedefDeclaration", decl.token, {
          name: decl.name,
          type: decl.type,
        }),
      );
      if (!cursor.match(",")) break;
    }
    if (!cursor.match(";")) missingSemicolon();
  };

  // --- Expressions ----------------------------------------------------------

  const parseExpression = (): AstNode | null => parseAssignment();

  const parseAssignment = (): AstNode | null => {
    const left = parseBinary(1);
    if (left && cursor.atValueIn(ASSIGN_OPS)) {
      const opTok = cursor.advance();
      const right = parseAssignment();
      return node("AssignmentExpression", opTok, { operator: opTok.value, left, right });
    }
    return left;
  };

  const parseBinary = (minPrec: number): AstNode | null => {
    let left = parseUnary();
    if (!left) return null;
    while (true) {
      const opTok = cursor.current();
      const prec = opPrecedence[opTok.value];
      if (prec === undefined || prec < minPrec) break;
      cursor.advance();
      const right = parseBinary(prec + 1);
      if (!right) break;
      left = node("BinaryExpression", opTok, {
        operator: opTok.value,
        left,
        right,
      });
    }
    return left;
  };

  const parseUnary = (): AstNode | null => {
    const t = cursor.current();
    if (t.type === "OPERATOR" && ["!", "-", "+", "++", "--", "*", "&", "~"].includes(t.value)) {
      cursor.advance();
      const operand = parseUnary();
      if (!operand) return null;
      return node("UnaryExpression", t, { operator: t.value, operand, prefix: true });
    }
    if (t.type === "KEYWORD" && t.value === "sizeof") {
      cursor.advance();
      if (cursor.match("(")) {
        const operand = parseExpression();
        if (cursor.at(")")) cursor.advance();
        return node("UnaryExpression", t, { operator: "sizeof", operand, prefix: true });
      }
      const operand = parseUnary();
      return node("UnaryExpression", t, { operator: "sizeof", operand, prefix: true });
    }
    return parsePostfix();
  };

  const parsePostfix = (): AstNode | null => {
    let left = parsePrimary();
    if (!left) return null;
    while (true) {
      if (cursor.at("[")) {
        const br = cursor.advance();
        const index = parseExpression();
        let closed = cursor.match("]");
        if (!closed) {
          error(
            "missing-bracket",
            "Missing ']' in array access",
            `Expected ']' to close the array index on line ${br.line}.`,
            "MEDIUM",
            null,
            "Add the closing ']'.",
          );
        }
        left = node("ArrayAccess", br, { object: left, index });
        continue;
      }
      if (cursor.at(".") || cursor.at("->")) {
        const opTok = cursor.advance();
        const propTok = cursor.current();
        cursor.advance();
        if (propTok.type !== "IDENTIFIER") {
          error(
            "expected-identifier",
            "Expected a member name after '.' or '->'",
            `Expected a struct member name but found '${propTok.value || "end of file"}' on line ${propTok.line}.`,
            "MEDIUM",
            propTok,
            "Provide the member name, e.g. point.x.",
          );
        }
        left = node("MemberAccess", opTok, {
          object: left,
          property: propTok.value,
          pointer: opTok.value === "->",
        });
        continue;
      }
      if (cursor.at("++") || cursor.at("--")) {
        const opTok = cursor.advance();
        left = node("UnaryExpression", opTok, {
          operator: opTok.value,
          operand: left,
          prefix: false,
        });
        continue;
      }
      break;
    }
    return left;
  };

  const parsePrimary = (): AstNode | null => {
    const t = cursor.current();

    if (t.type === "INTEGER" || t.type === "FLOAT") {
      cursor.advance();
      return node("Literal", t, {
        value: t.value,
        valueType: t.type === "INTEGER" ? "int" : "float",
      });
    }
    if (t.type === "STRING") {
      cursor.advance();
      return node("Literal", t, { value: t.value, valueType: "string" });
    }
    if (t.type === "CHAR") {
      cursor.advance();
      return node("Literal", t, { value: t.value, valueType: "char" });
    }
    if (t.type === "IDENTIFIER") {
      cursor.advance();
      const ident = node("Identifier", t, { name: t.value });
      if (cursor.at("(")) {
        cursor.advance();
        const args: AstNode[] = [];
        while (!cursor.at(")") && !cursor.atType("EOF")) {
          const arg = parseExpression();
          if (arg) args.push(arg);
          if (!cursor.match(",")) break;
        }
        if (!cursor.at(")")) {
          error(
            "missing-paren",
            "Missing ')' in function call",
            `Function call to '${t.value}' on line ${t.line} is missing its closing parenthesis.`,
            "MEDIUM",
            null,
            "Add the closing ')' after the arguments.",
          );
        } else {
          cursor.advance();
        }
        return node("CallExpression", t, { callee: ident, name: t.value, arguments: args });
      }
      return ident;
    }
    if (t.value === "(") {
      cursor.advance();
      const inner = parseExpression();
      if (!cursor.at(")")) {
        error(
          "missing-paren",
          "Missing ')' in expression",
          `Parenthesized expression on line ${t.line} is missing its closing parenthesis.`,
          "MEDIUM",
          null,
          "Add the closing ')'.",
        );
      } else {
        cursor.advance();
      }
      return inner;
    }

    // Unexpected token inside an expression.
    error(
      "unexpected-token",
      `Unexpected token '${t.value || "end of file"}' in expression`,
      `Expected an identifier, literal or '(' but found '${t.value || "end of file"}' on line ${t.line}.`,
      "HIGH",
      t,
      "Check the expression for typos or missing operands.",
    );
    synchronize();
    return null;
  };

  // --- Statements -----------------------------------------------------------

  const parseBlock = (): AstNode | null => {
    const openTok = cursor.current();
    if (!cursor.match("{")) {
      error(
        "missing-brace",
        "Missing '{'",
        `Expected a block to start with '{' but found '${cursor.current().value || "end of file"}' on line ${cursor.current().line}.`,
        "HIGH",
        null,
        "Add '{' to start the block.",
      );
      return null;
    }
    const body: AstNode[] = [];
    while (!cursor.at("}") && !cursor.atType("EOF")) {
      const before = cursor.pos;
      parseStatement(body);
      if (cursor.pos === before) {
        // No progress — skip a token to guarantee termination.
        error(
          "unexpected-token",
          `Unexpected token '${cursor.current().value || "end of file"}'`,
          `The token '${cursor.current().value || "end of file"}' on line ${cursor.current().line} cannot start a statement.`,
          "MEDIUM",
          null,
          "Remove the token or restructure the statement.",
        );
        cursor.advance();
        synchronize();
      }
    }
    if (cursor.atType("EOF")) {
      error(
        "missing-brace",
        "Missing '}'",
        `Block opened on line ${openTok.line} is never closed.`,
        "HIGH",
        openTok,
        "Add '}' to close the block.",
      );
      return node("BlockStatement", openTok, { body });
    }
    cursor.advance(); // consume '}'
    return node("BlockStatement", openTok, { body });
  };

  const parseStatement = (body: AstNode[]): void => {
    const t = cursor.current();

    if (t.value === ";") {
      cursor.advance();
      body.push(node("EmptyStatement", t));
      return;
    }

    if (t.value === "{") {
      const block = parseBlock();
      if (block) body.push(block);
      return;
    }

    if (isTypeStart(t)) {
      parseDeclarationStatement(body, "block");
      return;
    }

    if (t.type === "KEYWORD") {
      switch (t.value) {
        case "if": {
          cursor.advance();
          if (!cursor.match("(")) {
            error(
              "missing-paren",
              "Missing '(' after 'if'",
              `Expected '(' after 'if' on line ${t.line}.`,
              "MEDIUM",
              null,
              "Add '(' after 'if'.",
            );
          }
          const test = parseExpression();
          if (!cursor.match(")")) {
            error(
              "missing-paren",
              "Missing ')' after 'if' condition",
              `The condition of the 'if' on line ${t.line} is missing its closing parenthesis.`,
              "MEDIUM",
              null,
              "Add ')' after the condition.",
            );
          }
          const consequent = parseStatementOrBlock();
          let alternate: AstNode | null = null;
          if (cursor.at("else")) {
            cursor.advance();
            alternate = parseStatementOrBlock();
          }
          body.push(
            node("IfStatement", t, {
              test: test ?? node("Literal", t, { value: "0", valueType: "int" }),
              consequent,
              alternate,
            }),
          );
          return;
        }
        case "while": {
          cursor.advance();
          if (!cursor.match("(")) {
            error(
              "missing-paren",
              "Missing '(' after 'while'",
              `Expected '(' after 'while' on line ${t.line}.`,
              "MEDIUM",
              null,
              "Add '(' after 'while'.",
            );
          }
          const test = parseExpression();
          if (!cursor.match(")")) {
            error(
              "missing-paren",
              "Missing ')' after 'while' condition",
              `The condition of the 'while' on line ${t.line} is missing its closing parenthesis.`,
              "MEDIUM",
              null,
              "Add ')' after the condition.",
            );
          }
          const bodyNode = parseStatementOrBlock();
          body.push(
            node("WhileStatement", t, {
              test: test ?? node("Literal", t, { value: "0", valueType: "int" }),
              body: bodyNode,
            }),
          );
          return;
        }
        case "for": {
          cursor.advance();
          if (!cursor.match("(")) {
            error(
              "missing-paren",
              "Missing '(' after 'for'",
              `Expected '(' after 'for' on line ${t.line}.`,
              "MEDIUM",
              null,
              "Add '(' after 'for'.",
            );
          }
          let init: AstNode | null = null;
          if (isTypeStart(cursor.current())) {
            const parsed = parseTypeSpecifier();
            if (parsed) {
              if (parsed.inlineStruct && parsed.inlineStruct.isDefinition === true) {
                error(
                  "invalid-declaration",
                  "Struct definition not allowed in a for-loop initializer",
                  `A struct type cannot be defined inside a for-loop initializer (line ${parsed.token.line}).`,
                  "HIGH",
                  parsed.token,
                  "Move the struct definition outside the for-loop.",
                );
              }
              init = parseDeclarationFromType(parsed, false, "for");
            }
            if (cursor.at(";")) cursor.advance();
          } else if (!cursor.at(";")) {
            init = parseExpression();
            if (!cursor.at(";")) {
              error(
                "missing-semicolon",
                "Missing ';' in for-loop initializer",
                `The initializer of the for-loop on line ${t.line} is missing its semicolon.`,
                "MEDIUM",
                null,
                "Add ';' after the for-loop initializer.",
              );
            } else {
              cursor.advance();
            }
          } else {
            cursor.advance();
          }
          let cond: AstNode | null = null;
          if (!cursor.at(";")) cond = parseExpression();
          if (!cursor.match(";")) {
            error(
              "missing-semicolon",
              "Missing ';' in for-loop condition",
              `The condition of the for-loop on line ${t.line} is missing its semicolon.`,
              "MEDIUM",
              null,
              "Add ';' after the for-loop condition.",
            );
          }
          let update: AstNode | null = null;
          if (!cursor.at(")")) update = parseExpression();
          if (!cursor.match(")")) {
            error(
              "missing-paren",
              "Missing ')' after for-loop header",
              `The for-loop header on line ${t.line} is missing its closing parenthesis.`,
              "MEDIUM",
              null,
              "Add ')' after the for-loop update expression.",
            );
          }
          const bodyNode = parseStatementOrBlock();
          body.push(
            node("ForStatement", t, {
              init,
              cond,
              update,
              body: bodyNode,
            }),
          );
          return;
        }
        case "switch": {
          cursor.advance();
          if (!cursor.match("(")) {
            error(
              "missing-paren",
              "Missing '(' after 'switch'",
              `Expected '(' after 'switch' on line ${t.line}.`,
              "MEDIUM",
              null,
              "Add '(' after 'switch'.",
            );
          }
          const discriminant = parseExpression();
          if (!cursor.match(")")) {
            error(
              "missing-paren",
              "Missing ')' after 'switch' condition",
              `The switch expression on line ${t.line} is missing its closing parenthesis.`,
              "MEDIUM",
              null,
              "Add ')' after the switch expression.",
            );
          }
          if (!cursor.match("{")) {
            error(
              "missing-brace",
              "Missing '{' after 'switch'",
              `Expected '{' to start the switch body but found '${cursor.current().value || "end of file"}' on line ${cursor.current().line}.`,
              "HIGH",
              null,
              "Add '{' after the switch condition.",
            );
          }
          const cases: AstNode[] = [];
          let current: AstNode[] | null = null;
          while (!cursor.at("}") && !cursor.atType("EOF")) {
            const labelTok = cursor.current();
            if (labelTok.value === "case") {
              cursor.advance();
              const test = parseExpression();
              if (!cursor.match(":")) {
                error(
                  "expected-colon",
                  "Expected ':' after case label",
                  `A 'case' label must be followed by ':' (line ${labelTok.line}).`,
                  "MEDIUM",
                  null,
                  "Add ':' after the case value.",
                );
              }
              current = [];
              cases.push(node("SwitchCase", labelTok, { test, body: current }));
              continue;
            }
            if (labelTok.value === "default") {
              cursor.advance();
              if (cases.some((c) => c.test === null)) {
                error(
                  "duplicate-default",
                  "Duplicate 'default' label",
                  `A switch statement may only have one 'default' label (line ${labelTok.line}).`,
                  "MEDIUM",
                  labelTok,
                  "Remove the duplicate 'default' label.",
                );
              }
              if (!cursor.match(":")) {
                error(
                  "expected-colon",
                  "Expected ':' after default label",
                  `The 'default' label must be followed by ':' (line ${labelTok.line}).`,
                  "MEDIUM",
                  null,
                  "Add ':' after 'default'.",
                );
              }
              current = [];
              cases.push(node("SwitchCase", labelTok, { test: null, body: current }));
              continue;
            }
            if (!current) {
              error(
                "case-label-expected",
                "Statement outside of a case label",
                `Statements in a switch must follow a 'case' or 'default' label (line ${labelTok.line}).`,
                "MEDIUM",
                labelTok,
                "Wrap the statement in a 'case' label or move it out of the switch.",
              );
              current = [];
              cases.push(node("SwitchCase", labelTok, { test: null, body: current }));
            }
            const before = cursor.pos;
            parseStatement(current);
            if (cursor.pos === before) {
              error(
                "unexpected-token",
                `Unexpected token '${cursor.current().value || "end of file"}' in switch body`,
                `The token '${cursor.current().value || "end of file"}' on line ${cursor.current().line} cannot start a statement.`,
                "MEDIUM",
                null,
                "Remove the token or restructure the statement.",
              );
              cursor.advance();
              synchronize();
            }
          }
          if (cursor.atType("EOF")) {
            error(
              "missing-brace",
              "Missing '}' for switch block",
              `The switch block opened on line ${t.line} is never closed.`,
              "HIGH",
              t,
              "Add '}' to close the switch block.",
            );
          } else {
            cursor.advance(); // consume '}'
          }
          body.push(
            node("SwitchStatement", t, {
              discriminant,
              cases,
            }),
          );
          return;
        }
        case "break":
        case "continue": {
          cursor.advance();
          if (!cursor.match(";")) missingSemicolon();
          body.push(node(t.value === "break" ? "BreakStatement" : "ContinueStatement", t));
          return;
        }
        case "return": {
          cursor.advance();
          let argument: AstNode | null = null;
          if (!cursor.at(";")) argument = parseExpression();
          if (!cursor.match(";")) missingSemicolon();
          body.push(node("ReturnStatement", t, { argument }));
          return;
        }
        default: {
          error(
            "invalid-statement",
            `Invalid statement keyword '${t.value}'`,
            `'${t.value}' cannot start a statement here (line ${t.line}).`,
            "HIGH",
            t,
            "Check the statement for typos.",
          );
          cursor.advance();
          synchronize();
          return;
        }
      }
    }

    // Expression statement
    const expr = parseExpression();
    if (expr) {
      body.push(node("ExpressionStatement", t, { expression: expr }));
    }
    if (!cursor.match(";")) missingSemicolon();
  };

  const parseStatementOrBlock = (): AstNode | null => {
    if (cursor.at("{")) return parseBlock();
    const wrapper: AstNode[] = [];
    parseStatement(wrapper);
    return wrapper[0] ?? null;
  };

  // --- Functions -------------------------------------------------------------

  const parseParams = (): { params: AstNode[]; ok: boolean } => {
    const params: AstNode[] = [];
    cursor.match("(");
    while (!cursor.at(")") && !cursor.atType("EOF")) {
      const typeTok = cursor.current();
      if (!isTypeStart(typeTok)) {
        error(
          "invalid-parameter",
          "Invalid function parameter",
          `Expected a parameter type (int, char, float, double, void, a struct type or a typedef name) but found '${typeTok.value || "end of file"}' on line ${typeTok.line}.`,
          "HIGH",
          null,
          "Declare each parameter with a valid type.",
        );
        synchronize();
        break;
      }
      const parsed = parseTypeSpecifier();
      if (!parsed) {
        synchronize();
        break;
      }
      const baseType = parsed.type;
      let pointerDepth = 0;
      while (cursor.at("*")) {
        cursor.advance();
        pointerDepth += 1;
      }
      const nameTok = cursor.current();
      if (nameTok.type === "IDENTIFIER") {
        cursor.advance();
        let arraySize: number | null = null;
        if (cursor.at("[")) {
          cursor.advance();
          if (cursor.atType("INTEGER")) {
            arraySize = parseInt(cursor.advance().value, 10);
          }
          if (cursor.at("]")) cursor.advance();
        }
        const star = pointerDepth > 0 ? "*".repeat(pointerDepth) : "";
        const arr = arraySize !== null ? `[${arraySize}]` : "";
        params.push(
          node("Parameter", nameTok, {
            name: nameTok.value,
            type: `${baseType}${star}${arr}`,
          }),
        );
      } else if (baseType !== "void" || params.length > 0) {
        // Unnamed parameter (prototype style) — acceptable; keep a placeholder
        params.push(
          node("Parameter", typeTok, {
            name: "",
            type: `${baseType}${pointerDepth > 0 ? "*".repeat(pointerDepth) : ""}`,
          }),
        );
      } else {
        // `void` as the only parameter: no params.
        break;
      }
      if (!cursor.match(",")) break;
    }
    const ok = cursor.match(")");
    if (!ok) {
      error(
        "missing-paren",
        "Missing ')' in parameter list",
        `The parameter list is missing its closing parenthesis.`,
        "MEDIUM",
        null,
        "Add ')' after the parameters.",
      );
    }
    return { params, ok };
  };

  const parseFunctionOrDeclaration = (body: AstNode[]): void => {
    if (cursor.at("typedef")) {
      parseTypedef(body);
      return;
    }
    const parsed = parseTypeSpecifier();
    if (!parsed) {
      synchronize();
      return;
    }
    if (cursor.at(";")) {
      // Standalone `struct Tag;` (forward declaration) or `struct { ... };`.
      cursor.advance();
      if (parsed.inlineStruct) body.push(parsed.inlineStruct);
      return;
    }
    if (parsed.inlineStruct && parsed.inlineStruct.isDefinition === true) {
      body.push(parsed.inlineStruct);
    }
    const baseType = parsed.type;
    let pointerDepth = 0;
    while (cursor.at("*")) {
      cursor.advance();
      pointerDepth += 1;
    }
    const nameTok = cursor.current();
    if (nameTok.type !== "IDENTIFIER") {
      error(
        "expected-identifier",
        "Expected a function or variable name",
        `Expected an identifier after the type on line ${parsed.token.line}.`,
        "HIGH",
        null,
        "Provide a valid identifier.",
      );
      synchronize();
      return;
    }
    cursor.advance();

    if (cursor.at("(")) {
      // Function declaration (definition or prototype)
      const { params } = parseParams();
      let block: AstNode | null = null;
      if (cursor.at("{")) {
        block = parseBlock();
      } else if (cursor.match(";")) {
        // prototype — no body
      } else {
        error(
          "malformed-function",
          "Malformed function declaration",
          `Function '${nameTok.value}' on line ${nameTok.line} must be followed by a '{' body or a ';' prototype.`,
          "HIGH",
          nameTok,
          "Add a '{' ... '}' body or end the prototype with ';'.",
        );
        synchronize();
      }
      body.push(
        node("FunctionDeclaration", parsed.token, {
          name: nameTok.value,
          returnType: `${baseType}${pointerDepth > 0 ? "*".repeat(pointerDepth) : ""}`,
          params,
          body: block,
          isPrototype: block === null,
        }),
      );
      return;
    }

    // Global variable declaration
    if (cursor.match("[")) {
      // `int arr[10];` at top level
      if (cursor.atType("INTEGER")) cursor.advance();
      if (cursor.at("]")) cursor.advance();
      else {
        error(
          "missing-bracket",
          "Missing ']' in array declaration",
          `Expected ']' for the global array on line ${nameTok.line}.`,
          "MEDIUM",
          null,
          "Add the closing ']'.",
        );
      }
    }
    let init: AstNode | null = null;
    if (cursor.match("=")) init = parseInitializerAfterEq();
    if (!cursor.match(";")) missingSemicolon();
    const star = pointerDepth > 0 ? "*".repeat(pointerDepth) : "";
    body.push(
      node("VariableDeclaration", parsed.token, {
        context: "global",
        baseType,
        declarations: [
          node("VariableDeclarator", nameTok, {
            id: node("Identifier", nameTok, { name: nameTok.value }),
            name: nameTok.value,
            type: `${baseType}${star}`,
            arraySize: null,
            pointerDepth,
            init,
          }),
        ],
      }),
    );
  };

  // --- Program ---------------------------------------------------------------

  const programBody: AstNode[] = [];
  const programTok = tokens[0] ?? cursor.current();
  while (!cursor.atType("EOF")) {
    const t = cursor.current();
    if (t.type === "PREPROCESSOR") {
      cursor.advance();
      programBody.push(node("PreprocessorDirective", t, { value: t.value }));
      continue;
    }
    if (isTypeStart(t)) {
      parseFunctionOrDeclaration(programBody);
      continue;
    }
    error(
      "unexpected-token",
      `Unexpected token '${t.value}' at top level`,
      `Only preprocessor directives, function definitions and global declarations are allowed at top level (found '${t.value}' on line ${t.line}).`,
      "HIGH",
      t,
      "Move the code inside a function body or fix the declaration.",
    );
    cursor.advance();
    synchronize();
  }

  const ast: AstNode =
    programBody.length === 0 && findings.length > 0
      ? node("Program", programTok, { body: [] })
      : node("Program", programTok, { body: programBody });

  return { ast, findings };
}