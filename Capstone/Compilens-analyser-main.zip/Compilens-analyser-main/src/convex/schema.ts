import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { Infer, v } from "convex/values";

// --- Shared analysis value validators (mirror of the analyzer types) ---

export const severityValidator = v.union(
  v.literal("INFO"),
  v.literal("LOW"),
  v.literal("MEDIUM"),
  v.literal("HIGH"),
  v.literal("CRITICAL"),
);

export const categoryValidator = v.union(
  v.literal("LEXICAL"),
  v.literal("SYNTAX"),
  v.literal("SEMANTIC"),
  v.literal("SECURITY"),
  v.literal("RUNTIME"),
);

export const summaryValidator = v.object({
  total: v.number(),
  critical: v.number(),
  high: v.number(),
  medium: v.number(),
  low: v.number(),
  info: v.number(),
});

export const metadataValidator = v.object({
  lineCount: v.number(),
  tokenCount: v.number(),
  analysisTimeMs: v.number(),
  syntaxErrorCount: v.number(),
  semanticErrorCount: v.number(),
  securityCount: v.number(),
  runtimeCount: v.number(),
});

export const findingValidator = v.object({
  id: v.string(),
  category: categoryValidator,
  rule: v.string(),
  message: v.string(),
  description: v.string(),
  line: v.number(),
  column: v.number(),
  severity: severityValidator,
  cwe: v.string(),
  recommendation: v.string(),
  source: v.string(),
});

// default user roles. can add / remove based on the project as needed
export const ROLES = {
  ADMIN: "admin",
  USER: "user",
  MEMBER: "member",
} as const;

export const roleValidator = v.union(
  v.literal(ROLES.ADMIN),
  v.literal(ROLES.USER),
  v.literal(ROLES.MEMBER),
);
export type Role = Infer<typeof roleValidator>;

const schema = defineSchema(
  {
    // default auth tables using convex auth.
    ...authTables, // do not remove or modify

    // the users table is the default users table that is brought in by the authTables
    users: defineTable({
      name: v.optional(v.string()), // name of the user. do not remove
      image: v.optional(v.string()), // image of the user. do not remove
      email: v.optional(v.string()), // email of the user. do not remove
      emailVerificationTime: v.optional(v.number()), // email verification time. do not remove
      isAnonymous: v.optional(v.boolean()), // is the user anonymous. do not remove

      role: v.optional(roleValidator), // role of the user. do not remove
    }).index("email", ["email"]), // index for the email. do not remove or modify

    // Per-user code analysis runs. The full artifacts (tokens, AST, symbol
    // table) are stored as JSON strings so the row stays small enough to be
    // returned by queries, while findings get their own table.
    analyses: defineTable({
      userId: v.id("users"),
      filename: v.string(),
      language: v.string(),
      sourceCode: v.string(),
      summary: summaryValidator,
      metadata: metadataValidator,
      tokensJson: v.string(),
      astJson: v.string(),
      symbolTableJson: v.string(),
      notes: v.array(v.string()),
    })
      .index("by_user", ["userId"]),

    // Individual findings for each analysis. Ownership enforced server-side
    // on every query/mutation by filtering on userId.
    findings: defineTable({
      analysisId: v.id("analyses"),
      userId: v.id("users"),
      category: categoryValidator,
      rule: v.string(),
      message: v.string(),
      description: v.string(),
      line: v.number(),
      column: v.number(),
      severity: severityValidator,
      cwe: v.string(),
      recommendation: v.string(),
      source: v.string(),
    })
      .index("by_analysis", ["analysisId"])
      .index("by_user", ["userId"]),

    // Lightweight user profile mirror used for profile editing.
    profiles: defineTable({
      userId: v.id("users"),
      fullName: v.string(),
      email: v.string(),
      updatedAt: v.number(),
    })
      .index("by_user", ["userId"])
      .index("by_email", ["email"]),
  },
  {
    schemaValidation: false,
  },
);

export default schema;
