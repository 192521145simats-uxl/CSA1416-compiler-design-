/**
 * Convex API for the code analyzer: run analyses, list/get/delete history,
 * dashboard stats, and profile updates. Every query/mutation enforces that
 * the caller can only touch their own rows (user-scoped authorization).
 */
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { mutation, query } from "./_generated/server";
import { runAnalysisPipeline } from "./analyzer/orchestrator";
import {
  categoryValidator,
  findingValidator,
  metadataValidator,
  severityValidator,
  summaryValidator,
} from "./schema";

// Safety valve: the Convex function response limit is 256KB, so very large
// programs get their tokens/AST truncated before storage with a note.
const MAX_ARTIFACT_JSON_LENGTH = 200_000;

/**
 * Serialize + truncate a large artifact so a document stays under limits.
 * Truncated payloads are wrapped in an envelope that stays valid JSON, so
 * reading them back can never throw a parse error.
 */
function serializeArtifact(value: unknown, noteSink: string[]): string {
  const json = JSON.stringify(value);
  if (json.length <= MAX_ARTIFACT_JSON_LENGTH) return json;
  noteSink.push(
    "This program is large; tokens/AST artifacts were truncated for storage. Re-analyze a smaller program for full artifacts.",
  );
  return JSON.stringify({ __truncated: true, payload: json.slice(0, MAX_ARTIFACT_JSON_LENGTH) });
}

/** Reverse of serializeArtifact — never throws on stored data. */
function parseArtifact(json: string): unknown {
  try {
    const parsed = JSON.parse(json) as unknown;
    if (
      parsed &&
      typeof parsed === "object" &&
      "__truncated" in parsed &&
      (parsed as { __truncated?: boolean }).__truncated === true
    ) {
      return (parsed as { payload?: string }).payload ?? null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function describeSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

export const runAnalysis = mutation({
  args: {
    code: v.string(),
    language: v.string(),
    filename: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      throw new Error("You must be signed in to analyze code.");
    }

    const code = args.code;
    if (!code.trim()) {
      throw new Error("Source code cannot be empty.");
    }
    if (code.length > 60_000) {
      throw new Error(
        `Source code is too large (${describeSize(code.length)}). The limit is 60 KB per file.`,
      );
    }

    const result = runAnalysisPipeline({
      code,
      language: args.language || "c",
      filename: args.filename || "main.c",
    });

    // Persist before returning so the history list always includes this run.
    const notes = [...result.notes];
    const analysisId = await ctx.db.insert("analyses", {
      userId,
      filename: result.filename,
      language: result.language,
      sourceCode: code,
      summary: result.summary,
      metadata: result.metadata,
      tokensJson: serializeArtifact(result.tokens, notes),
      astJson: serializeArtifact(result.ast, notes),
      symbolTableJson: serializeArtifact(result.symbolTable, notes),
      notes,
    });

    for (const finding of result.findings) {
      await ctx.db.insert("findings", {
        analysisId,
        userId,
        category: finding.category,
        rule: finding.rule,
        message: finding.message,
        description: finding.description,
        line: finding.line,
        column: finding.column,
        severity: finding.severity,
        cwe: finding.cwe,
        recommendation: finding.recommendation,
        source: finding.source,
      });
    }

    return { analysisId, result };
  },
});

export const listAnalyses = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return [];

    const rows = await ctx.db
      .query("analyses")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(50);

    return rows.map((row) => ({
      id: row._id,
      filename: row.filename,
      language: row.language,
      createdAt: row._creationTime,
      summary: row.summary,
      metadata: row.metadata,
      lineCount: row.metadata.lineCount,
      hasNotes: row.notes.length > 0,
    }));
  },
});

export const getAnalysis = query({
  args: { id: v.id("analyses") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Not signed in.");

    const row = await ctx.db.get(args.id);
    if (!row || row.userId !== userId) {
      throw new Error("Analysis not found.");
    }

    const findingRows = await ctx.db
      .query("findings")
      .withIndex("by_analysis", (q) => q.eq("analysisId", args.id))
      .collect();

    return {
      id: row._id,
      filename: row.filename,
      language: row.language,
      sourceCode: row.sourceCode,
      createdAt: row._creationTime,
      summary: row.summary,
      metadata: row.metadata,
      notes: row.notes,
      tokens: parseArtifact(row.tokensJson),
      ast: parseArtifact(row.astJson),
      symbolTable: parseArtifact(row.symbolTableJson),
      findings: findingRows.map((f) => ({
        id: f._id,
        category: f.category,
        rule: f.rule,
        message: f.message,
        description: f.description,
        line: f.line,
        column: f.column,
        severity: f.severity,
        cwe: f.cwe,
        recommendation: f.recommendation,
        source: f.source,
      })),
    };
  },
});

export const deleteAnalysis = mutation({
  args: { id: v.id("analyses") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Not signed in.");

    const row = await ctx.db.get(args.id);
    if (!row || row.userId !== userId) {
      throw new Error("Analysis not found.");
    }

    const findingRows = await ctx.db
      .query("findings")
      .withIndex("by_analysis", (q) => q.eq("analysisId", args.id))
      .collect();
    for (const finding of findingRows) {
      await ctx.db.delete(finding._id);
    }
    await ctx.db.delete(args.id);
    return true;
  },
});

export const getDashboardStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      return {
        totalAnalyses: 0,
        totalFindings: 0,
        critical: 0,
        high: 0,
        medium: 0,
        low: 0,
        info: 0,
        recent: [],
      };
    }

    const rows = await ctx.db
      .query("analyses")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(50);

    const recent = rows.slice(0, 5).map((row) => ({
      id: row._id,
      filename: row.filename,
      createdAt: row._creationTime,
      summary: row.summary,
    }));

    const totals = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
    for (const row of rows) {
      totals.critical += row.summary.critical;
      totals.high += row.summary.high;
      totals.medium += row.summary.medium;
      totals.low += row.summary.low;
      totals.info += row.summary.info;
    }
    const totalFindings =
      totals.critical + totals.high + totals.medium + totals.low + totals.info;

    return {
      totalAnalyses: rows.length,
      totalFindings,
      ...totals,
      recent,
    };
  },
});

export const updateProfile = mutation({
  args: { fullName: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Not signed in.");

    const name = args.fullName.trim();
    if (!name) throw new Error("Full name cannot be empty.");
    if (name.length > 80) throw new Error("Full name is too long.");

    const user = await ctx.db.get(userId);
    if (!user) throw new Error("User not found.");

    await ctx.db.patch(userId, { name });

    const existing = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();
    const email = user.email ?? "";
    if (existing) {
      await ctx.db.patch(existing._id, {
        fullName: name,
        email,
        updatedAt: Date.now(),
      });
    } else {
      await ctx.db.insert("profiles", {
        userId,
        fullName: name,
        email,
        updatedAt: Date.now(),
      });
    }
    return true;
  },
});

export const getProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return null;

    const user = await ctx.db.get(userId);
    if (!user) return null;

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return {
      fullName: profile?.fullName ?? user.name ?? "",
      email: user.email ?? "",
      createdAt: user._creationTime,
    };
  },
});

// Re-export validators so the frontend can reuse them for typing.
export const analysisValidators = {
  categoryValidator,
  findingValidator,
  severityValidator,
  summaryValidator,
  metadataValidator,
};