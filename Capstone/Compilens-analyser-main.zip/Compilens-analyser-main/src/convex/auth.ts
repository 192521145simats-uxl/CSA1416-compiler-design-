// THIS FILE IS READ ONLY. Do not touch this file unless you are correctly adding a new auth provider in accordance to the vly auth documentation

import { convexAuth } from "@convex-dev/auth/server";
import { Anonymous } from "@convex-dev/auth/providers/Anonymous";
import { Password } from "@convex-dev/auth/providers/Password";
import { emailOtp } from "./auth/emailOtp";
import type { Value } from "convex/values";

// Email + password authentication with full name support (the primary flow
// for this app). Passwords are hashed with scrypt by the Password provider.
const password = Password({
  validatePasswordRequirements(password: string) {
    if (!password || password.length < 8) {
      throw new Error("Password must be at least 8 characters long.");
    }
  },
  // Persist the full name captured on the sign-up form onto the user row
  // (the provider's default profile only keeps the email).
  profile(params) {
    const email = typeof params.email === "string" ? params.email : "";
    const out: { email: string; [k: string]: Value } = { email };
    const name = params.name;
    if (typeof name === "string" && name.trim()) out.name = name.trim();
    return out;
  },
});

export const { auth, signIn, signOut, store, isAuthenticated } = convexAuth({
  providers: [password, emailOtp, Anonymous],
});