import { Fragment, useMemo, useState } from "react";
import { ChevronDown, ChevronRight, FileWarning } from "lucide-react";
import type {
  AnalysisResult,
  AstNode,
  Finding,
  Severity,
  SymbolEntry,
  Token,
} from "@/convex/analyzer/types";
import { cn } from "@/lib/utils";
import {
  CategoryBadge,
  GlassBadge,
  SeverityBadge,
} from "@/components/Glass";
import { Button } from "@/components/ui/button";
import {
  buildHtmlReport,
  buildJsonReport,
  buildTxtReport,
  downloadReport,
  type ReportFormat,
} from "@/lib/reports";

/* ------------------------------------------------------------------ */
/* Small table helpers                                                 */
/* ------------------------------------------------------------------ */

function EmptyNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-14 text-center">
      <FileWarning className="size-8 text-slate-300" />
      <p className="text-sm text-muted-foreground">{children}</p>
    </div>
  );
}

const thCls =
  "px-3 py-2 text-left text-[11px] font-bold uppercase tracking-wider text-slate-500";
const tdCls = "px-3 py-2 align-top text-[13px]";

/* ------------------------------------------------------------------ */
/* Overview                                                            */
/* ------------------------------------------------------------------ */

export function OverviewView({ result }: { result: AnalysisResult }) {
  const stats: { label: string; value: number; cls: string }[] = [
    { label: "Critical", value: result.summary.critical, cls: "text-rose-600" },
    { label: "High", value: result.summary.high, cls: "text-orange-600" },
    { label: "Medium", value: result.summary.medium, cls: "text-amber-600" },
    { label: "Low", value: result.summary.low, cls: "text-blue-600" },
    { label: "Info", value: result.summary.info, cls: "text-slate-500" },
  ];
  const status = (count: number) =>
    count === 0 ? (
      <GlassBadge tone="success">PASS</GlassBadge>
    ) : (
      <GlassBadge tone="danger">
        {count} issue{count === 1 ? "" : "s"}
      </GlassBadge>
    );

  return (
    <div className="space-y-5 p-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        {stats.map((s) => (
          <div
            key={s.label}
            className="glass-subtle rounded-xl px-3 py-3 text-center"
          >
            <p className={cn("text-2xl font-bold tabular", s.cls)}>{s.value}</p>
            <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              {s.label}
            </p>
          </div>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="glass-subtle rounded-xl p-4">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Module status
          </p>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex items-center justify-between gap-3">
              <dt className="text-slate-600">Lexical analysis</dt>
              <dd>{result.tokens.length > 0 ? status(0) : <GlassBadge tone="warning">skipped</GlassBadge>}</dd>
            </div>
            <div className="flex items-center justify-between gap-3">
              <dt className="text-slate-600">Syntax analysis</dt>
              <dd>{status(result.metadata.syntaxErrorCount)}</dd>
            </div>
            <div className="flex items-center justify-between gap-3">
              <dt className="text-slate-600">Semantic analysis</dt>
              <dd>{status(result.metadata.semanticErrorCount)}</dd>
            </div>
            <div className="flex items-center justify-between gap-3">
              <dt className="text-slate-600">Security scan</dt>
              <dd>{status(result.metadata.securityCount)}</dd>
            </div>
            <div className="flex items-center justify-between gap-3">
              <dt className="text-slate-600">Runtime risks</dt>
              <dd>{status(result.metadata.runtimeCount)}</dd>
            </div>
          </dl>
        </div>
        <div className="glass-subtle rounded-xl p-4">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Metadata
          </p>
          <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {[
              ["Source lines", String(result.metadata.lineCount)],
              ["Tokens", String(result.metadata.tokenCount)],
              ["Analysis time", `${result.metadata.analysisTimeMs} ms`],
              ["AST nodes", String(countAstNodes(result.ast))],
            ].map(([k, v]) => (
              <div key={k} className="flex items-baseline justify-between gap-2 border-b border-slate-100 pb-1">
                <dt className="text-slate-500">{k}</dt>
                <dd className="font-semibold text-slate-700 tabular">{v}</dd>
              </div>
            ))}
          </dl>
          {result.notes.length > 0 && (
            <div className="mt-4">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Analyzer notes
              </p>
              <ul className="mt-2 space-y-1.5">
                {result.notes.map((n) => (
                  <li
                    key={n}
                    className="rounded-lg border border-amber-200/70 bg-amber-50/60 px-3 py-2 text-[12.5px] text-amber-800"
                  >
                    {n}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function countAstNodes(node: AstNode | null): number {
  if (!node) return 0;
  let count = 1;
  for (const key of Object.keys(node)) {
    if (key === "kind" || key === "loc") continue;
    const value = node[key];
    if (Array.isArray(value)) {
      for (const item of value) {
        if (item && typeof item === "object" && typeof (item as AstNode).kind === "string") {
          count += countAstNodes(item as AstNode);
        }
      }
    } else if (value && typeof value === "object" && typeof (value as AstNode).kind === "string") {
      count += countAstNodes(value as AstNode);
    }
  }
  return count;
}

/* ------------------------------------------------------------------ */
/* Findings                                                            */
/* ------------------------------------------------------------------ */

export function FindingsView({
  findings,
  onJump,
}: {
  findings: Finding[];
  onJump?: (line: number) => void;
}) {
  const [open, setOpen] = useState<string | null>(null);
  if (findings.length === 0) {
    return (
      <EmptyNote>
        No findings — the analyzer found the source clean across all modules.
      </EmptyNote>
    );
  }
  return (
    <div className="scrollbar-thin overflow-auto">
      <table className="w-full min-w-[760px] border-collapse">
        <thead className="bg-white/60 sticky top-0 z-10 backdrop-blur">
          <tr className="border-b border-slate-200/80 text-left">
            <th className={thCls}>Severity</th>
            <th className={thCls}>Category</th>
            <th className={thCls}>Line</th>
            <th className={thCls}>Rule</th>
            <th className={thCls}>Message</th>
            <th className={thCls}>CWE</th>
            <th className={thCls} />
          </tr>
        </thead>
        <tbody>
          {findings.map((f) => (
            <Fragment key={f.id}>
              <tr
                onClick={() => setOpen(open === f.id ? null : f.id)}
                className="cursor-pointer border-b border-slate-100 transition-colors hover:bg-blue-50/40"
              >
                <td className={tdCls}>
                  <SeverityBadge severity={f.severity as Severity} />
                </td>
                <td className={tdCls}>
                  <CategoryBadge category={f.category} />
                </td>
                <td className={cn(tdCls, "font-mono tabular")}>
                  {f.line > 0 ? (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onJump?.(f.line);
                      }}
                      className="cursor-pointer rounded-md px-1.5 py-0.5 font-mono text-blue-600 underline-offset-2 hover:bg-blue-100/70 hover:underline"
                    >
                      :{f.line}
                    </button>
                  ) : (
                    "—"
                  )}
                </td>
                <td className={cn(tdCls, "font-mono text-[12.5px]")}>{f.rule}</td>
                <td className={tdCls}>{f.message}</td>
                <td className={cn(tdCls, "font-mono text-[12px] text-slate-500")}>
                  {f.cwe || "—"}
                </td>
                <td className={tdCls}>
                  {open === f.id ? (
                    <ChevronDown className="size-4 text-slate-400" />
                  ) : (
                    <ChevronRight className="size-4 text-slate-400" />
                  )}
                </td>
              </tr>
              {open === f.id && (
                <tr className="bg-white/50">
                  <td colSpan={7} className="px-5 py-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          Description
                        </p>
                        <p className="mt-1 text-[13px] leading-relaxed text-slate-700">
                          {f.description || f.message}
                        </p>
                        <p className="mt-3 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          Source
                        </p>
                        <p className="mt-1 text-[13px] text-slate-600">
                          {f.source} · line {f.line || "—"}, column {f.column || "—"}
                        </p>
                      </div>
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          Recommendation
                        </p>
                        <p className="mt-1 rounded-lg border border-emerald-200/70 bg-emerald-50/60 px-3 py-2 text-[13px] leading-relaxed text-emerald-800">
                          {f.recommendation}
                        </p>
                        {f.line > 0 && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-3 cursor-pointer"
                            onClick={() => onJump?.(f.line)}
                          >
                            Jump to line {f.line}
                          </Button>
                        )}
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Tokens                                                              */
/* ------------------------------------------------------------------ */

export function TokensView({ tokens }: { tokens: Token[] }) {
  const list = tokens.filter((t) => t.type !== "EOF");
  if (list.length === 0) return <EmptyNote>No tokens were produced.</EmptyNote>;
  return (
    <div className="scrollbar-thin overflow-auto">
      <table className="w-full min-w-[620px] border-collapse">
        <thead className="sticky top-0 z-10 bg-white/70 backdrop-blur">
          <tr className="border-b border-slate-200/80 text-left">
            <th className={thCls}>#</th>
            <th className={thCls}>Type</th>
            <th className={thCls}>Value</th>
            <th className={thCls}>Line</th>
            <th className={thCls}>Column</th>
          </tr>
        </thead>
        <tbody className="font-mono">
          {list.map((t, i) => (
            <tr key={i} className="border-b border-slate-100 hover:bg-blue-50/30">
              <td className={cn(tdCls, "text-slate-400")}>{i + 1}</td>
              <td className={cn(tdCls, "text-[12px] text-slate-500")}>{t.type}</td>
              <td className={cn(tdCls, "max-w-[420px] truncate text-slate-700")}>
                {t.value === "\n" ? "\\n" : t.value}
              </td>
              <td className={cn(tdCls, "tabular text-slate-500")}>{t.line}</td>
              <td className={cn(tdCls, "tabular text-slate-500")}>{t.column}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* AST                                                                 */
/* ------------------------------------------------------------------ */

interface AstRow {
  id: string;
  depth: number;
  label: string;
  kind: string;
  line: number;
  childIds: string[];
}

function flattenAst(node: AstNode): AstRow[] {
  const rows: AstRow[] = [];
  let counter = 0;
  const visit = (n: AstNode, depth: number): string => {
    const id = `n${counter}`;
    counter += 1;
    const meta: string[] = [];
    const childIds: string[] = [];
    for (const key of Object.keys(n)) {
      if (key === "kind" || key === "loc") continue;
      const value = n[key];
      if (Array.isArray(value)) {
        for (const item of value) {
          if (item && typeof item === "object" && typeof (item as AstNode).kind === "string") {
            childIds.push(visit(item as AstNode, depth + 1));
          }
        }
      } else if (
        value &&
        typeof value === "object" &&
        typeof (value as AstNode).kind === "string"
      ) {
        childIds.push(visit(value as AstNode, depth + 1));
      } else if (value !== undefined && value !== null && typeof value !== "boolean") {
        if (key === "valueType") continue;
        if (key === "operator" || key === "name") {
          meta.push(String(value));
        } else if (typeof value === "string" || typeof value === "number") {
          meta.push(`${key}=${JSON.stringify(value)}`);
        }
      }
    }
    rows.push({
      id,
      depth,
      label: meta.length ? meta.join(" ") : "",
      kind: n.kind,
      line: n.loc?.line ?? 0,
      childIds,
    });
    return id;
  };
  visit(node, 0);
  return rows;
}

export function AstView({ ast }: { ast: AstNode | null }) {
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const rows = useMemo(() => (ast ? flattenAst(ast) : []), [ast]);
  if (!ast || rows.length === 0) {
    return <EmptyNote>No syntax tree available — the parser could not build an AST.</EmptyNote>;
  }
  const visible = rows.filter(
    (r) => !r.childIds.length || !isCollapsedAncestor(r, collapsed),
  );
  function isCollapsedAncestor(row: AstRow, state: Set<string>): boolean {
    return row.childIds.length > 0 && state.has(row.id);
  }

  return (
    <div className="scrollbar-thin overflow-auto p-4">
      <div className="min-w-[560px] font-mono text-[12.5px]">
        {visible.map((row) => {
          const hasChildren = row.childIds.length > 0;
          const isOpen = !collapsed.has(row.id);
          return (
            <div
              key={row.id}
              className="flex items-center gap-2 rounded-md py-[3px] hover:bg-blue-50/40"
              style={{ paddingLeft: `${row.depth * 18 + 4}px` }}
            >
              {hasChildren ? (
                <button
                  type="button"
                  onClick={() =>
                    setCollapsed((prev) => {
                      const next = new Set(prev);
                      if (isOpen) next.add(row.id);
                      else next.delete(row.id);
                      return next;
                    })
                  }
                  className="flex size-4 cursor-pointer items-center justify-center rounded text-slate-400 hover:bg-white/80 hover:text-slate-600"
                  aria-label={isOpen ? "Collapse" : "Expand"}
                >
                  {isOpen ? (
                    <ChevronDown className="size-3.5" />
                  ) : (
                    <ChevronRight className="size-3.5" />
                  )}
                </button>
              ) : (
                <span className="size-4" />
              )}
              <span className="rounded-md bg-blue-100/80 px-1.5 py-0.5 text-[11px] font-bold text-blue-700">
                {row.kind}
              </span>
              {row.label && <span className="truncate text-slate-600">{row.label}</span>}
              {row.line > 0 && (
                <span className="ml-auto shrink-0 text-[11px] text-slate-400">
                  L{row.line}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Symbol table                                                        */
/* ------------------------------------------------------------------ */

export function SymbolsView({ symbols }: { symbols: SymbolEntry[] }) {
  if (symbols.length === 0) {
    return <EmptyNote>No symbols recorded — semantic analysis could not run.</EmptyNote>;
  }
  return (
    <div className="scrollbar-thin overflow-auto">
      <table className="w-full min-w-[700px] border-collapse">
        <thead className="sticky top-0 z-10 bg-white/70 backdrop-blur">
          <tr className="border-b border-slate-200/80 text-left">
            <th className={thCls}>Name</th>
            <th className={thCls}>Type</th>
            <th className={thCls}>Kind</th>
            <th className={thCls}>Scope</th>
            <th className={thCls}>Line</th>
            <th className={thCls}>Initialized</th>
          </tr>
        </thead>
        <tbody>
          {symbols.map((s, i) => (
            <tr key={i} className="border-b border-slate-100 hover:bg-blue-50/30">
              <td className={cn(tdCls, "font-mono font-semibold text-slate-800")}>{s.name}</td>
              <td className={cn(tdCls, "font-mono text-[12.5px] text-slate-600")}>{s.type}</td>
              <td className={tdCls}>
                <GlassBadge tone={s.kind === "Function" ? "brand" : s.kind === "Parameter" ? "info" : "neutral"}>
                  {s.kind}
                </GlassBadge>
              </td>
              <td className={cn(tdCls, "font-mono text-[12.5px] text-slate-500")}>{s.scope}</td>
              <td className={cn(tdCls, "font-mono tabular text-slate-500")}>{s.line > 0 ? s.line : "—"}</td>
              <td className={tdCls}>
                {s.initialized ? (
                  <GlassBadge tone="success">yes</GlassBadge>
                ) : (
                  <GlassBadge tone="warning">no</GlassBadge>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Category subsets (security / runtime)                               */
/* ------------------------------------------------------------------ */

export function CategoryFindingsView({
  findings,
  category,
  onJump,
  emptyMessage,
}: {
  findings: Finding[];
  category: "SECURITY" | "RUNTIME";
  onJump?: (line: number) => void;
  emptyMessage: string;
}) {
  const subset = findings.filter((f) => f.category === category);
  if (subset.length === 0) return <EmptyNote>{emptyMessage}</EmptyNote>;
  return <FindingsView findings={subset} onJump={onJump} />;
}

/* ------------------------------------------------------------------ */
/* Report                                                              */
/* ------------------------------------------------------------------ */

export function ReportView({
  projectName,
  result,
  sourceCode,
  createdAt,
}: {
  projectName: string;
  result: AnalysisResult;
  sourceCode: string;
  createdAt?: number;
}) {
  const [format, setFormat] = useState<ReportFormat>("html");
  const input = {
    projectName,
    filename: result.filename,
    language: result.language,
    sourceCode,
    createdAt,
    result,
  };
  const content =
    format === "json"
      ? buildJsonReport(input)
      : format === "html"
        ? buildHtmlReport(input)
        : buildTxtReport(input);
  const preview =
    format === "html" ? null : content.length > 20000 ? content.slice(0, 20000) + "\n…" : content;

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/70 px-4 py-2.5">
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
          Export report — {result.filename}
        </p>
        <div className="flex flex-wrap items-center gap-2">
          {(["html", "json", "txt"] as ReportFormat[]).map((fmt) => (
            <Button
              key={fmt}
              variant={format === fmt ? "default" : "outline"}
              size="sm"
              className={cn(
                "cursor-pointer rounded-lg uppercase",
                format === fmt && "bg-gradient-to-r from-sky-500 to-indigo-600 text-white",
              )}
              onClick={() => setFormat(fmt)}
            >
              {fmt}
            </Button>
          ))}
          <Button
            size="sm"
            className="cursor-pointer rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-500 hover:to-teal-500"
            onClick={() => downloadReport(content, format, result.filename)}
          >
            Download .{format}
          </Button>
        </div>
      </div>
      {format === "html" ? (
        <iframe
          title="HTML report preview"
          className="min-h-[420px] flex-1 border-0 bg-white"
          srcDoc={content}
          sandbox=""
        />
      ) : (
        <pre className="scrollbar-thin flex-1 overflow-auto whitespace-pre-wrap p-4 font-mono text-[12px] leading-relaxed text-slate-700">
          {preview}
        </pre>
      )}
    </div>
  );
}
