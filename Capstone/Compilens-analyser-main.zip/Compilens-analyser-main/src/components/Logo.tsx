import { ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "relative inline-flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500 via-blue-600 to-indigo-600 text-white shadow-[0_8px_20px_-8px_rgba(37,99,235,0.7)]",
        className,
      )}
    >
      <ShieldCheck className="size-5" strokeWidth={2.2} />
      <span className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/40" />
    </span>
  );
}

export function Logo({
  onClick,
  className,
  compact = false,
}: {
  onClick?: () => void;
  className?: string;
  compact?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "group flex cursor-pointer items-center gap-2.5 text-left",
        className,
      )}
      aria-label="Secure Code Analyzer home"
    >
      <LogoMark className="transition-transform duration-300 group-hover:-rotate-3 group-hover:scale-105" />
      {!compact && (
        <span className="leading-tight">
          <span className="block text-[15px] font-bold tracking-tight text-foreground">
            SECURE CODE
            <span className="text-primary"> ANALYZER</span>
          </span>
          <span className="block text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
            Compiler-based C analysis
          </span>
        </span>
      )}
    </button>
  );
}
