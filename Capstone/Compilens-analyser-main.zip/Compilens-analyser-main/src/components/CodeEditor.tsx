/**
 * CodeEditor — a lightweight IDE-grade editor for C source.
 *
 * Monaco is intentionally not pulled in (it is a very heavy dependency for
 * this environment). Instead the editor layers a real <textarea> over a
 * highlighted <pre> whose spans are produced by the SAME lexer used by the
 * backend analyzer (src/convex/analyzer/lexer.ts is dependency-free), so
 * editor colors always match the analyzer's token model.
 *
 * Layout: one shared scroll pane contains a wrapper that the <pre> sizes in
 * flow; the <textarea> is absolutely positioned over the same box. The two
 * layers always share metrics, so scrolling and caret placement stay in
 * sync without JS. A line-number gutter tracks vertical scroll.
 *
 * Features: C syntax highlighting, line numbers, per-line severity markers,
 * jump-to-line + flash, and Ctrl/Cmd+Enter to analyze.
 */
import {
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
  type Ref,
} from "react";
import { lexSource } from "@/convex/analyzer/lexer";
import type { Finding, Severity, TokenType } from "@/convex/analyzer/types";
import { cn } from "@/lib/utils";

const TOKEN_CLASS: Partial<Record<TokenType, string>> = {
  KEYWORD: "tok-kw",
  IDENTIFIER: "tok-id",
  INTEGER: "tok-num",
  FLOAT: "tok-num",
  STRING: "tok-str",
  CHAR: "tok-str",
  OPERATOR: "tok-op",
  PUNCTUATION: "tok-punc",
  PREPROCESSOR: "tok-pp",
  COMMENT: "tok-com",
  INVALID: "tok-invalid",
};

const SEVERITY_DOT: Record<Severity, string> = {
  CRITICAL: "bg-rose-500",
  HIGH: "bg-orange-500",
  MEDIUM: "bg-amber-500",
  LOW: "bg-blue-500",
  INFO: "bg-slate-400",
};

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

export interface EditorHandle {
  focusLine: (line: number) => void;
}

interface CodeEditorProps {
  value: string;
  onChange: (code: string) => void;
  onAnalyze: () => void;
  findings?: Finding[];
  readOnly?: boolean;
  className?: string;
  ref?: Ref<EditorHandle>;
}

const LINE_HEIGHT_REM = 1.5;

export function CodeEditor({
  value,
  onChange,
  onAnalyze,
  findings = [],
  readOnly = false,
  className,
  ref,
}: CodeEditorProps) {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const [flashLine, setFlashLine] = useState<number | null>(null);
  const [activeLine, setActiveLine] = useState(1);
  const flashTimer = useRef<number | null>(null);

  /** HTML highlighting produced by the real lexer. */
  const highlightedHtml = useMemo(() => {
    if (!value) return "";
    const { data } = lexSource(value);
    let html = "";
    let cursor = 0;
    for (const token of data) {
      if (token.start > cursor) html += escapeHtml(value.slice(cursor, token.start));
      const content = escapeHtml(value.slice(token.start, token.end));
      if (token.type === "EOF") {
        cursor = token.start;
        continue;
      }
      const cls = TOKEN_CLASS[token.type];
      html += cls ? `<span class="${cls}">${content}</span>` : content;
      cursor = token.end;
    }
    if (cursor < value.length) html += escapeHtml(value.slice(cursor));
    return html;
  }, [value]);

  const lineCount = useMemo(() => {
    if (!value) return 1;
    let n = 1;
    for (let i = 0; i < value.length; i += 1) if (value[i] === "\n") n += 1;
    return n;
  }, [value]);

  /** line number → most severe finding marker */
  const markers = useMemo(() => {
    const map = new Map<number, Severity>();
    const rank: Record<Severity, number> = {
      CRITICAL: 0,
      HIGH: 1,
      MEDIUM: 2,
      LOW: 3,
      INFO: 4,
    };
    for (const f of findings) {
      if (f.line <= 0) continue;
      const existing = map.get(f.line);
      if (!existing || (rank[f.severity] ?? 5) < rank[existing]) {
        map.set(f.line, f.severity);
      }
    }
    return map;
  }, [findings]);

  const lineStartOffset = useCallback(
    (line: number): number | null => {
      let offset = 0;
      let current = 1;
      while (current < line) {
        const idx = value.indexOf("\n", offset);
        if (idx === -1) return null;
        offset = idx + 1;
        current += 1;
      }
      return offset;
    },
    [value],
  );

  /** Public API: jump the caret to a source line and flash it. */
  const focusLine = useCallback(
    (line: number) => {
      const clamped = Math.max(1, Math.min(line, lineCount));
      const offset = lineStartOffset(clamped);
      setActiveLine(clamped);
      if (flashTimer.current) window.clearTimeout(flashTimer.current);
      setFlashLine(clamped);
      flashTimer.current = window.setTimeout(() => setFlashLine(null), 1600);
      const ta = textareaRef.current;
      if (ta && offset !== null) {
        ta.focus({ preventScroll: true });
        ta.setSelectionRange(offset, offset);
        requestAnimationFrame(() => {
          const root = scrollRef.current;
          const lineEl = root?.parentElement?.querySelector<HTMLElement>(
            `[data-editor-line="${clamped}"]`,
          );
          lineEl?.scrollIntoView({ block: "center", behavior: "smooth" });
        });
      }
    },
    [lineCount, lineStartOffset],
  );

  useImperativeHandle(ref, () => ({ focusLine }), [focusLine]);

  useEffect(() => {
    return () => {
      if (flashTimer.current) window.clearTimeout(flashTimer.current);
    };
  }, []);

  /** Translate the gutter so its numbers follow the shared scroll pane. */
  const syncGutter = useCallback(() => {
    const scroll = scrollRef.current;
    const gutter = scroll?.parentElement?.querySelector<HTMLElement>(
      "[data-gutter-lines]",
    );
    if (scroll && gutter) {
      gutter.style.transform = `translate3d(0, ${-scroll.scrollTop}px, 0)`;
    }
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      onAnalyze();
    }
  };

  const handleCaretMove = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    const upto = value.slice(0, ta.selectionStart ?? 0);
    let line = 1;
    for (let i = 0; i < upto.length; i += 1) if (upto[i] === "\n") line += 1;
    setActiveLine(line);
  };

  const editorPad = "p-4";
  const fontCls = "code-editor-font m-0 whitespace-pre text-[13.5px] leading-6";

  return (
    <div className={cn("flex h-full min-h-0 flex-col overflow-hidden", className)}>
      {/* toolbar strip */}
      <div className="flex items-center justify-between gap-2 border-b border-white/50 px-4 py-1.5 text-[11px] text-muted-foreground">
        <span className="font-medium tracking-wide text-slate-500">C SOURCE</span>
        <span className="hidden items-center gap-1.5 sm:flex">
          <kbd className="rounded border border-slate-300/80 bg-white/60 px-1.5 py-0.5 font-mono text-[10px] text-slate-500">
            Ctrl
          </kbd>
          +
          <kbd className="rounded border border-slate-300/80 bg-white/60 px-1.5 py-0.5 font-mono text-[10px] text-slate-500">
            Enter
          </kbd>
          to analyze
        </span>
      </div>

      <div className="relative flex min-h-0 flex-1">
        {/* Gutter (vertically synced with the shared scroll pane) */}
        <div
          className="relative z-20 w-14 shrink-0 overflow-hidden border-r border-white/60 bg-white/60 backdrop-blur-sm"
          aria-hidden
        >
          <div
            className="flex flex-col px-1.5 pt-4 text-right font-mono text-[13.5px] leading-6 text-slate-400"
            data-gutter-lines
            style={{ height: `${lineCount * LINE_HEIGHT_REM + 2}rem` }}
          >
            {Array.from({ length: lineCount }, (_, i) => i + 1).map((n) => (
              <div
                key={n}
                data-editor-line={n}
                className={cn(
                  "flex min-h-6 items-center justify-end gap-1.5",
                  n === flashLine && "-mx-1.5 rounded-md bg-amber-200/80 px-1.5",
                  n === activeLine && "font-semibold text-primary",
                )}
              >
                <span className="min-w-1.5 shrink-0">
                  {markers.has(n) && (
                    <span
                      className={cn(
                        "inline-block size-1.5 rounded-full",
                        SEVERITY_DOT[markers.get(n) as Severity],
                      )}
                    />
                  )}
                </span>
                {n}
              </div>
            ))}
          </div>
        </div>

        {/* Shared scroll pane: <pre> sizes the box, <textarea> overlays it */}
        <div
          ref={scrollRef}
          onScroll={syncGutter}
          className="scrollbar-thin relative min-w-0 flex-1 overflow-auto bg-white/40"
        >
          <div className="relative min-h-full w-max min-w-full">
            <pre
              className={cn(
                fontCls,
                editorPad,
                "inline-block min-h-full min-w-full align-top text-slate-700",
              )}
              aria-hidden
            >
              <code dangerouslySetInnerHTML={{ __html: highlightedHtml }} />
            </pre>
            <textarea
              ref={textareaRef}
              value={value}
              readOnly={readOnly}
              onChange={(e) => {
                onChange(e.target.value);
                handleCaretMove();
              }}
              onKeyDown={handleKeyDown}
              onSelect={handleCaretMove}
              onClick={handleCaretMove}
              onKeyUp={handleCaretMove}
              spellCheck={false}
              autoCapitalize="off"
              autoCorrect="off"
              autoComplete="off"
              wrap="off"
              className={cn(
                fontCls,
                editorPad,
                "code-input absolute inset-0 resize-none overflow-hidden",
              )}
              placeholder="// Paste or type C source code…"
              aria-label="C source code editor"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
