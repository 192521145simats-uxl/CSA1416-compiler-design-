import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { Severity } from "@/convex/analyzer/types";

/* ------------------------------------------------------------------ */
/* Surfaces                                                            */
/* ------------------------------------------------------------------ */

export function GlassCard({
  className,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("glass edge-glow", className)} {...props} />;
}

export function GlassPanel({
  className,
  children,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("glass-subtle", className)} {...props}>
      {children}
    </div>
  );
}

type GlassButtonVariant = "primary" | "outline" | "ghost";
type GlassButtonProps = Omit<React.ComponentProps<typeof Button>, "variant"> & {
  variant?: GlassButtonVariant;
};

export function GlassButton({
  variant = "primary",
  className,
  children,
  ...props
}: GlassButtonProps) {
  const buttonVariant =
    variant === "outline" ? "outline" : variant === "ghost" ? "ghost" : "default";
  return (
    <Button
      data-slot="glass-button"
      variant={buttonVariant}
      className={cn(
        "relative overflow-hidden rounded-xl font-semibold transition-all duration-200",
        variant === "primary" &&
          "bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 text-white shadow-[0_10px_24px_-10px_rgba(37,99,235,0.65)] hover:from-sky-500 hover:via-blue-500 hover:to-indigo-500 hover:shadow-[0_14px_30px_-10px_rgba(37,99,235,0.7)]",
        variant === "outline" && "glass-subtle text-foreground hover:bg-white/70",
        variant === "ghost" && "hover:bg-white/70",
        className,
      )}
      {...props}
    >
      {children}
    </Button>
  );
}

/* ------------------------------------------------------------------ */
/* Badges                                                              */
/* ------------------------------------------------------------------ */

export type GlassBadgeTone =
  | "neutral"
  | "brand"
  | "success"
  | "warning"
  | "danger"
  | "info";

export function GlassBadge({
  className,
  children,
  tone = "neutral",
}: {
  className?: string;
  children: ReactNode;
  tone?: GlassBadgeTone;
}) {
  const tones: Record<GlassBadgeTone, string> = {
    neutral: "border-slate-200/80 bg-white/70 text-slate-600",
    brand: "border-blue-200/80 bg-blue-50/80 text-blue-700",
    success: "border-emerald-200/80 bg-emerald-50/80 text-emerald-700",
    warning: "border-amber-200/80 bg-amber-50/80 text-amber-700",
    danger: "border-rose-200/80 bg-rose-50/80 text-rose-700",
    info: "border-cyan-200/80 bg-cyan-50/80 text-cyan-700",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

const SEVERITY_STYLES: Record<Severity, { tone: GlassBadgeTone; dot: string }> = {
  CRITICAL: { tone: "danger", dot: "bg-rose-500" },
  HIGH: { tone: "danger", dot: "bg-orange-500" },
  MEDIUM: { tone: "warning", dot: "bg-amber-500" },
  LOW: { tone: "brand", dot: "bg-blue-500" },
  INFO: { tone: "neutral", dot: "bg-slate-400" },
};

export function SeverityBadge({
  severity,
  className,
  withDot = true,
}: {
  severity: Severity;
  className?: string;
  withDot?: boolean;
}) {
  const style = SEVERITY_STYLES[severity] ?? SEVERITY_STYLES.INFO;
  return (
    <GlassBadge tone={style.tone} className={className}>
      {withDot && (
        <span className={cn("size-1.5 rounded-full", style.dot)} />
      )}
      {severity}
    </GlassBadge>
  );
}

export function CategoryBadge({ category }: { category: string }) {
  const tones: Record<string, "brand" | "info" | "warning" | "danger" | "success"> = {
    LEXICAL: "info",
    SYNTAX: "warning",
    SEMANTIC: "danger",
    SECURITY: "danger",
    RUNTIME: "brand",
  };
  return (
    <GlassBadge tone={tones[category] ?? "neutral"} className="font-mono uppercase">
      {category}
    </GlassBadge>
  );
}

/* ------------------------------------------------------------------ */
/* Ambient scene (page background art)                                 */
/* ------------------------------------------------------------------ */

export function AmbientScene({ className }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={cn(
        "pointer-events-none fixed inset-0 -z-10 overflow-hidden",
        className,
      )}
    >
      <div className="absolute -top-32 -left-24 size-[480px] rounded-full bg-gradient-to-br from-sky-300/45 to-blue-400/20 blur-3xl animate-float-slow" />
      <div className="absolute top-1/4 -right-32 size-[520px] rounded-full bg-gradient-to-bl from-indigo-300/40 via-violet-300/25 to-cyan-200/30 blur-3xl animate-float-slow [animation-delay:-4s]" />
      <div className="absolute bottom-[-180px] left-1/3 size-[520px] rounded-full bg-gradient-to-tr from-cyan-200/40 to-sky-300/25 blur-3xl animate-float-slow [animation-delay:-8s]" />
    </div>
  );
}
